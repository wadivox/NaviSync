import { RouteOption, RouteStep, NavigationMode } from '../types/navigation';

export class RoutingProvider {
  public async getRoutes(
    startLat: number,
    startLng: number,
    destLat: number,
    destLng: number,
    mode: NavigationMode = 'driving'
  ): Promise<RouteOption[]> {
    try {
      // Set 3.5s timeout on network request to prevent UI stall
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);

      // Select profile for OSRM request
      const osrmProfile = mode === 'walking' ? 'walking' : mode === 'cycling' ? 'bicycle' : 'driving';
      const url = `https://router.project-osrm.org/route/v1/${osrmProfile}/${startLng},${startLat};${destLng},${destLat}?overview=full&geometries=geojson&steps=true&alternatives=true`;
      
      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);

      if (!res.ok) throw new Error(`OSRM status ${res.status}`);
      const data = await res.json();

      if (!data.routes || data.routes.length === 0) {
        throw new Error('No OSRM routes found');
      }

      // Mode-specific speeds (in meters per second):
      // Walking: ~4.8 km/h = 1.33 m/s
      // Cycling: ~16 km/h = 4.44 m/s
      // Two-Wheeler: ~40 km/h = 11.1 m/s (agile filtering through urban traffic)
      // Driving: ~32-45 km/h = 9.7 - 12.5 m/s (urban congestion dependent)
      const getSpeedMps = (m: NavigationMode): number => {
        switch (m) {
          case 'walking':
            return 1.33; // 4.8 km/h
          case 'cycling':
            return 4.44; // 16 km/h
          case 'two_wheeler':
            return 10.5; // ~38 km/h (quicker than car in traffic)
          case 'driving':
          default:
            return 8.9; // ~32 km/h average urban speed
        }
      };

      const speedMps = getSpeedMps(mode);

      return data.routes.map((r: any, idx: number): RouteOption => {
        // GeoJSON coordinates are [lng, lat], convert to [lat, lng]
        const coordinates: [number, number][] = r.geometry.coordinates.map((c: [number, number]) => [c[1], c[0]]);
        
        const rawDistanceMeters = r.distance || 1000;
        // Walking paths may take slightly more direct pedestrian cuts
        const modeDistanceKm =
          mode === 'walking'
            ? Math.round(((rawDistanceMeters * 0.94) / 1000) * 10) / 10
            : Math.round((rawDistanceMeters / 1000) * 10) / 10;

        const modeDurationMinutes = Math.max(1, Math.round((modeDistanceKm * 1000) / speedMps / 60));

        const steps: RouteStep[] = (r.legs[0]?.steps || []).map((s: any, stepIdx: number): RouteStep => {
          let maneuverType: RouteStep['maneuver'] = 'continue';
          const t = (s.maneuver?.type || '').toLowerCase();
          const mod = (s.maneuver?.modifier || '').toLowerCase();
          
          if (t === 'arrive') maneuverType = 'arrive';
          else if (t === 'depart') maneuverType = 'depart';
          else if (mod.includes('left')) maneuverType = mod.includes('slight') ? 'slight-left' : 'turn-left';
          else if (mod.includes('right')) maneuverType = mod.includes('slight') ? 'slight-right' : 'turn-right';
          else if (mod.includes('u-turn')) maneuverType = 'u-turn';

          const streetName = s.name || (stepIdx === 0 ? 'Start route' : 'Continue straight');
          const stepDistMeters = Math.round(s.distance);
          const stepDurSeconds = Math.max(5, Math.round(stepDistMeters / speedMps));

          // Check for tunnel risk
          const isTunnel = (streetName + ' ' + (s.maneuver?.instruction || '')).toLowerCase().includes('tunnel');

          // Mode-adapted instruction
          let prefix = '';
          if (mode === 'walking') prefix = 'Walk along ';
          else if (mode === 'cycling') prefix = 'Cycle along ';
          else if (mode === 'two_wheeler') prefix = 'Ride along ';

          const rawInstruction = s.maneuver?.instruction || `In ${stepDistMeters}m, ${maneuverType.replace('-', ' ')}`;
          const adaptedInstruction = prefix ? `${prefix}${streetName} (${stepDistMeters}m)` : rawInstruction;

          return {
            id: `step-${idx}-${stepIdx}`,
            instruction: adaptedInstruction,
            maneuver: maneuverType,
            distanceMeters: stepDistMeters,
            durationSeconds: stepDurSeconds,
            startCoordinate: { lat: s.maneuver?.location[1] || startLat, lng: s.maneuver?.location[0] || startLng },
            endCoordinate: { lat: destLat, lng: destLng },
            streetName,
            gnssRiskLevel: isTunnel ? 'HIGH' : 'LOW',
            gnssRiskReason: isTunnel ? 'Subterranean GNSS signal loss likely' : undefined
          };
        });

        // Mode-specific route labels
        const modeLabel =
          mode === 'walking'
            ? idx === 0 ? 'Pedestrian Walkway' : 'Scenic Footpath'
            : mode === 'cycling'
            ? idx === 0 ? 'Designated Bike Route' : 'Low-Traffic Byway'
            : mode === 'two_wheeler'
            ? idx === 0 ? 'Express Two-Wheeler Route' : 'Alternative Arterial'
            : idx === 0 ? 'Primary Route (Fastest)' : idx === 1 ? 'Via Outer Ring Rd' : 'Scenic Boulevard';

        return {
          id: `route-${mode}-${idx}`,
          name: modeLabel,
          summary: r.legs[0]?.summary || `Via ${steps[1]?.streetName || 'Road Network'}`,
          distanceKm: modeDistanceKm,
          durationMinutes: modeDurationMinutes + (idx === 1 ? Math.round(modeDurationMinutes * 0.15) : 0),
          trafficLevel: mode === 'walking' || mode === 'cycling' ? 'LOW' : idx === 0 ? 'MODERATE' : 'LOW',
          isFastest: idx === 0,
          isEco: mode === 'cycling' || mode === 'walking' || idx === 2,
          isShortest: idx === 1,
          coordinates,
          steps,
          tunnelSegments: this.detectTunnelSegments(coordinates, steps)
        };
      });
    } catch (err) {
      console.warn(`Routing query fallback for mode ${mode}:`, err);
      return this.generateSyntheticRoute(startLat, startLng, destLat, destLng, mode);
    }
  }

  private detectTunnelSegments(coords: [number, number][], steps: RouteStep[]) {
    // If any step contains tunnel, mark indices
    const tunnels: { startIdx: number; endIdx: number; name: string }[] = [];
    steps.forEach((s, sIdx) => {
      if ((s.streetName + ' ' + s.instruction).toLowerCase().includes('tunnel')) {
        const approxIdx = Math.floor((sIdx / Math.max(1, steps.length)) * coords.length);
        tunnels.push({
          startIdx: approxIdx,
          endIdx: Math.min(coords.length - 1, approxIdx + 12),
          name: s.streetName || 'Mountain Tunnel'
        });
      }
    });
    return tunnels;
  }

  public generateSyntheticRoute(
    startLat: number,
    startLng: number,
    destLat: number,
    destLng: number,
    mode: NavigationMode = 'driving'
  ): RouteOption[] {
    // Interpolate realistic waypoints with slight curve
    const coords: [number, number][] = [];
    const pointsCount = 40;

    for (let i = 0; i <= pointsCount; i++) {
      const frac = i / pointsCount;
      const curvature = Math.sin(frac * Math.PI) * (mode === 'walking' ? 0.003 : 0.008);
      const lat = startLat + frac * (destLat - startLat) + curvature;
      const lng = startLng + frac * (destLng - startLng) - curvature * 0.7;
      coords.push([lat, lng]);
    }

    const directDistKm = this.calculateDistance(startLat, startLng, destLat, destLng);
    
    // Distances and speed profiles per mode
    let distKm = Math.round(directDistKm * 1.22 * 10) / 10;
    let durMin = Math.round(distKm * 2.1); // ~30 km/h driving baseline

    if (mode === 'walking') {
      distKm = Math.round(directDistKm * 1.08 * 10) / 10; // direct paths
      durMin = Math.max(1, Math.round((distKm / 4.8) * 60)); // ~12.5 min/km
    } else if (mode === 'cycling') {
      distKm = Math.round(directDistKm * 1.15 * 10) / 10;
      durMin = Math.max(1, Math.round((distKm / 16.0) * 60)); // ~3.75 min/km
    } else if (mode === 'two_wheeler') {
      distKm = Math.round(directDistKm * 1.2 * 10) / 10;
      durMin = Math.max(1, Math.round((distKm / 38.0) * 60)); // ~1.58 min/km
    } else {
      // Driving
      distKm = Math.round(directDistKm * 1.25 * 10) / 10;
      durMin = Math.max(1, Math.round((distKm / 32.0) * 60)); // ~1.88 min/km
    }

    const stepSpeedMps = (distKm * 1000) / (durMin * 60);

    const steps: RouteStep[] = [
      {
        id: 'step-0',
        instruction: mode === 'walking' ? 'Walk forward on pedestrian path' : 'Head out toward main road',
        maneuver: 'depart',
        distanceMeters: Math.round(distKm * 120),
        durationSeconds: Math.round((distKm * 120) / stepSpeedMps),
        startCoordinate: { lat: startLat, lng: startLng },
        endCoordinate: { lat: coords[8][0], lng: coords[8][1] },
        streetName: mode === 'walking' ? 'Pedestrian Walkway' : 'Avenue Link'
      },
      {
        id: 'step-1',
        instruction: mode === 'walking' ? 'Continue along sidewalk for 1.5 km' : 'Continue on Outer Ring Road',
        maneuver: 'continue',
        distanceMeters: Math.round(distKm * 400),
        durationSeconds: Math.round((distKm * 400) / stepSpeedMps),
        startCoordinate: { lat: coords[8][0], lng: coords[8][1] },
        endCoordinate: { lat: coords[22][0], lng: coords[22][1] },
        streetName: mode === 'walking' ? 'City Sidewalk' : 'Outer Ring Road'
      },
      {
        id: 'step-2',
        instruction: mode === 'walking' ? 'Pass pedestrian tunnel underpass' : 'Enter Patalganga Mountain Tunnel (GNSS Risk Zone)',
        maneuver: 'continue',
        distanceMeters: Math.round(distKm * 280),
        durationSeconds: Math.round((distKm * 280) / stepSpeedMps),
        startCoordinate: { lat: coords[22][0], lng: coords[22][1] },
        endCoordinate: { lat: coords[32][0], lng: coords[32][1] },
        streetName: 'Patalganga Underpass',
        gnssRiskLevel: 'HIGH',
        gnssRiskReason: 'Subterranean tunnel with zero satellite line-of-sight'
      },
      {
        id: 'step-3',
        instruction: 'Turn slight right toward destination approach',
        maneuver: 'slight-right',
        distanceMeters: Math.round(distKm * 150),
        durationSeconds: Math.round((distKm * 150) / stepSpeedMps),
        startCoordinate: { lat: coords[32][0], lng: coords[32][1] },
        endCoordinate: { lat: coords[38][0], lng: coords[38][1] },
        streetName: 'Destination Approach'
      },
      {
        id: 'step-4',
        instruction: 'You have arrived at your destination',
        maneuver: 'arrive',
        distanceMeters: 50,
        durationSeconds: Math.round(50 / stepSpeedMps),
        startCoordinate: { lat: coords[38][0], lng: coords[38][1] },
        endCoordinate: { lat: destLat, lng: destLng },
        streetName: 'Destination'
      }
    ];

    const modeTitle =
      mode === 'walking' ? 'Footpath Route' : mode === 'cycling' ? 'Bicycle Trail' : mode === 'two_wheeler' ? 'Moto Priority' : 'Primary Expressway';

    return [
      {
        id: `route-${mode}-fastest`,
        name: `${modeTitle} (Fastest)`,
        summary: mode === 'walking' ? 'Via Direct Walkway' : 'Via Outer Ring & Tunnel',
        distanceKm: distKm,
        durationMinutes: durMin,
        trafficLevel: mode === 'walking' || mode === 'cycling' ? 'LOW' : 'MODERATE',
        isFastest: true,
        coordinates: coords,
        steps,
        tunnelSegments: [{ startIdx: 22, endIdx: 32, name: 'Patalganga Underpass Tunnel' }]
      },
      {
        id: `route-${mode}-alt`,
        name: mode === 'walking' ? 'Shaded Park Walk' : 'Surface Byway (Avoids Tunnel)',
        summary: mode === 'walking' ? 'Via Park Greenery' : 'Via Surface Ridgeline Rd',
        distanceKm: Math.round((distKm + (mode === 'walking' ? 0.3 : 1.6)) * 10) / 10,
        durationMinutes: durMin + (mode === 'walking' ? 4 : 5),
        trafficLevel: 'LOW',
        isEco: true,
        coordinates: coords.map(c => [c[0] + 0.002, c[1] - 0.003]),
        steps: steps.filter(s => s.id !== 'step-2')
      }
    ];
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
  }
}
