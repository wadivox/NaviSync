export interface GeocodingResult {
  displayName: string;
  name: string;
  lat: number;
  lng: number;
  type: string;
}

export class GeocodingProvider {
  private cache = new Map<string, GeocodingResult[]>();

  public async search(query: string): Promise<GeocodingResult[]> {
    if (!query || query.trim().length < 2) return [];
    const cleanQuery = query.trim();

    if (this.cache.has(cleanQuery.toLowerCase())) {
      return this.cache.get(cleanQuery.toLowerCase())!;
    }

    try {
      // Real Nominatim geocoding
      const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(cleanQuery)}&limit=7&addressdetails=1`;
      const response = await fetch(url, {
        headers: {
          'Accept-Language': 'en',
          'User-Agent': 'NaviSync-App/1.0'
        }
      });

      if (!response.ok) {
        throw new Error(`Nominatim responded with ${response.status}`);
      }

      const data = await response.json();
      const results: GeocodingResult[] = data.map((item: any) => ({
        displayName: item.display_name,
        name: item.name || item.display_name.split(',')[0],
        lat: parseFloat(item.lat),
        lng: parseFloat(item.lon),
        type: item.type || 'place'
      }));

      this.cache.set(cleanQuery.toLowerCase(), results);
      return results;
    } catch (err) {
      console.warn('Geocoding API network fallback:', err);
      // Fallback local global search presets
      return this.getLocalFallback(cleanQuery);
    }
  }

  private getLocalFallback(query: string): GeocodingResult[] {
    const presets = [
      { name: 'Hyderabad Central (Cyber Towers)', displayName: 'Cyber Towers, Hitec City, Hyderabad, Telangana, India', lat: 17.4504, lng: 78.3808, type: 'commercial' },
      { name: 'Mumbai Airport (BOM)', displayName: 'Chhatrapati Shivaji Maharaj International Airport, Mumbai, Maharashtra, India', lat: 19.0896, lng: 72.8656, type: 'aerodrome' },
      { name: 'London King\'s Cross', displayName: 'King\'s Cross Station, Euston Rd, London, United Kingdom', lat: 51.5308, lng: -0.1238, type: 'station' },
      { name: 'Tokyo Shibuya Crossing', displayName: 'Shibuya Crossing, Shibuya City, Tokyo, Japan', lat: 35.6595, lng: 139.7005, type: 'landmark' },
      { name: 'New York Central Park', displayName: 'Central Park, Manhattan, New York, NY, USA', lat: 40.785091, lng: -73.968285, type: 'park' },
      { name: 'Apollo Hospitals Emergency', displayName: 'Apollo Hospitals Jubilee Hills, Hyderabad, Telangana', lat: 17.4239, lng: 78.4162, type: 'hospital' },
      { name: 'EV Supercharger Station', displayName: 'Tata Power EZ EV Fast Charging Station, Outer Ring Rd', lat: 17.4320, lng: 78.3680, type: 'ev_charging' }
    ];

    const q = query.toLowerCase();
    return presets.filter(p => p.name.toLowerCase().includes(q) || p.displayName.toLowerCase().includes(q));
  }
}
