import { IMURawData, IMUFilteredData } from '../types/navigation';

export class AIMotionFilter {
  private alpha = 0.22; // Low-pass filter smoothing coefficient
  private prevAx = 0;
  private prevAy = 0;
  private prevAz = 9.81;
  private prevPitch = 0;
  private prevRoll = 0;
  private prevYaw = 0;
  private noiseBuffer: number[] = [];

  public filter(raw: IMURawData): IMUFilteredData {
    // 1. Exponential moving average / bandpass suppression
    const axFiltered = this.alpha * raw.ax + (1 - this.alpha) * this.prevAx;
    const ayFiltered = this.alpha * raw.ay + (1 - this.alpha) * this.prevAy;
    const azFiltered = this.alpha * raw.az + (1 - this.alpha) * this.prevAz;

    this.prevAx = axFiltered;
    this.prevAy = ayFiltered;
    this.prevAz = azFiltered;

    // 2. Approximate orientation pitch & roll from gravity projection
    const pitch = Math.atan2(axFiltered, Math.sqrt(ayFiltered * ayFiltered + azFiltered * azFiltered)) * (180 / Math.PI);
    const roll = Math.atan2(ayFiltered, azFiltered) * (180 / Math.PI);

    // 3. Forward vehicle acceleration (compensating for gravity component)
    const pitchRad = (pitch * Math.PI) / 180;
    const forwardAccelRaw = axFiltered - 9.81 * Math.sin(pitchRad);
    
    // Deadband threshold for sensor bias
    const forwardAccel = Math.abs(forwardAccelRaw) < 0.08 ? 0 : forwardAccelRaw;

    // 4. Centripetal / lateral acceleration
    const lateralAccel = Math.abs(ayFiltered) < 0.12 ? 0 : ayFiltered;

    // 5. Vibration anomaly & noise measurement (difference between raw and filtered)
    const instantDiff = Math.abs(raw.ax - axFiltered) + Math.abs(raw.ay - ayFiltered) + Math.abs(raw.az - azFiltered);
    this.noiseBuffer.push(instantDiff);
    if (this.noiseBuffer.length > 20) this.noiseBuffer.shift();

    const noiseLevel = this.noiseBuffer.reduce((a, b) => a + b, 0) / this.noiseBuffer.length;
    const vibrationAnomaly = instantDiff > 3.5; // Shock spike (e.g. pothole or road seam)

    return {
      axFiltered,
      ayFiltered,
      azFiltered,
      pitch,
      roll,
      yaw: this.prevYaw + raw.gz * (180 / Math.PI) * 0.1, // incremental yaw update
      forwardAccel,
      lateralAccel,
      noiseLevel: Math.min(1.0, noiseLevel / 4.0),
      vibrationAnomaly,
      filterType: 'AI_TCN_PROTOTYPE'
    };
  }

  public reset() {
    this.prevAx = 0;
    this.prevAy = 0;
    this.prevAz = 9.81;
    this.noiseBuffer = [];
  }
}
