import { GNSSReading, IMUFilteredData, FusionState, GNSSState, NaviSyncNavigationState } from '../types/navigation';
import { NaviSyncSpeedEstimator } from './NaviSyncSpeedEstimator';
import { ZeroVelocityDetector } from './ZeroVelocityDetector';
import { NHCConstraintEngine } from './NHCConstraintEngine';
import { MapMatchingEngine } from './MapMatchingEngine';
import { DriftEstimator } from './DriftEstimator';
import { globalVehicleAlignmentEngine } from './VehicleAlignmentEngine';

export class SensorFusionEngine {
  private currentLat: number;
  private currentLng: number;
  private currentHeadingDeg: number = 0;
  private headingConfidence: number = 0.95;
  private headingSource: 'GNSS_COURSE' | 'FUSED_IMU' | 'COMPASS_DEVICE' | 'LAST_RELIABLE' = 'FUSED_IMU';
  private lastTimestamp = Date.now();

  private speedEstimator = new NaviSyncSpeedEstimator();
  private zuptDetector = new ZeroVelocityDetector();
  private nhcEngine = new NHCConstraintEngine();
  private mapMatcher = new MapMatchingEngine();
  private driftEstimator = new DriftEstimator();

  // Smoothing filter gain
  private kalmanGain = 0.65;

  private latestNavState: NaviSyncNavigationState;

  constructor(initialLat = 17.385044, initialLng = 78.486671, initialHeading = 0) {
    this.currentLat = initialLat;
    this.currentLng = initialLng;
    this.currentHeadingDeg = initialHeading;

    this.latestNavState = {
      latitude: initialLat,
      longitude: initialLng,
      accuracy: 10,
      altitude: null,
      heading: initialHeading,
      headingConfidence: 0.9,
      headingSource: 'FUSED_IMU',
      speedMps: 0,
      speedKmh: 0,
      speedConfidence: 0.95,
      speedSource: 'ZUPT_ZERO',
      gnssStatus: 'AVAILABLE',
      navigationMode: 'GNSS',
      positionConfidence: 0.95,
      estimatedDriftMeters: 0,
      isStationary: true,
      timestamp: Date.now()
    };
  }

  public setPosition(lat: number, lng: number, heading = this.currentHeadingDeg) {
    this.currentLat = lat;
    this.currentLng = lng;
    this.currentHeadingDeg = heading;
    this.latestNavState.latitude = lat;
    this.latestNavState.longitude = lng;
    this.latestNavState.heading = heading;
  }

  public update(
    gnssReading: GNSSReading | null,
    gnssState: GNSSState,
    filteredIMU: IMUFilteredData,
    rawGzRadPerSec: number,
    routeCoordinates: [number, number][] = [],
    now = Date.now(),
    deviceCompassHeading: number | null = null
  ): FusionState {
    const dt = Math.min(0.25, Math.max(0.01, (now - this.lastTimestamp) / 1000));
    this.lastTimestamp = now;

    // 1. Check ZUPT (Zero Velocity Update)
    const isZupt = this.zuptDetector.getIsStationary();

    // 2. Real-Time Dedicated Speed Estimation (Cases 1, 2, 3, 4)
    const speedResult = this.speedEstimator.update(
      filteredIMU,
      isZupt,
      gnssReading,
      gnssState,
      now
    );
    const speedMps = speedResult.speedMps;
    const speedKmh = speedResult.speedKmh;

    // 3. Multi-Sensor Heading Pipeline with Vehicle Alignment (Requirements 3, 4, 5)
    // Priority:
    // If vehicle movement detected: GNSS course + gyro + accel + magnetometer through fusion
    // If GNSS course unavailable: Gyro + accel + magnetometer + alignment offset + motion model
    const yawRateDeg = (rawGzRadPerSec * 180) / Math.PI;

    // NHC vehicle motion constraints
    const { constrainedHeadingDeg } = this.nhcEngine.applyConstraints(
      this.currentHeadingDeg,
      yawRateDeg,
      speedMps,
      dt
    );
    this.currentHeadingDeg = constrainedHeadingDeg;

    if (gnssState === 'GNSS_AVAILABLE' && gnssReading?.heading !== null && gnssReading?.heading !== undefined && !isNaN(gnssReading.heading)) {
      // High confidence GNSS course
      const gnssHeading = gnssReading.heading;
      // Shortest angle difference blend
      const diff = ((gnssHeading - this.currentHeadingDeg + 540) % 360) - 180;
      this.currentHeadingDeg = (this.currentHeadingDeg + diff * 0.45 + 360) % 360;
      this.headingConfidence = 0.96;
      this.headingSource = 'GNSS_COURSE';

      // Provide sample to Vehicle Alignment Engine if calibration is running
      if (deviceCompassHeading !== null) {
        globalVehicleAlignmentEngine.addSample(
          gnssHeading,
          deviceCompassHeading,
          filteredIMU.pitch,
          filteredIMU.roll,
          speedKmh
        );
      }
    } else if (deviceCompassHeading !== null && !isNaN(deviceCompassHeading)) {
      // Compass heading adjusted by vehicle alignment offset
      const alignedCompass = globalVehicleAlignmentEngine.applyAlignment(deviceCompassHeading);
      const diff = ((alignedCompass - this.currentHeadingDeg + 540) % 360) - 180;
      this.currentHeadingDeg = (this.currentHeadingDeg + diff * 0.25 + 360) % 360;
      this.headingConfidence = 0.88;
      this.headingSource = 'COMPASS_DEVICE';
    } else {
      // Gyroscopic dead reckoning
      this.headingConfidence = Math.max(0.65, 0.92 - (this.driftEstimator.getDriftMeters() / 150));
      this.headingSource = 'FUSED_IMU';
    }

    // 4. Dead Reckoning Displacement: delta distance
    const deltaDistanceMeters = isZupt ? 0 : speedMps * dt;

    // Project displacement into lat/lng
    const headingRad = (this.currentHeadingDeg * Math.PI) / 180;
    const deltaLat = (deltaDistanceMeters * Math.cos(headingRad)) / 111132;
    const deltaLng = (deltaDistanceMeters * Math.sin(headingRad)) / (111132 * Math.cos((this.currentLat * Math.PI) / 180));

    let projectedLat = this.currentLat + deltaLat;
    let projectedLng = this.currentLng + deltaLng;

    let gnssWeight = 0;
    let imuWeight = 1.0;
    let activeEngine: 'GNSS' | 'NAVISYNC_INERTIAL' | 'FUSED' = 'NAVISYNC_INERTIAL';

    // 5. Sensor Fusion with GNSS (Smooth Kalman innovation without jumps)
    if (gnssState === 'GNSS_AVAILABLE' && gnssReading) {
      activeEngine = 'GNSS';
      gnssWeight = 0.85;
      imuWeight = 0.15;

      const innovLat = gnssReading.latitude - projectedLat;
      const innovLng = gnssReading.longitude - projectedLng;

      projectedLat += innovLat * this.kalmanGain;
      projectedLng += innovLng * this.kalmanGain;
    } else if (gnssState === 'GNSS_RESTORING' && gnssReading) {
      activeEngine = 'FUSED';
      gnssWeight = 0.45;
      imuWeight = 0.55;
      const innovLat = gnssReading.latitude - projectedLat;
      const innovLng = gnssReading.longitude - projectedLng;
      projectedLat += innovLat * 0.25;
      projectedLng += innovLng * 0.25;
    } else {
      activeEngine = 'NAVISYNC_INERTIAL';
      gnssWeight = 0.0;
      imuWeight = 1.0;
    }

    // 6. Map Matching onto Route/Road Geometry
    let isMapMatched = false;
    if (routeCoordinates.length > 1) {
      const matchResult = this.mapMatcher.matchToRoute(
        projectedLat,
        projectedLng,
        this.currentHeadingDeg,
        routeCoordinates
      );
      projectedLat = matchResult.matchedLat;
      projectedLng = matchResult.matchedLng;
      this.currentHeadingDeg = matchResult.matchedHeading;
      isMapMatched = matchResult.isMatched;
    }

    this.currentLat = projectedLat;
    this.currentLng = projectedLng;

    // 7. Calculate Drift and Dynamic Confidence
    const isLost = gnssState === 'GNSS_LOST' || gnssState === 'NAVISYNC_INERTIAL' || gnssState === 'GNSS_DEGRADED';
    const driftResult = this.driftEstimator.update(
      isLost,
      isZupt,
      deltaDistanceMeters,
      isMapMatched,
      now
    );

    // Map gnssStatus for NaviSyncNavigationState
    let navStateGnssStatus: 'AVAILABLE' | 'DEGRADED' | 'LOST' | 'RESTORED' = 'AVAILABLE';
    if (gnssState === 'GNSS_LOST' || gnssState === 'NAVISYNC_INERTIAL') {
      navStateGnssStatus = 'LOST';
    } else if (gnssState === 'GNSS_DEGRADED') {
      navStateGnssStatus = 'DEGRADED';
    } else if (gnssState === 'GNSS_RESTORING') {
      navStateGnssStatus = 'RESTORED';
    }

    let navMode: 'GNSS' | 'FUSED' | 'DEAD_RECKONING' = 'GNSS';
    if (isLost) {
      navMode = 'DEAD_RECKONING';
    } else if (gnssState === 'GNSS_RESTORING' || activeEngine === 'FUSED') {
      navMode = 'FUSED';
    }

    // Update authoritative single state
    this.latestNavState = {
      latitude: this.currentLat,
      longitude: this.currentLng,
      accuracy: gnssReading?.accuracy || (isLost ? Math.round(driftResult.driftMeters + 8) : 10),
      altitude: gnssReading?.altitude || null,
      heading: Math.round(this.currentHeadingDeg),
      headingConfidence: Math.round(this.headingConfidence * 100) / 100,
      headingSource: this.headingSource,
      speedMps: speedResult.speedMps,
      speedKmh: speedResult.speedKmh,
      speedConfidence: speedResult.speedConfidence,
      speedSource: speedResult.speedSource,
      gnssStatus: navStateGnssStatus,
      navigationMode: navMode,
      positionConfidence: driftResult.confidence,
      estimatedDriftMeters: driftResult.driftMeters,
      isStationary: isZupt,
      timestamp: now
    };

    return {
      lat: this.currentLat,
      lng: this.currentLng,
      speedKmh: speedResult.speedKmh,
      headingDeg: Math.round(this.currentHeadingDeg),
      confidence: driftResult.confidence,
      driftMeters: driftResult.driftMeters,
      gnssOutageDurationSec: driftResult.outageDurationSeconds,
      isZuptActive: isZupt,
      isMapMatched,
      activeEngine,
      rawDriftMetersWithoutNaviSync: driftResult.traditionalDriftMeters,
      gnssWeight,
      imuWeight
    };
  }

  public getNavigationState(): NaviSyncNavigationState {
    return { ...this.latestNavState };
  }

  public getZuptDetector(): ZeroVelocityDetector {
    return this.zuptDetector;
  }

  public getSpeedEstimator(): NaviSyncSpeedEstimator {
    return this.speedEstimator;
  }

  public resetDrift() {
    this.driftEstimator.reset();
  }
}
