import { GNSSState, GNSSReading } from '../types/navigation';

export class GNSSLossDetector {
  private currentState: GNSSState = 'GNSS_AVAILABLE';
  private lastReadingTime: number = Date.now();
  private consecutiveMissedThreshold = 2200; // ms gap
  private accuracyDegradedThreshold = 24; // meters
  private accuracyLostThreshold = 45; // meters
  private restoringStartTime: number | null = null;
  private restoringRequiredDurationMs = 1800;
  private forcedStateOverride: GNSSState | null = null;

  public update(reading: GNSSReading | null, now = Date.now()): GNSSState {
    if (this.forcedStateOverride) {
      this.currentState = this.forcedStateOverride;
      return this.currentState;
    }

    if (!reading) {
      const elapsed = now - this.lastReadingTime;
      if (elapsed > this.consecutiveMissedThreshold * 2) {
        this.currentState = 'GNSS_LOST';
      } else if (elapsed > this.consecutiveMissedThreshold) {
        this.currentState = 'GNSS_DEGRADED';
      }
      return this.currentState;
    }

    this.lastReadingTime = now;

    // Check accuracy & signal quality
    if (reading.accuracy > this.accuracyLostThreshold) {
      this.currentState = 'GNSS_LOST';
      this.restoringStartTime = null;
    } else if (reading.accuracy > this.accuracyDegradedThreshold) {
      this.currentState = 'GNSS_DEGRADED';
      this.restoringStartTime = null;
    } else {
      // Good accuracy - check if we were lost or degraded before
      if (this.currentState === 'GNSS_LOST' || this.currentState === 'NAVISYNC_INERTIAL') {
        if (!this.restoringStartTime) {
          this.restoringStartTime = now;
          this.currentState = 'GNSS_RESTORING';
        } else if (now - this.restoringStartTime >= this.restoringRequiredDurationMs) {
          this.currentState = 'GNSS_AVAILABLE';
          this.restoringStartTime = null;
        }
      } else if (this.currentState === 'GNSS_DEGRADED') {
        this.currentState = 'GNSS_AVAILABLE';
      }
    }

    return this.currentState;
  }

  public forceState(state: GNSSState | null) {
    this.forcedStateOverride = state;
    if (state) {
      this.currentState = state;
    }
  }

  public getState(): GNSSState {
    return this.currentState;
  }

  public getLastHeartbeat(): number {
    return this.lastReadingTime;
  }
}
