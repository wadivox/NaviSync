import { IMUFilteredData, IMURawData } from '../types/navigation';

export class ZeroVelocityDetector {
  private windowSize = 8;
  private accelWindow: number[] = [];
  private gyroWindow: number[] = [];
  private isStationary = false;

  public update(raw: IMURawData, filtered: IMUFilteredData): boolean {
    const accelMag = Math.sqrt(raw.ax * raw.ax + raw.ay * raw.ay + (raw.az - 9.81) * (raw.az - 9.81));
    const gyroMag = Math.sqrt(raw.gx * raw.gx + raw.gy * raw.gy + raw.gz * raw.gz);

    this.accelWindow.push(accelMag);
    this.gyroWindow.push(gyroMag);

    if (this.accelWindow.length > this.windowSize) this.accelWindow.shift();
    if (this.gyroWindow.length > this.windowSize) this.gyroWindow.shift();

    if (this.accelWindow.length < 4) return false;

    // Calculate variance
    const accelMean = this.accelWindow.reduce((a, b) => a + b, 0) / this.accelWindow.length;
    const accelVar = this.accelWindow.reduce((sum, val) => sum + Math.pow(val - accelMean, 2), 0) / this.accelWindow.length;

    const gyroMean = this.gyroWindow.reduce((a, b) => a + b, 0) / this.gyroWindow.length;
    const gyroVar = this.gyroWindow.reduce((sum, val) => sum + Math.pow(val - gyroMean, 2), 0) / this.gyroWindow.length;

    // Conditions for ZUPT: very low dynamic variance and low filtered forward acceleration
    const lowAccelVariance = accelVar < 0.04;
    const lowGyroVariance = gyroVar < 0.03;
    const lowForwardAccel = Math.abs(filtered.forwardAccel) < 0.15;

    this.isStationary = lowAccelVariance && lowGyroVariance && lowForwardAccel;
    return this.isStationary;
  }

  public getIsStationary(): boolean {
    return this.isStationary;
  }

  public forceStationary(val: boolean) {
    this.isStationary = val;
  }
}
