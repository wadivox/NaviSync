import { IMUFilteredData } from '../types/navigation';

export class IMUSpeedEstimator {
  private currentSpeedMps = 0; // meters per second
  private lastUpdateTime = Date.now();
  private maxSpeedMps = 45; // ~160 km/h sanity clamp
  private dampingFactor = 0.994; // slight drag damping to combat drift

  public update(filtered: IMUFilteredData, isZupt: boolean, gnssSpeedMps?: number | null, now = Date.now()): number {
    const dt = Math.min(0.25, Math.max(0.01, (now - this.lastUpdateTime) / 1000));
    this.lastUpdateTime = now;

    // If ZUPT is active, immediately clamp velocity to 0
    if (isZupt) {
      this.currentSpeedMps = 0;
      return 0;
    }

    // If GNSS speed is available and reliable, use it to calibrate and pull speed
    if (gnssSpeedMps !== undefined && gnssSpeedMps !== null && gnssSpeedMps >= 0) {
      this.currentSpeedMps = 0.85 * gnssSpeedMps + 0.15 * (this.currentSpeedMps + filtered.forwardAccel * dt);
    } else {
      // GNSS-denied mode: integrate forward acceleration
      const deltaV = filtered.forwardAccel * dt;
      this.currentSpeedMps += deltaV;
      this.currentSpeedMps *= this.dampingFactor; // natural deceleration/air resistance
    }

    // Clamp non-negative for forward vehicle motion unless reversing
    if (this.currentSpeedMps < 0) this.currentSpeedMps = 0;
    if (this.currentSpeedMps > this.maxSpeedMps) this.currentSpeedMps = this.maxSpeedMps;

    return this.currentSpeedMps;
  }

  public getSpeedKmh(): number {
    return this.currentSpeedMps * 3.6;
  }

  public setSpeedMps(speedMps: number) {
    this.currentSpeedMps = Math.max(0, speedMps);
  }
}
