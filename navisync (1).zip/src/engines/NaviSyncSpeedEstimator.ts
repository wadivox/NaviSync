import { GNSSReading, IMUFilteredData, GNSSState } from '../types/navigation';

export interface SpeedEstimateResult {
  speedMps: number;
  speedKmh: number;
  speedConfidence: number; // 0.0 to 1.0
  speedSource: 'GNSS' | 'GNSS_DISPLACEMENT' | 'IMU_ESTIMATOR' | 'ZUPT_ZERO' | 'CALCULATING';
}

export class NaviSyncSpeedEstimator {
  private currentSpeedMps = 0;
  private lastUpdateTime = Date.now();
  private lastGnssLat: number | null = null;
  private lastGnssLng: number | null = null;
  private lastGnssTime: number | null = null;

  private maxSpeedMps = 55.5; // 200 km/h sanity clamp
  private maxAccelMps2 = 6.0; // Max realistic passenger car acceleration ~6 m/s^2
  private maxBrakingMps2 = 9.8; // Max emergency braking ~1g
  private naturalDragFactor = 0.992; // Natural rolling resistance & aerodynamic drag per 100ms
  private stationaryConsecutiveFrames = 0;

  /**
   * Primary update method called at 5-10+ Hz
   */
  public update(
    filteredIMU: IMUFilteredData,
    isZuptStationary: boolean,
    gnssReading: GNSSReading | null,
    gnssState: GNSSState,
    now = Date.now()
  ): SpeedEstimateResult {
    const rawDt = (now - this.lastUpdateTime) / 1000;
    const dt = Math.min(0.3, Math.max(0.01, rawDt));
    this.lastUpdateTime = now;

    // CASE 4: VEHICLE IS STATIONARY (ZUPT Active)
    if (isZuptStationary) {
      this.stationaryConsecutiveFrames++;
      // Rapid decay to absolute 0
      this.currentSpeedMps = 0;
      return {
        speedMps: 0,
        speedKmh: 0,
        speedConfidence: 0.98,
        speedSource: 'ZUPT_ZERO'
      };
    }

    this.stationaryConsecutiveFrames = 0;

    // Calculate displacement speed from successive GNSS fixes if available
    let displacementSpeedMps: number | null = null;
    if (gnssReading && this.lastGnssLat !== null && this.lastGnssLng !== null && this.lastGnssTime !== null) {
      const gnssDt = (gnssReading.timestamp - this.lastGnssTime) / 1000;
      if (gnssDt >= 0.5 && gnssDt <= 4.0) {
        const distMeters = this.calculateDistanceMeters(
          this.lastGnssLat,
          this.lastGnssLng,
          gnssReading.latitude,
          gnssReading.longitude
        );
        displacementSpeedMps = distMeters / gnssDt;
      }
    }

    if (gnssReading) {
      this.lastGnssLat = gnssReading.latitude;
      this.lastGnssLng = gnssReading.longitude;
      this.lastGnssTime = gnssReading.timestamp;
    }

    // CASE 1: RELIABLE HIGH-ACCURACY GNSS AVAILABLE
    if (gnssState === 'GNSS_AVAILABLE' && gnssReading) {
      const rawGnssSpeed = gnssReading.speed;

      if (rawGnssSpeed !== null && rawGnssSpeed !== undefined && !isNaN(rawGnssSpeed) && rawGnssSpeed >= 0) {
        // GNSS reported Doppler speed is very accurate (0.1 m/s)
        // Check sanity against sudden impossible jumps
        const maxAllowedDeltaV = (rawGnssSpeed > this.currentSpeedMps ? this.maxAccelMps2 : this.maxBrakingMps2) * Math.max(1, dt * 3);
        let blendedSpeed = rawGnssSpeed;

        if (this.currentSpeedMps > 1.0 && Math.abs(rawGnssSpeed - this.currentSpeedMps) > maxAllowedDeltaV) {
          // Rate-limit jump
          blendedSpeed = this.currentSpeedMps + Math.sign(rawGnssSpeed - this.currentSpeedMps) * maxAllowedDeltaV;
        }

        // Slight blend with IMU forward integration for smooth 10Hz responsiveness between 1Hz GPS ticks
        const imuDeltaV = (filteredIMU.vibrationAnomaly ? 0 : filteredIMU.forwardAccel) * dt;
        this.currentSpeedMps = 0.88 * blendedSpeed + 0.12 * (this.currentSpeedMps + imuDeltaV);

        if (this.currentSpeedMps < 0.2) this.currentSpeedMps = 0;

        return {
          speedMps: this.currentSpeedMps,
          speedKmh: Math.round(this.currentSpeedMps * 3.6 * 10) / 10,
          speedConfidence: 0.95,
          speedSource: 'GNSS'
        };
      } else if (displacementSpeedMps !== null && displacementSpeedMps >= 0) {
        // Fallback to displacement speed
        this.currentSpeedMps = 0.75 * displacementSpeedMps + 0.25 * this.currentSpeedMps;
        return {
          speedMps: this.currentSpeedMps,
          speedKmh: Math.round(this.currentSpeedMps * 3.6 * 10) / 10,
          speedConfidence: 0.84,
          speedSource: 'GNSS_DISPLACEMENT'
        };
      }
    }

    // CASE 2: GNSS DEGRADED OR RESTORING
    if (gnssState === 'GNSS_DEGRADED' || gnssState === 'GNSS_RESTORING') {
      const rawGnssSpeed = gnssReading?.speed;
      const imuDeltaV = (filteredIMU.vibrationAnomaly ? 0 : filteredIMU.forwardAccel) * dt;
      const deadReckonedSpeed = (this.currentSpeedMps + imuDeltaV) * this.naturalDragFactor;

      if (rawGnssSpeed !== null && rawGnssSpeed !== undefined && rawGnssSpeed >= 0) {
        // Balanced fusion between degraded GNSS and IMU integration
        this.currentSpeedMps = 0.55 * rawGnssSpeed + 0.45 * deadReckonedSpeed;
        return {
          speedMps: this.currentSpeedMps,
          speedKmh: Math.round(this.currentSpeedMps * 3.6 * 10) / 10,
          speedConfidence: 0.76,
          speedSource: 'GNSS'
        };
      } else {
        this.currentSpeedMps = deadReckonedSpeed;
        return {
          speedMps: this.currentSpeedMps,
          speedKmh: Math.round(this.currentSpeedMps * 3.6 * 10) / 10,
          speedConfidence: 0.70,
          speedSource: 'IMU_ESTIMATOR'
        };
      }
    }

    // CASE 3: GNSS COMPLETELY LOST (INERTIAL DEAD RECKONING)
    // Dynamic physics model with forward acceleration integration + non-holonomic limits
    let forwardAccel = filteredIMU.forwardAccel;

    // Sanity check: Reject anomalous vibration spikes (e.g. pothole shock)
    if (filteredIMU.vibrationAnomaly || filteredIMU.noiseLevel > 4.0) {
      forwardAccel = 0; // Don't falsely accelerate on potholes
    } else {
      // Clamp acceleration to realistic vehicle capability
      forwardAccel = Math.max(-this.maxBrakingMps2, Math.min(this.maxAccelMps2, forwardAccel));
    }

    // Integrate forward acceleration: v = v0 + a * dt
    let nextSpeed = this.currentSpeedMps + forwardAccel * dt;

    // Apply natural rolling resistance & drag
    nextSpeed *= this.naturalDragFactor;

    // Zero threshold clamp
    if (nextSpeed < 0.25) {
      nextSpeed = 0;
    }

    if (nextSpeed > this.maxSpeedMps) {
      nextSpeed = this.maxSpeedMps;
    }

    this.currentSpeedMps = nextSpeed;

    return {
      speedMps: this.currentSpeedMps,
      speedKmh: Math.round(this.currentSpeedMps * 3.6 * 10) / 10,
      speedConfidence: Math.max(0.55, 0.88 - Math.min(0.35, (now - (this.lastGnssTime || now)) / 45000)),
      speedSource: 'IMU_ESTIMATOR'
    };
  }

  public setSpeedMps(mps: number) {
    this.currentSpeedMps = Math.max(0, mps);
  }

  public getSpeedKmh(): number {
    return this.currentSpeedMps * 3.6;
  }

  public reset() {
    this.currentSpeedMps = 0;
    this.lastGnssLat = null;
    this.lastGnssLng = null;
    this.lastGnssTime = null;
    this.lastUpdateTime = Date.now();
  }

  private calculateDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const toRad = (deg: number) => (deg * Math.PI) / 180;
    const R = 6371000; // meters
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }
}

export const globalNaviSyncSpeedEstimator = new NaviSyncSpeedEstimator();
