import { RouteStep } from '../types/navigation';

export class GNSSRiskPredictor {
  // Keywords indicating signal obstruction
  private riskKeywords = ['tunnel', 'underground', 'underpass', 'subway', 'metro', 'flyover', 'basement'];

  public analyzeRoute(steps: RouteStep[]): {
    totalRiskZones: number;
    riskDetails: { stepIndex: number; name: string; reason: string; level: 'HIGH' | 'MEDIUM' }[];
  } {
    const riskDetails: { stepIndex: number; name: string; reason: string; level: 'HIGH' | 'MEDIUM' }[] = [];

    steps.forEach((step, idx) => {
      const text = (step.streetName + ' ' + step.instruction).toLowerCase();
      for (const kw of this.riskKeywords) {
        if (text.includes(kw)) {
          riskDetails.push({
            stepIndex: idx,
            name: step.streetName || `Segment #${idx + 1}`,
            reason: `Potential signal attenuation detected (${kw.toUpperCase()})`,
            level: kw === 'tunnel' || kw === 'underground' ? 'HIGH' : 'MEDIUM'
          });
          break;
        }
      }
    });

    return {
      totalRiskZones: riskDetails.length,
      riskDetails
    };
  }
}
