export class DriftEstimator {
  private outageStartTime: number | null = null;
  private totalDistanceTravelledMeters = 0;
  private accumulatedDriftMeters = 0;
  private traditionalUnconstrainedDriftMeters = 0;

  public update(
    isGNSSLost: boolean,
    isZupt: boolean,
    deltaMeters: number,
    isMapMatched: boolean,
    now = Date.now()
  ): {
    driftMeters: number;
    driftPercentage: number;
    confidence: number;
    outageDurationSeconds: number;
    traditionalDriftMeters: number;
  } {
    this.totalDistanceTravelledMeters += Math.max(0, deltaMeters);

    if (isGNSSLost) {
      if (!this.outageStartTime) {
        this.outageStartTime = now;
      }
      const outageDurationSeconds = (now - this.outageStartTime) / 1000;

      // Unconstrained traditional DR error: grows quadratically with time (~0.04 * t^2) + bias leakage
      // At 60 seconds without ZUPT/map matching, traditional DR drifts > 90-140m
      this.traditionalUnconstrainedDriftMeters += (isZupt ? 0.35 : 0.85) * (deltaMeters * 0.12 + 0.05);

      // NaviSync constrained drift:
      // When ZUPT is active: zero drift accumulation
      // When Map-matched: lateral drift eliminated, longitudinal drift bounded to <1.5% distance
      if (isZupt) {
        // Standstill: no drift added!
      } else if (isMapMatched) {
        this.accumulatedDriftMeters += deltaMeters * 0.012; // ~1.2% error
      } else {
        this.accumulatedDriftMeters += deltaMeters * 0.038; // ~3.8% error without road match
      }

      // Dynamic confidence calculation:
      // Starts at 0.95, degrades gently with outage duration and distance, but protected by ZUPT & Map Matching
      const timePenalty = Math.min(0.35, Math.log10(1 + outageDurationSeconds / 45) * 0.35);
      const matchBonus = isMapMatched ? 0.08 : -0.05;
      const zuptBonus = isZupt ? 0.05 : 0.0;
      const confidence = Math.max(0.42, Math.min(0.96, 0.95 - timePenalty + matchBonus + zuptBonus));

      const driftPercentage = this.totalDistanceTravelledMeters > 0
        ? (this.accumulatedDriftMeters / this.totalDistanceTravelledMeters) * 100
        : 0;

      return {
        driftMeters: Math.round(this.accumulatedDriftMeters * 10) / 10,
        driftPercentage: Math.min(100, Math.round(driftPercentage * 10) / 10),
        confidence: Math.round(confidence * 100) / 100,
        outageDurationSeconds: Math.round(outageDurationSeconds),
        traditionalDriftMeters: Math.round(this.traditionalUnconstrainedDriftMeters * 10) / 10
      };
    } else {
      // GNSS is active
      this.outageStartTime = null;
      this.accumulatedDriftMeters = Math.max(0, this.accumulatedDriftMeters * 0.85 - 0.5); // smoothly recovers
      this.traditionalUnconstrainedDriftMeters = 0;

      return {
        driftMeters: 0,
        driftPercentage: 0,
        confidence: 0.98,
        outageDurationSeconds: 0,
        traditionalDriftMeters: 0
      };
    }
  }

  public reset() {
    this.outageStartTime = null;
    this.totalDistanceTravelledMeters = 0;
    this.accumulatedDriftMeters = 0;
    this.traditionalUnconstrainedDriftMeters = 0;
  }

  public getDriftMeters(): number {
    return this.accumulatedDriftMeters;
  }
}
