export class NHCConstraintEngine {
  private maxTurnRateDegPerSec = 45; // Kinematic turn limit for typical road vehicle at speed

  public applyConstraints(
    headingDeg: number,
    yawRateDegPerSec: number,
    speedMps: number,
    dt: number
  ): { constrainedHeadingDeg: number; lateralSlipErrorMeters: number } {
    // 1. Angular rate clamp
    const clampedYawRate = Math.max(-this.maxTurnRateDegPerSec, Math.min(this.maxTurnRateDegPerSec, yawRateDegPerSec));
    
    // 2. High speed reduces maximum yaw rate (cannot spin 40 deg/sec at 100 km/h)
    const speedFactor = speedMps > 15 ? 15 / speedMps : 1.0;
    const effectiveYawRate = clampedYawRate * speedFactor;

    let newHeading = (headingDeg + effectiveYawRate * dt) % 360;
    if (newHeading < 0) newHeading += 360;

    // Lateral slip assumption: v_lateral = 0, so lateral displacement drift is bounded
    const lateralSlipErrorMeters = 0.02 * dt; // minimal residual tire drift

    return {
      constrainedHeadingDeg: newHeading,
      lateralSlipErrorMeters
    };
  }
}
