export class MapMatchingEngine {
  // Finds closest segment on a polyline and projects point [lat, lng]
  public matchToRoute(
    currentLat: number,
    currentLng: number,
    headingDeg: number,
    routeCoordinates: [number, number][],
    maxSearchRadiusMeters = 40
  ): { matchedLat: number; matchedLng: number; matchedHeading: number; isMatched: boolean; distanceToRoadMeters: number } {
    if (!routeCoordinates || routeCoordinates.length < 2) {
      return { matchedLat: currentLat, matchedLng: currentLng, matchedHeading: headingDeg, isMatched: false, distanceToRoadMeters: 0 };
    }

    let minDistance = Infinity;
    let bestPoint: [number, number] = [currentLat, currentLng];
    let bestHeading = headingDeg;

    for (let i = 0; i < routeCoordinates.length - 1; i++) {
      const p1 = routeCoordinates[i];
      const p2 = routeCoordinates[i + 1];

      const proj = this.projectPointOntoSegment(currentLat, currentLng, p1[0], p1[1], p2[0], p2[1]);
      const dist = this.haversineMeters(currentLat, currentLng, proj.lat, proj.lng);

      if (dist < minDistance) {
        minDistance = dist;
        bestPoint = [proj.lat, proj.lng];
        
        // Calculate segment heading
        const segmentHeading = this.calculateBearing(p1[0], p1[1], p2[0], p2[1]);
        
        // If our heading is roughly in the same direction (< 60 deg difference)
        const angleDiff = Math.abs((headingDeg - segmentHeading + 180) % 360 - 180);
        if (angleDiff < 60) {
          bestHeading = 0.8 * segmentHeading + 0.2 * headingDeg;
        } else {
          bestHeading = headingDeg;
        }
      }
    }

    if (minDistance <= maxSearchRadiusMeters) {
      // Soft snap: blend current position with road centerline
      const snapFactor = minDistance < 8 ? 0.9 : 0.6;
      const matchedLat = currentLat * (1 - snapFactor) + bestPoint[0] * snapFactor;
      const matchedLng = currentLng * (1 - snapFactor) + bestPoint[1] * snapFactor;
      return {
        matchedLat,
        matchedLng,
        matchedHeading: bestHeading,
        isMatched: true,
        distanceToRoadMeters: minDistance
      };
    }

    return {
      matchedLat: currentLat,
      matchedLng: currentLng,
      matchedHeading: headingDeg,
      isMatched: false,
      distanceToRoadMeters: minDistance
    };
  }

  private projectPointOntoSegment(
    pLat: number,
    pLng: number,
    aLat: number,
    aLng: number,
    bLat: number,
    bLng: number
  ): { lat: number; lng: number } {
    const dx = bLng - aLng;
    const dy = bLat - aLat;
    if (dx === 0 && dy === 0) return { lat: aLat, lng: aLng };

    const t = ((pLng - aLng) * dx + (pLat - aLat) * dy) / (dx * dx + dy * dy);
    const clampedT = Math.max(0, Math.min(1, t));

    return {
      lat: aLat + clampedT * dy,
      lng: aLng + clampedT * dx
    };
  }

  public haversineMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371000;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  public calculateBearing(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const y = Math.sin(((lon2 - lon1) * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180);
    const x =
      Math.cos((lat1 * Math.PI) / 180) * Math.sin((lat2 * Math.PI) / 180) -
      Math.sin((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.cos(((lon2 - lon1) * Math.PI) / 180);
    const deg = (Math.atan2(y, x) * 180) / Math.PI;
    return (deg + 360) % 360;
  }
}
