import { globalSensorCapabilityManager } from '../services/SensorCapabilityManager';
import { VehicleAlignment } from '../types/navigation';

export class VehicleAlignmentEngine {
  private isCalibrating = false;
  private samples: { gnssCourse: number; deviceHeading: number; pitch: number; roll: number }[] = [];
  private currentAlignment: VehicleAlignment;

  constructor() {
    this.currentAlignment = globalSensorCapabilityManager.getVehicleAlignment();
    globalSensorCapabilityManager.subscribeAlignment((alignment) => {
      this.currentAlignment = alignment;
    });
  }

  public startCalibration() {
    this.isCalibrating = true;
    this.samples = [];
  }

  public addSample(gnssCourse: number, deviceHeading: number, pitch = 0, roll = 0, speedKmh = 0) {
    if (!this.isCalibrating) return;
    // Only accept samples if vehicle is moving fast enough for reliable GNSS course (> 12 km/h)
    if (speedKmh < 12) return;

    this.samples.push({ gnssCourse, deviceHeading, pitch, roll });

    // After 10 quality samples (~2-3 seconds of driving straight), finalize
    if (this.samples.length >= 10) {
      this.finalizeCalibration();
    }
  }

  public getCalibrationProgress(): { isCalibrating: boolean; progressPercent: number; samplesCount: number } {
    return {
      isCalibrating: this.isCalibrating,
      progressPercent: Math.min(100, Math.round((this.samples.length / 10) * 100)),
      samplesCount: this.samples.length
    };
  }

  public finalizeCalibration(): VehicleAlignment {
    this.isCalibrating = false;
    if (this.samples.length === 0) {
      return this.currentAlignment;
    }

    // Circular mean calculation for yaw difference
    let sinSum = 0;
    let cosSum = 0;
    let pitchSum = 0;
    let rollSum = 0;

    for (const sample of this.samples) {
      // difference = gnssCourse - deviceHeading
      const diffRad = ((sample.gnssCourse - sample.deviceHeading) * Math.PI) / 180;
      sinSum += Math.sin(diffRad);
      cosSum += Math.cos(diffRad);
      pitchSum += sample.pitch;
      rollSum += sample.roll;
    }

    const avgDiffRad = Math.atan2(sinSum, cosSum);
    let avgYawOffsetDeg = Math.round((avgDiffRad * 180) / Math.PI);
    const avgPitchOffset = Math.round(pitchSum / this.samples.length);
    const avgRollOffset = Math.round(rollSum / this.samples.length);

    const newAlignment: VehicleAlignment = {
      deviceVehicleYawOffset: avgYawOffsetDeg,
      deviceVehiclePitchOffset: avgPitchOffset,
      deviceVehicleRollOffset: avgRollOffset,
      isCalibrated: true,
      lastCalibratedAt: Date.now()
    };

    globalSensorCapabilityManager.setVehicleAlignment(newAlignment);
    return newAlignment;
  }

  public cancelCalibration() {
    this.isCalibrating = false;
    this.samples = [];
  }

  /**
   * Applies vehicle mounting offset:
   * Vehicle Heading = Device Heading + Vehicle Alignment Offset
   */
  public applyAlignment(deviceHeadingDeg: number): number {
    const yawOffset = this.currentAlignment.deviceVehicleYawOffset || 0;
    return (deviceHeadingDeg + yawOffset + 360) % 360;
  }

  public getAlignment(): VehicleAlignment {
    return this.currentAlignment;
  }

  public isCalibrated(): boolean {
    return this.currentAlignment?.isCalibrated || false;
  }
}

export const globalVehicleAlignmentEngine = new VehicleAlignmentEngine();
