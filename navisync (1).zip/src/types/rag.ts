export interface RAGDocument {
  id: string;
  title: string;
  category: 'architecture' | 'navigation' | 'algorithms' | 'dataset' | 'emergency' | 'user_help';
  content: string;
  keywords: string[];
  version: string;
  author: string;
  updatedAt: string;
}

export interface RAGSearchResult {
  documentId: string;
  title: string;
  category: string;
  snippet: string;
  score: number;
}

export interface CopilotMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  sources?: { title: string; category: string; snippet?: string }[];
  toolCalls?: { name: string; args: Record<string, any>; result?: any }[];
  isSimulatedFallback?: boolean;
}

export interface NavigationContextPayload {
  location: {
    latitude: number;
    longitude: number;
    accuracy: number;
  };
  destination?: {
    name: string;
    lat: number;
    lng: number;
  } | null;
  route?: {
    summary: string;
    distanceKm: number;
    durationMinutes: number;
    currentStepIndex: number;
    nextManeuver: string;
    distanceToNextManeuverMeters: number;
  } | null;
  gnss: {
    state: string;
    accuracyMeters: number;
    isLost: boolean;
  };
  imu: {
    available: boolean;
    forwardAccel: number;
    filteredQuality: number;
  };
  navigation: {
    state: string;
    confidencePercent: number;
    driftMeters: number;
    outageDurationSeconds: number;
    zuptActive: boolean;
    speedKmh: number;
  };
  offline: boolean;
  language: string;
  travelHistory?: {
    totalTrips: number;
    totalDistanceKm: number;
    avgSpeedKmh: number;
    longestTripKm: number;
    recentSummary?: string;
  };
}
