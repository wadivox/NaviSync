import { GeoCoordinate } from './navigation';

export type ReplayPhase = 'GNSS_AVAILABLE' | 'GNSS_LOST' | 'DEAD_RECKONING' | 'GNSS_RESTORED';

export interface SIHReplayFrame {
  frameIndex: number;
  timeSec: number;
  timeFormatted: string; // e.g. "00:45"
  
  // 1. Reference / Ground Truth (True vehicle state)
  groundTruth: {
    lat: number;
    lng: number;
    speedKmh: number;
    headingDeg: number;
  };

  // 2. Raw GNSS Receiver state
  gnssReading: {
    lat: number | null;
    lng: number | null;
    speedKmh: number | null;
    headingDeg: number | null;
    status: 'AVAILABLE' | 'DEGRADED' | 'LOST' | 'RESTORED';
    hdop: number | null;
    satellites: number;
  };

  // 3. Raw IMU Sensor Feed
  imu: {
    ax: number; // m/s^2 forward/lateral
    ay: number;
    az: number;
    gx: number; // deg/s yaw rate
    gy: number;
    gz: number;
    isStationary: boolean;
  };

  // 4. Baseline Conventional Dead Reckoning (Pure double-integration without NaviSync corrections)
  baselineDR: {
    lat: number;
    lng: number;
    speedKmh: number;
    headingDeg: number;
    errorMeters: number;
    accumulatedDriftPct: number;
  };

  // 5. NaviSync Pipeline (IMU + AI Motion Filter + ZUPT + EKF + Map Matching + Non-Holonomic Constraints)
  navisync: {
    lat: number;
    lng: number;
    speedKmh: number;
    headingDeg: number;
    errorMeters: number;
    accumulatedDriftPct: number;
    confidencePct: number;
    driftMeters: number;
    navigationMode: 'GNSS + INS' | 'NaviSync DEAD RECKONING' | 'GNSS + INS FUSION';
    zuptActive: boolean;
    aiMotionActive: boolean;
    mapMatchingActive: boolean;
  };

  phase: ReplayPhase;
  outageElapsedSec: number;
  locationName: string;
}

export interface SIHJourneySummary {
  routeName: string;
  startLocation: string;
  destinationLocation: string;
  distanceKm: number;
  durationMinutes: number;
  averageSpeedKmh: number;
  maxSpeedKmh: number;
  gnssAvailabilityPct: number;
  gnssOutageSeconds: number;
  outageStartIndex: number;
  outageEndIndex: number;
}

export interface SIHBenchmarkMetrics {
  distanceTravelledKm: number;
  durationMin: number;
  averageSpeedKmh: number;
  maxSpeedKmh: number;
  gnssOutageSec: number;

  // Baseline Conventional DR
  baselineFinalErrorM: number;
  baselineRmseM: number;
  baselineDriftPct: number;

  // NaviSync Engine
  navisyncFinalErrorM: number;
  navisyncRmseM: number;
  navisyncDriftPct: number;

  // Comparative Improvement
  improvementPct: number;
  sihTargetPct: number; // 10%
  isWithinTarget: boolean;
}

export interface SIHExperimentRecord {
  id: string;
  date: string;
  timestamp: number;
  routeName: string;
  startLocation: string;
  endLocation: string;
  distanceKm: number;
  durationMinutes: number;
  outageDurationSec: number;
  averageSpeedKmh: number;
  maxSpeedKmh: number;
  
  baselineErrorM: number;
  navisyncErrorM: number;
  baselineDriftPct: number;
  navisyncDriftPct: number;
  baselineRmseM: number;
  navisyncRmseM: number;
  improvementPct: number;
  sihTargetMet: boolean;
}
