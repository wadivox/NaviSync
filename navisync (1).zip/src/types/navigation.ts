export type GNSSState = 
  | 'GNSS_AVAILABLE'
  | 'GNSS_DEGRADED'
  | 'GNSS_LOST'
  | 'GNSS_RESTORING'
  | 'NAVISYNC_INERTIAL';

export type NavigationMode = 'driving' | 'two_wheeler' | 'walking' | 'cycling';

export interface GeoCoordinate {
  lat: number;
  lng: number;
  altitude?: number;
}

export interface GNSSReading {
  latitude: number;
  longitude: number;
  altitude: number | null;
  accuracy: number; // in meters
  speed: number | null; // in m/s
  heading: number | null; // in degrees 0-360
  timestamp: number;
  isSimulated?: boolean;
}

export interface IMURawData {
  ax: number; // m/s^2 forward/accel
  ay: number; // m/s^2 lateral
  az: number; // m/s^2 vertical (includes gravity ~9.81)
  gx: number; // rad/s pitch rate
  gy: number; // rad/s roll rate
  gz: number; // rad/s yaw rate
  timestamp: number;
  isSimulated?: boolean;
}

export interface IMUFilteredData {
  axFiltered: number;
  ayFiltered: number;
  azFiltered: number;
  pitch: number; // degrees
  roll: number;
  yaw: number;
  forwardAccel: number; // vehicle forward acceleration without gravity
  lateralAccel: number; // lateral centripetal acceleration
  noiseLevel: number;
  vibrationAnomaly: boolean;
  filterType: 'AI_TCN_PROTOTYPE' | 'EXPONENTIAL_BANDPASS';
}

export interface FusionState {
  lat: number;
  lng: number;
  speedKmh: number;
  headingDeg: number;
  confidence: number; // 0.0 - 1.0 (e.g. 0.96)
  driftMeters: number;
  gnssOutageDurationSec: number;
  isZuptActive: boolean;
  isMapMatched: boolean;
  activeEngine: 'GNSS' | 'NAVISYNC_INERTIAL' | 'FUSED';
  rawDriftMetersWithoutNaviSync: number; // Traditional unconstrained DR comparison
  gnssWeight: number; // e.g. 0.0 to 1.0
  imuWeight: number;
}

export interface RouteStep {
  id: string;
  instruction: string;
  maneuver: 'turn-left' | 'turn-right' | 'continue' | 'slight-left' | 'slight-right' | 'u-turn' | 'arrive' | 'depart' | 'roundabout';
  distanceMeters: number;
  durationSeconds: number;
  startCoordinate: GeoCoordinate;
  endCoordinate: GeoCoordinate;
  streetName: string;
  gnssRiskLevel?: 'LOW' | 'MEDIUM' | 'HIGH';
  gnssRiskReason?: string;
}

export interface RouteOption {
  id: string;
  name: string;
  summary: string;
  distanceKm: number;
  durationMinutes: number;
  trafficLevel: 'LOW' | 'MODERATE' | 'HEAVY' | 'UNAVAILABLE';
  isFastest?: boolean;
  isEco?: boolean;
  isShortest?: boolean;
  coordinates: [number, number][]; // [lat, lng] array
  steps: RouteStep[];
  tunnelSegments?: { startIdx: number; endIdx: number; name: string }[];
}

export interface PlaceItem {
  id: string;
  name: string;
  category: 'restaurant' | 'fuel' | 'ev_charging' | 'hospital' | 'pharmacy' | 'parking' | 'police' | 'poi';
  lat: number;
  lng: number;
  address: string;
  rating?: number;
  reviewCount?: number;
  distanceKm?: number;
  isOpenNow?: boolean;
  phone?: string;
  website?: string;
  source: 'REAL' | 'DEMO';
}

export interface EvaluatorScenario {
  id: string;
  label: string;
  description: string;
  type: 'BLACKOUT' | 'TRAFFIC_STOP' | 'RECONNECT' | 'TUNNEL' | 'UNDERGROUND' | 'URBAN_CANYON' | 'POTHOLE';
}

/**
 * Authoritative NaviSync Unified Navigation State (Single Source of Truth)
 * Requirement 31: One authoritative navigation state consumed by Map, Speed, Arrow, Dashboard, Recorder, AI.
 */
export interface NaviSyncNavigationState {
  latitude: number;
  longitude: number;
  accuracy: number; // in meters
  altitude?: number | null;

  heading: number; // 0° = North, 90° = East, 180° = South, 270° = West
  headingConfidence: number; // 0.0 - 1.0 (e.g. 0.95)
  headingSource: 'GNSS_COURSE' | 'FUSED_IMU' | 'COMPASS_DEVICE' | 'LAST_RELIABLE';

  speedMps: number;
  speedKmh: number;
  speedConfidence: number; // 0.0 - 1.0 (e.g. 0.94)
  speedSource: 'GNSS' | 'GNSS_DISPLACEMENT' | 'IMU_ESTIMATOR' | 'ZUPT_ZERO' | 'CALCULATING';

  gnssStatus: 'AVAILABLE' | 'DEGRADED' | 'LOST' | 'RESTORED';
  navigationMode: 'GNSS' | 'FUSED' | 'DEAD_RECKONING';

  positionConfidence: number; // 0.0 - 1.0
  estimatedDriftMeters: number;
  isStationary: boolean;
  timestamp: number;

  isDemoScenario?: boolean;
  scenarioName?: string;
}

export type SensorStatusType = 'AVAILABLE' | 'ACTIVE' | 'DENIED' | 'PROMPT' | 'UNAVAILABLE' | 'UNSUPPORTED';

export interface SensorCapabilityReport {
  geolocation: SensorStatusType;
  deviceOrientation: SensorStatusType;
  deviceMotion: SensorStatusType;
  accelerometer: SensorStatusType;
  gyroscope: SensorStatusType;
  magnetometer: SensorStatusType;
  highAccuracyGeo: boolean;
  hasOrientationPermission: boolean;
  needsUserGesture: boolean;
  lastUpdated: number;
}

export interface VehicleAlignment {
  deviceVehicleYawOffset: number; // in degrees (-180 to 180)
  deviceVehiclePitchOffset: number; // in degrees
  deviceVehicleRollOffset: number; // in degrees
  isCalibrated: boolean;
  lastCalibratedAt?: number;
}

export interface GNSSOutageSegment {
  startTime: number;
  endTime?: number;
  durationSeconds: number;
  startCoordinate: [number, number];
  endCoordinate?: [number, number];
  maxDriftMeters: number;
  recoveredConfidence: number;
  cause: 'TUNNEL' | 'UNDERGROUND' | 'URBAN_CANYON' | 'SIGNAL_DROP' | 'SIMULATED_TEST';
}

export interface TravelTrajectoryPoint {
  lat: number;
  lng: number;
  speedKmh: number;
  heading: number;
  gnssStatus: 'AVAILABLE' | 'DEGRADED' | 'LOST' | 'RESTORED';
  confidence: number;
  timestamp: number;
}

export interface TravelHistoryRecord {
  id: string;
  startTime: number;
  endTime: number;
  dateFormatted: string;

  startLocation: string;
  endLocation: string;
  startCoordinate: GeoCoordinate;
  endCoordinate: GeoCoordinate;

  routeCoordinates: [number, number][]; // [lat, lng] array of traveled trajectory
  trajectoryPoints?: TravelTrajectoryPoint[];

  distanceKm: number;
  durationMinutes: number;
  stoppedDurationSeconds: number;

  averageSpeedKmh: number;
  maxSpeedKmh: number;

  navigationMode: NavigationMode;

  gnssOutageDurationSeconds: number;
  gnssOutageSegments: GNSSOutageSegment[];
  gnssAvailabilityPercentage: number;
  drPercentage: number;

  estimatedDriftMeters: number;
  overallConfidence: number;

  routeName?: string;
  completedNaturally: boolean;

  // Backwards-compatible aliases
  timestamp?: number;
  destinationName?: string;
  destinationCoord?: GeoCoordinate;
  mode?: NavigationMode;
}
