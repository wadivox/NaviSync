import React, { useState, useRef, useEffect } from 'react';
import { CopilotMessage, NavigationContextPayload } from '../../types/rag';
import { MessageSquare, X, Send, Sparkles, BookOpen, AlertTriangle, ShieldCheck, ChevronDown, ChevronUp, Bot } from 'lucide-react';

interface NaviCopilotProps {
  contextPayload: NavigationContextPayload;
  isOpen: boolean;
  onToggleOpen: () => void;
}

export const NaviCopilot: React.FC<NaviCopilotProps> = ({
  contextPayload,
  isOpen,
  onToggleOpen
}) => {
  const [messages, setMessages] = useState<CopilotMessage[]>([
    {
      id: 'welcome-msg',
      role: 'assistant',
      content: `Hello, I'm NaviSync — your intelligent navigation assistant. I am grounded in NaviSync's inertial telemetry, ZUPT sensors, and RAG knowledge base. Ask me about your route, GNSS loss resilience, drift, or nearby places.`,
      timestamp: Date.now(),
      sources: [{ title: 'NaviSync 4-System Architecture', category: 'architecture' }]
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [expandedSourceIndex, setExpandedSourceIndex] = useState<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickPrompts = [
    'Why did GPS disappear?',
    'How confident are you about my current location?',
    'What is ZUPT and why is it active?',
    'How much drift has accumulated?',
    'Find coffee near me'
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isTyping) return;
    const userMsg: CopilotMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text.trim(),
      timestamp: Date.now()
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMsg.content,
          context: contextPayload,
          history: messages.slice(-4)
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const botMsg: CopilotMessage = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        content: data.content,
        timestamp: Date.now(),
        sources: data.sources,
        isSimulatedFallback: data.isSimulatedFallback
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.warn('Navi assistant request error:', err);
      // Fallback local grounded answer
      const botMsg: CopilotMessage = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        content: `NaviSync Intelligence Status: GNSS state is ${contextPayload.gnss.state}. Speed is ${contextPayload.navigation.speedKmh} km/h with ${contextPayload.navigation.confidencePercent}% positioning confidence. (Navigation continues uninterrupted).`,
        timestamp: Date.now(),
        isSimulatedFallback: true
      };
      setMessages((prev) => [...prev, botMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <>
      {/* Floating Copilot Launcher Button */}
      {!isOpen && (
        <button
          id="btn-open-navi-copilot"
          onClick={onToggleOpen}
          className="fixed bottom-6 right-6 z-40 bg-gradient-to-tr from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white p-3.5 rounded-2xl shadow-2xl shadow-black/80 flex items-center gap-2 border border-blue-400/40 backdrop-blur-md transition-all group"
        >
          <div className="relative">
            <Bot className="w-5 h-5 text-white" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#050505] animate-pulse"></span>
          </div>
          <span className="text-xs font-bold tracking-wide pr-1">NaviSync AI</span>
        </button>
      )}

      {/* Floating Copilot Panel */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-2rem)] h-[520px] bg-[#0d0d0d]/95 border border-[#1f1f1f] rounded-2xl shadow-2xl shadow-black/95 flex flex-col backdrop-blur-md overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="p-3.5 bg-[#080808]/90 border-b border-[#1a1a1a] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-blue-600/15 border border-blue-500/30 text-blue-400 flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  <span>NaviSync AI</span>
                  <span className="text-[10px] bg-blue-950/60 text-blue-300 border border-blue-800/60 px-1.5 py-0.2 rounded font-mono">
                    RAG Grounded
                  </span>
                </div>
                <div className="text-[10px] text-[#8e8e8e]">
                  Live state: {contextPayload.gnss.state} • Conf {contextPayload.navigation.confidencePercent}%
                </div>
              </div>
            </div>
            <button
              id="btn-close-navi-copilot"
              onClick={onToggleOpen}
              className="p-1 rounded-lg text-[#8e8e8e] hover:text-white hover:bg-[#161616] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-3.5 overflow-y-auto flex flex-col gap-3 text-xs">
            {messages.map((m, idx) => {
              const isUser = m.role === 'user';
              return (
                <div
                  key={m.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} max-w-[92%] ${
                    isUser ? 'self-end' : 'self-start'
                  }`}
                >
                  <div
                    className={`p-3 rounded-2xl ${
                      isUser
                        ? 'bg-blue-600 text-white rounded-br-xs shadow-md shadow-blue-600/30'
                        : 'bg-[#141414] border border-[#1f1f1f] text-[#e0e0e0] rounded-bl-xs shadow-md'
                    }`}
                  >
                    <p className="leading-relaxed whitespace-pre-wrap">{m.content}</p>

                    {/* RAG Source Citations */}
                    {m.sources && m.sources.length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-[#1f1f1f]">
                        <div
                          onClick={() =>
                            setExpandedSourceIndex(expandedSourceIndex === idx ? null : idx)
                          }
                          className="text-[10px] text-blue-400 flex items-center gap-1 cursor-pointer hover:underline font-medium"
                        >
                          <BookOpen className="w-3 h-3 text-blue-400" />
                          <span>Sources ({m.sources.length} grounded documents)</span>
                          {expandedSourceIndex === idx ? (
                            <ChevronUp className="w-3 h-3" />
                          ) : (
                            <ChevronDown className="w-3 h-3" />
                          )}
                        </div>

                        {expandedSourceIndex === idx && (
                          <div className="mt-1 flex flex-col gap-1 pl-1">
                            {m.sources.map((s, sIdx) => (
                              <div
                                key={sIdx}
                                className="text-[10px] text-[#8e8e8e] bg-[#0a0a0a] p-1.5 rounded border border-[#1a1a1a]"
                              >
                                <span className="font-semibold text-[#e0e0e0]">• {s.title}</span>
                                <span className="text-[#666666] ml-1">({s.category})</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  <span className="text-[9px] text-[#666666] mt-1 px-1">
                    {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              );
            })}

            {isTyping && (
              <div className="self-start flex items-center gap-2 text-[#8e8e8e] text-xs bg-[#141414] border border-[#1f1f1f] px-3 py-2 rounded-xl">
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping"></span>
                <span>NaviSync is reasoning over navigation telemetry...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Questions Chips */}
          <div className="p-2 border-t border-[#1a1a1a] bg-[#080808]/60 overflow-x-auto flex gap-1.5 scrollbar-none">
            {quickPrompts.map((qp, qIdx) => (
              <button
                key={qIdx}
                onClick={() => handleSendMessage(qp)}
                className="text-[11px] text-[#a0a0a0] bg-[#141414] hover:bg-[#1a1a1a] hover:text-white border border-[#1f1f1f] px-2.5 py-1 rounded-lg shrink-0 whitespace-nowrap transition-colors"
              >
                {qp}
              </button>
            ))}
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputText);
            }}
            className="p-3 bg-[#080808] border-t border-[#1a1a1a] flex items-center gap-2"
          >
            <input
              id="input-navi-query"
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask NaviSync about route, GNSS loss, or places..."
              className="flex-1 bg-[#121212] border border-[#1f1f1f] rounded-xl px-3 py-2 text-xs text-[#e0e0e0] placeholder:text-[#666666] outline-none focus:border-blue-500/70"
            />
            <button
              id="btn-send-navi-query"
              type="submit"
              disabled={!inputText.trim() || isTyping}
              className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white transition-colors shrink-0 shadow-md shadow-blue-600/30"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
