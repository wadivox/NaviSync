import React, { useState, useEffect, useRef } from 'react';
import { GeocodingProvider, GeocodingResult } from '../../providers/GeocodingProvider';
import { PlaceItem } from '../../types/navigation';
import { Search, X, MapPin, Loader2, Navigation, Heart, Briefcase, Home } from 'lucide-react';

interface SearchBarProps {
  onSelectLocation: (result: GeocodingResult) => void;
  onClearDestination?: () => void;
  activeDestinationName?: string;
  placeholderText?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  onSelectLocation,
  onClearDestination,
  activeDestinationName,
  placeholderText
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<GeocodingResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const providerRef = useRef(new GeocodingProvider());
  const debounceTimerRef = useRef<any>(null);

  // Sync external destination name into search display if present
  useEffect(() => {
    if (activeDestinationName && !query) {
      setQuery(activeDestinationName);
    } else if (!activeDestinationName && query === activeDestinationName) {
      setQuery('');
    }
  }, [activeDestinationName]);

  const presets = [
    { name: 'Home', address: 'Banjara Hills Rd No 12, Hyderabad', lat: 17.4156, lng: 78.4357, icon: Home },
    { name: 'Work', address: 'Cyber Towers, Hitec City, Hyderabad', lat: 17.4504, lng: 78.3808, icon: Briefcase }
  ];

  useEffect(() => {
    if (query.trim().length < 2) {
      setResults([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);

    debounceTimerRef.current = setTimeout(async () => {
      try {
        const data = await providerRef.current.search(query);
        setResults(data);
      } catch (e) {
        console.warn('Geocoding search error:', e);
      } finally {
        setIsLoading(false);
      }
    }, 320);

    return () => clearTimeout(debounceTimerRef.current);
  }, [query]);

  return (
    <div className="relative w-full max-w-md">
      {/* Search Input Box */}
      <div className="flex items-center bg-[#0d0d0d]/90 border border-[#1f1f1f] rounded-2xl px-3.5 py-2.5 shadow-2xl shadow-black/80 backdrop-blur-md focus-within:border-blue-500/70 focus-within:ring-2 focus-within:ring-blue-500/15 transition-all">
        <Search className="w-5 h-5 text-[#8e8e8e] shrink-0 mr-2.5" />
        <input
          id="global-search-input"
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholderText || 'Search places, hospitals, EV chargers, addresses...'}
          className="bg-transparent text-sm text-[#e0e0e0] placeholder:text-[#666666] outline-none w-full"
        />
        {isLoading && <Loader2 className="w-4 h-4 text-blue-400 animate-spin shrink-0 mx-1" />}
        {(query || activeDestinationName) && (
          <button
            id="btn-clear-search"
            onClick={() => {
              setQuery('');
              setResults([]);
              setIsOpen(false);
              onClearDestination?.();
            }}
            title="Clear search and destination"
            className="p-1 hover:bg-[#1f1f1f] text-[#8e8e8e] hover:text-[#e0e0e0] rounded-full shrink-0 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Results Dropdown */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-[#0d0d0d]/95 border border-[#1f1f1f] rounded-2xl shadow-2xl shadow-black/90 overflow-hidden z-40 backdrop-blur-md max-h-80 overflow-y-auto">
          {/* Quick Presets when input is empty */}
          {query.trim().length === 0 && (
            <div className="p-2 border-b border-[#1a1a1a]">
              <div className="text-[11px] font-semibold text-[#8e8e8e] uppercase tracking-wider px-3 py-1.5">
                Saved Places
              </div>
              {presets.map((p) => {
                const IconComponent = p.icon;
                return (
                  <button
                    key={p.name}
                    onClick={() => {
                      onSelectLocation({ displayName: p.address, name: p.name, lat: p.lat, lng: p.lng, type: 'saved' });
                      setIsOpen(false);
                      setQuery(p.name);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-[#161616] flex items-center gap-3 transition-colors text-[#e0e0e0]"
                  >
                    <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/20 flex items-center justify-center shrink-0">
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium text-white">{p.name}</div>
                      <div className="text-xs text-[#8e8e8e] truncate">{p.address}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* Search Geocoding Results */}
          {results.length > 0 ? (
            <div className="p-1">
              {results.map((r, idx) => (
                <button
                  key={`${r.lat}-${r.lng}-${idx}`}
                  onClick={() => {
                    onSelectLocation(r);
                    setIsOpen(false);
                    setQuery(r.name);
                  }}
                  className="w-full text-left px-3.5 py-2.5 rounded-xl hover:bg-[#161616] flex items-start gap-3 transition-colors border-b border-[#1a1a1a]/60 last:border-0"
                >
                  <MapPin className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium text-white truncate">{r.name}</div>
                    <div className="text-xs text-[#8e8e8e] truncate mt-0.5">{r.displayName}</div>
                  </div>
                </button>
              ))}
            </div>
          ) : query.trim().length >= 2 && !isLoading ? (
            <div className="p-4 text-center text-xs text-[#8e8e8e]">
              No matching locations found for "{query}". Try a city, street, or landmark.
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
};
