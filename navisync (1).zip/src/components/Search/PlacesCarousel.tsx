import React from 'react';
import { PlaceItem } from '../../types/navigation';
import { Navigation, Star, MapPin, X, ChevronRight } from 'lucide-react';

interface PlacesCarouselProps {
  places: PlaceItem[];
  selectedPlaceId?: string | null;
  onSelectPlace: (place: PlaceItem) => void;
  onGetDirections: (place: PlaceItem) => void;
  onClose: () => void;
  categoryName?: string;
}

export const PlacesCarousel: React.FC<PlacesCarouselProps> = ({
  places,
  selectedPlaceId,
  onSelectPlace,
  onGetDirections,
  onClose,
  categoryName
}) => {
  if (!places || places.length === 0) return null;

  return (
    <div
      id="nearby-places-carousel-container"
      className="w-full max-w-2xl mx-auto flex flex-col gap-2 pointer-events-auto select-none animate-in fade-in slide-in-from-bottom-4 duration-200"
    >
      {/* Header bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#0d0d0d]/90 border border-[#222222] rounded-xl backdrop-blur-md shadow-xl text-xs">
        <div className="flex items-center gap-2">
          <MapPin className="w-3.5 h-3.5 text-blue-400" />
          <span className="font-semibold text-white">
            {places.length} Nearby {categoryName ? categoryName.toUpperCase() : 'PLACES'} (Within 5 km)
          </span>
        </div>
        <button
          onClick={onClose}
          aria-label="Close nearby places"
          className="p-1 rounded-lg text-[#888888] hover:text-white hover:bg-[#1a1a1a] transition-colors"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Horizontal Carousel */}
      <div className="flex gap-3 overflow-x-auto pb-2 pt-1 px-1 scrollbar-thin scrollbar-thumb-[#333333] scrollbar-track-transparent">
        {places.map((place) => {
          const isSelected = selectedPlaceId === place.id;
          return (
            <div
              key={place.id}
              onClick={() => onSelectPlace(place)}
              className={`flex-shrink-0 w-64 bg-[#0d0d0d]/95 border rounded-2xl p-3.5 backdrop-blur-md shadow-2xl cursor-pointer transition-all duration-150 flex flex-col justify-between ${
                isSelected
                  ? 'border-blue-500 ring-2 ring-blue-500/40 bg-[#121212]'
                  : 'border-[#222222] hover:border-[#383838] hover:bg-[#141414]'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-1 mb-1">
                  <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-blue-400 bg-blue-950/60 border border-blue-800/50 px-1.5 py-0.5 rounded">
                    {place.category.replace('_', ' ')}
                  </span>
                  {place.distanceKm !== undefined && (
                    <span className="text-[11px] font-mono font-bold text-emerald-400">
                      {place.distanceKm} km
                    </span>
                  )}
                </div>

                <h4 className="text-sm font-bold text-white line-clamp-1 group-hover:text-blue-300">
                  {place.name}
                </h4>
                <p className="text-[11px] text-[#8e8e8e] line-clamp-1 mt-0.5">
                  {place.address}
                </p>

                {place.rating && (
                  <div className="flex items-center gap-1.5 mt-2 text-xs">
                    <div className="flex items-center text-amber-400">
                      <Star className="w-3 h-3 fill-amber-400 mr-0.5" />
                      <span className="font-bold text-[11px]">{place.rating.toFixed(1)}</span>
                    </div>
                    {place.reviewCount && (
                      <span className="text-[10px] text-[#666666]">
                        ({place.reviewCount})
                      </span>
                    )}
                  </div>
                )}
              </div>

              <div className="mt-3 pt-2 border-t border-[#1e1e1e] flex items-center justify-between">
                <span className="text-[10px] text-[#777777] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span>Open Now</span>
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onGetDirections(place);
                  }}
                  className="bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-semibold px-2.5 py-1.5 rounded-lg flex items-center gap-1 shadow-md shadow-blue-600/30 transition-all"
                >
                  <Navigation className="w-3 h-3" />
                  <span>Route</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
