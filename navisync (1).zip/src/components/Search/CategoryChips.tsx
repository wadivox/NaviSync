import React from 'react';
import { PlaceItem } from '../../types/navigation';
import { Hospital, Zap, Fuel, Utensils, Pill, SquareParking, ShieldCheck, Siren } from 'lucide-react';

interface CategoryChipsProps {
  onSelectCategory: (category: PlaceItem['category']) => void;
  onTriggerEmergency: () => void;
  activeCategory?: PlaceItem['category'] | null;
}

export const CategoryChips: React.FC<CategoryChipsProps> = ({
  onSelectCategory,
  onTriggerEmergency,
  activeCategory
}) => {
  const categories: { id: PlaceItem['category']; label: string; icon: any; color: string }[] = [
    { id: 'hospital', label: 'Hospitals', icon: Hospital, color: 'hover:border-rose-500/50 hover:text-rose-400' },
    { id: 'ev_charging', label: 'EV Chargers', icon: Zap, color: 'hover:border-cyan-500/50 hover:text-cyan-400' },
    { id: 'fuel', label: 'Fuel', icon: Fuel, color: 'hover:border-amber-500/50 hover:text-amber-400' },
    { id: 'restaurant', label: 'Food', icon: Utensils, color: 'hover:border-orange-500/50 hover:text-orange-400' },
    { id: 'pharmacy', label: 'Pharmacy', icon: Pill, color: 'hover:border-emerald-500/50 hover:text-emerald-400' },
    { id: 'parking', label: 'Parking', icon: SquareParking, color: 'hover:border-blue-500/50 hover:text-blue-400' }
  ];

  return (
    <div className="flex items-center gap-2 overflow-x-auto py-1 max-w-full scrollbar-none">
      {/* 1-Tap Emergency SOS Chip */}
      <button
        id="btn-emergency-sos"
        onClick={onTriggerEmergency}
        className="px-3 py-1.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 hover:bg-rose-500/25 text-xs font-semibold flex items-center gap-1.5 shrink-0 shadow-xl shadow-black/60 backdrop-blur-md transition-all animate-pulse"
      >
        <Siren className="w-3.5 h-3.5 text-rose-400" />
        <span>Emergency SOS</span>
      </button>

      {/* Categories */}
      {categories.map((c) => {
        const Icon = c.icon;
        const isActive = activeCategory === c.id;
        return (
          <button
            key={c.id}
            id={`chip-cat-${c.id}`}
            onClick={() => onSelectCategory(c.id)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-1.5 shrink-0 shadow-lg shadow-black/50 backdrop-blur-md transition-all ${
              isActive
                ? 'bg-blue-600 text-white border-blue-500 shadow-blue-600/30'
                : `bg-[#0d0d0d]/90 border-[#1f1f1f] text-[#e0e0e0] ${c.color} hover:bg-[#161616] hover:border-[#2a2a2a]`
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            <span>{c.label}</span>
          </button>
        );
      })}
    </div>
  );
};
