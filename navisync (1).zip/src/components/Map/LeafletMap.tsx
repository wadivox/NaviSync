import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { GeoCoordinate, RouteOption, FusionState, GNSSState, PlaceItem, NaviSyncNavigationState } from '../../types/navigation';
import { Layers, Navigation, Compass, Plus, Minus, ShieldAlert, Crosshair } from 'lucide-react';

interface LeafletMapProps {
  currentPosition: GeoCoordinate;
  fusionState: FusionState;
  navState?: NaviSyncNavigationState;
  gnssState: GNSSState;
  gnssHeading?: number | null;
  compassHeading?: number | null;
  activeRoute: RouteOption | null;
  destinationCoordinate?: GeoCoordinate | null;
  destinationName?: string;
  nearbyPlaces?: PlaceItem[];
  selectedPlace: PlaceItem | null;
  onSelectPlace: (place: PlaceItem | null) => void;
  isNavigating: boolean;
  showTraditionalComparison: boolean;
  onMapClick?: (lat: number, lng: number) => void;
  recenterTrigger?: number;
}

const CARTO_API_KEY = (import.meta.env.VITE_CARTO_API_KEY as string) || 'cb1_2wsb_1_1ce327a00cc6c5aedcb3471b';

const getTileLayerConfig = (style: 'streets' | 'dark' | 'satellite') => {
  if (style === 'dark') {
    return {
      url: `https://{s}.basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}{r}.png?key=${CARTO_API_KEY}`,
      options: {
        subdomains: 'abcd',
        maxZoom: 20,
        attribution: '&copy; OpenStreetMap &copy; CARTO'
      }
    };
  }
  if (style === 'satellite') {
    return {
      url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      options: {
        maxZoom: 19,
        attribution: 'Tiles &copy; Esri'
      }
    };
  }
  return {
    url: `https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png?key=${CARTO_API_KEY}`,
    options: {
      subdomains: 'abcd',
      maxZoom: 20,
      attribution: '&copy; OpenStreetMap &copy; CARTO'
    }
  };
};

export const LeafletMap: React.FC<LeafletMapProps> = ({
  currentPosition,
  fusionState,
  navState,
  gnssState,
  gnssHeading,
  compassHeading,
  activeRoute,
  destinationCoordinate,
  destinationName,
  nearbyPlaces,
  selectedPlace,
  onSelectPlace,
  isNavigating,
  showTraditionalComparison,
  onMapClick,
  recenterTrigger
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const vehicleMarkerRef = useRef<L.Marker | null>(null);
  const destinationMarkerRef = useRef<L.Marker | null>(null);
  const accuracyCircleRef = useRef<L.Circle | null>(null);
  const traditionalMarkerRef = useRef<L.Marker | null>(null);
  const routePolylineRef = useRef<L.Polyline | null>(null);
  const tunnelPolylinesRef = useRef<L.Polyline[]>([]);
  const comparisonPolylineRef = useRef<L.Polyline[]>([]);
  const placesLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const lastHeadingAngleRef = useRef<number>(navState?.heading ?? fusionState.headingDeg ?? 0);
  const prevActiveRouteRef = useRef<RouteOption | null>(null);
  const prevDestinationCoordRef = useRef<GeoCoordinate | null | undefined>(null);

  const [mapStyle, setMapStyle] = useState<'streets' | 'dark' | 'satellite'>('dark');
  const [isFollowMode, setIsFollowMode] = useState(true);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const initialLat = navState ? navState.latitude : currentPosition.lat;
    const initialLng = navState ? navState.longitude : currentPosition.lng;

    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLng],
      zoom: 16,
      zoomControl: false,
      attributionControl: false
    });

    const { url, options } = getTileLayerConfig(mapStyle);
    const tiles = L.tileLayer(url, options);
    tiles.addTo(map);
    tileLayerRef.current = tiles;

    placesLayerGroupRef.current = L.layerGroup().addTo(map);

    map.on('click', (e) => {
      if (onMapClick) onMapClick(e.latlng.lat, e.latlng.lng);
    });

    map.on('dragstart', () => {
      setIsFollowMode(false);
    });

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Tile Layer on Style Change
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    if (tileLayerRef.current) {
      mapInstanceRef.current.removeLayer(tileLayerRef.current);
    }

    const { url, options } = getTileLayerConfig(mapStyle);
    const tiles = L.tileLayer(url, options);
    tiles.addTo(mapInstanceRef.current);
    tileLayerRef.current = tiles;
  }, [mapStyle]);

  // Update Vehicle Marker & Accuracy Circle with directional arrow
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;
    
    // Authoritative position: navState if provided, otherwise fallback to fusionState
    const lat = navState ? navState.latitude : fusionState.lat;
    const lng = navState ? navState.longitude : fusionState.lng;

    // Determine status color: Blue = GNSS, Amber = Lost/Inertial DR, Cyan = Restoring
    const isLost = gnssState === 'GNSS_LOST' || gnssState === 'NAVISYNC_INERTIAL';
    const isRestoring = gnssState === 'GNSS_RESTORING';

    let primaryColorLight = '#60a5fa'; // Blue 400
    let primaryColorDark = '#1d4ed8';  // Blue 700
    let pulseColor = '#3b82f6';
    if (isLost) {
      primaryColorLight = '#fbbf24'; // Amber 400
      primaryColorDark = '#b45309';  // Amber 700
      pulseColor = '#f59e0b';
    } else if (isRestoring) {
      primaryColorLight = '#22d3ee'; // Cyan 400
      primaryColorDark = '#0e7490';  // Cyan 700
      pulseColor = '#06b6d4';
    }

    // Authoritative heading: navState if provided, otherwise computed fallback
    let targetHeading = navState ? navState.heading : fusionState.headingDeg;
    let headingSource: string = navState ? navState.headingSource : 'NaviSync IMU DR';

    if (!navState) {
      if (isLost) {
        targetHeading = fusionState.headingDeg;
        headingSource = 'NaviSync IMU DR';
      } else if (gnssHeading !== null && gnssHeading !== undefined && !isNaN(gnssHeading) && gnssHeading >= 0) {
        targetHeading = gnssHeading;
        headingSource = 'GNSS Heading';
      } else if (compassHeading !== null && compassHeading !== undefined && !isNaN(compassHeading) && compassHeading >= 0) {
        targetHeading = compassHeading;
        headingSource = 'Compass Orientation';
      } else {
        targetHeading = fusionState.headingDeg;
        headingSource = 'NaviSync IMU DR';
      }
    }

    // Smooth shortest-angular-difference unwrapping to prevent 360-degree snap or reverse spinning
    const currentAngle = lastHeadingAngleRef.current;
    let diff = ((targetHeading - (currentAngle % 360) + 540) % 360) - 180;
    const unwrappedAngle = currentAngle + diff;
    lastHeadingAngleRef.current = unwrappedAngle;

    // High-Visibility Directional Navigation Chevron Marker:
    // Features a true aerodynamic swept-back navigation arrow, forward-facing illumination cone,
    // and white contrast border + deep shadow for flawless visibility.
    const vehicleIconHtml = `
      <div class="navisync-loc-marker" style="position: relative; width: 64px; height: 64px; display: flex; align-items: center; justify-content: center; pointer-events: none;" title="Heading: ${Math.round(targetHeading)}° (${headingSource})">
        <!-- Omni-directional pulsating ripple ring -->
        <div style="position: absolute; width: 46px; height: 46px; border-radius: 50%; background: ${pulseColor}22; border: 1.5px solid ${pulseColor}44; animation: ping 2.4s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>

        <!-- Rotating Directional Assembly (Centered on GPS coordinate at [32, 32]) -->
        <div style="position: absolute; width: 64px; height: 64px; display: flex; align-items: center; justify-content: center; transform: rotate(${unwrappedAngle}deg); transition: transform 0.22s cubic-bezier(0.2, 0, 0.25, 1); transform-origin: 32px 32px;">
          
          <!-- Forward Directional Illumination Beam (Flashlight Cone pointing forward) -->
          <div style="position: absolute; top: 0px; width: 48px; height: 32px; pointer-events: none;">
            <svg width="48" height="32" viewBox="0 0 48 32" style="overflow: visible;">
              <defs>
                <radialGradient id="beam-grad" cx="50%" cy="100%" r="90%">
                  <stop offset="0%" stop-color="${pulseColor}" stop-opacity="0.75" />
                  <stop offset="55%" stop-color="${pulseColor}" stop-opacity="0.30" />
                  <stop offset="100%" stop-color="${pulseColor}" stop-opacity="0" />
                </radialGradient>
              </defs>
              <path d="M 24 32 L 2 2 Q 24 0 46 2 Z" fill="url(#beam-grad)" />
            </svg>
          </div>

          <!-- Bold Aerodynamic Navigation Chevron Arrow Puck -->
          <div style="position: relative; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; filter: drop-shadow(0 4px 8px rgba(0,0,0,0.85)) drop-shadow(0 0 10px ${pulseColor}bb);">
            <svg width="42" height="42" viewBox="0 0 40 40" style="overflow: visible;">
              <defs>
                <linearGradient id="nav-arrow-fill" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stop-color="${primaryColorLight}" />
                  <stop offset="100%" stop-color="${primaryColorDark}" />
                </linearGradient>
              </defs>
              <!-- Outer Arrow Puck with Crisp 2.5px White Border -->
              <path
                d="M 20 4 L 34 35 L 20 28 L 6 35 Z"
                fill="url(#nav-arrow-fill)"
                stroke="#ffffff"
                stroke-width="2.5"
                stroke-linejoin="round"
                stroke-linecap="round"
              />
              <!-- Inner Center Spine Highlight -->
              <path
                d="M 20 8 L 20 27"
                stroke="#ffffff"
                stroke-width="1.8"
                stroke-linecap="round"
                stroke-opacity="0.9"
              />
            </svg>
          </div>
        </div>

        <!-- Center Anchor Dot -->
        <div style="position: absolute; width: 8px; height: 8px; border-radius: 50%; background: #ffffff; box-shadow: 0 0 6px ${pulseColor}; z-index: 10;"></div>
      </div>
    `;

    const customIcon = L.divIcon({
      html: vehicleIconHtml,
      className: 'navisync-vehicle-marker',
      iconSize: [64, 64],
      iconAnchor: [32, 32]
    });

    if (!vehicleMarkerRef.current) {
      vehicleMarkerRef.current = L.marker([lat, lng], { icon: customIcon, zIndexOffset: 1200 }).addTo(map);
    } else {
      vehicleMarkerRef.current.setLatLng([lat, lng]);
      vehicleMarkerRef.current.setIcon(customIcon);
    }

    // Accuracy Circle
    const accuracyRadius = navState
      ? Math.max(8, navState.accuracy)
      : isLost
      ? Math.max(8, fusionState.driftMeters * 1.5)
      : 12;
    if (!accuracyCircleRef.current) {
      accuracyCircleRef.current = L.circle([lat, lng], {
        radius: accuracyRadius,
        color: pulseColor,
        weight: 1.5,
        fillColor: pulseColor,
        fillOpacity: 0.12
      }).addTo(map);
    } else {
      accuracyCircleRef.current.setLatLng([lat, lng]);
      accuracyCircleRef.current.setRadius(accuracyRadius);
      accuracyCircleRef.current.setStyle({ color: pulseColor, fillColor: pulseColor });
    }

    if (isFollowMode) {
      map.panTo([lat, lng], { animate: true, duration: 0.4 });
    }
  }, [fusionState, navState, gnssState, gnssHeading, compassHeading, isFollowMode]);

  // Return to normal exploration view when destination or route is cleared
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;
    const hadRoute = !!prevActiveRouteRef.current;
    const hadDest = !!prevDestinationCoordRef.current;
    prevActiveRouteRef.current = activeRoute;
    prevDestinationCoordRef.current = destinationCoordinate;

    // If route or destination was cleared and we're not currently navigating, smoothly recenter to exploration view
    if ((hadRoute && !activeRoute) || (hadDest && !destinationCoordinate)) {
      if (!isNavigating) {
        map.setView([fusionState.lat, fusionState.lng], 16, { animate: true });
        setIsFollowMode(true);
      }
    }
  }, [activeRoute, destinationCoordinate, isNavigating, fusionState.lat, fusionState.lng]);

  // Handle external / manual Recenter Trigger
  useEffect(() => {
    if (!mapInstanceRef.current || recenterTrigger === undefined) return;
    const map = mapInstanceRef.current;
    map.setView([fusionState.lat, fusionState.lng], 16, { animate: true });
    setIsFollowMode(true);
  }, [recenterTrigger]);

  // Render Active Route and Tunnel Risk Zones
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    // Clear old route lines
    if (routePolylineRef.current) {
      map.removeLayer(routePolylineRef.current);
      routePolylineRef.current = null;
    }
    tunnelPolylinesRef.current.forEach((line) => map.removeLayer(line));
    tunnelPolylinesRef.current = [];

    if (!activeRoute || activeRoute.coordinates.length < 2) return;

    // Draw main route
    const polyline = L.polyline(activeRoute.coordinates, {
      color: '#3b82f6',
      weight: 6,
      opacity: 0.9,
      lineCap: 'round',
      lineJoin: 'round'
    }).addTo(map);
    routePolylineRef.current = polyline;

    // Draw tunnel / GNSS risk segments with distinct amber/striped styling
    if (activeRoute.tunnelSegments && activeRoute.tunnelSegments.length > 0) {
      activeRoute.tunnelSegments.forEach((tunnel) => {
        const segCoords = activeRoute.coordinates.slice(tunnel.startIdx, tunnel.endIdx + 1);
        if (segCoords.length >= 2) {
          const tunnelLine = L.polyline(segCoords, {
            color: '#f59e0b',
            weight: 7,
            dashArray: '8, 8',
            opacity: 1
          }).addTo(map);

          tunnelLine.bindTooltip(`⚠️ ${tunnel.name} (GNSS Denied Zone)`, {
            sticky: true,
            className: 'bg-amber-950 text-amber-200 border border-amber-600 text-xs px-2 py-1 rounded shadow'
          });
          tunnelPolylinesRef.current.push(tunnelLine);
        }
      });
    }

    // Fit bounds once on route load
    if (!isNavigating) {
      map.fitBounds(polyline.getBounds(), { padding: [60, 60] });
    }
  }, [activeRoute, isNavigating]);

  // Render Persistent Destination Pin (persists across rerouting, removed only on clear/cancel)
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    if (!destinationCoordinate) {
      if (destinationMarkerRef.current) {
        map.removeLayer(destinationMarkerRef.current);
        destinationMarkerRef.current = null;
      }
      return;
    }

    const { lat, lng } = destinationCoordinate;

    // Distinct drop-pin marker with smooth drop-in bounce animation and high-contrast styling
    const destinationIconHtml = `
      <div style="position: relative; width: 38px; height: 48px; filter: drop-shadow(0 8px 12px rgba(0,0,0,0.7));">
        <style>
          @keyframes naviPinDrop {
            0% { transform: translateY(-44px) scale(0.6); opacity: 0; }
            60% { transform: translateY(4px) scale(1.06); opacity: 1; }
            80% { transform: translateY(-2px) scale(0.98); }
            100% { transform: translateY(0) scale(1); }
          }
        </style>
        <div style="animation: naviPinDrop 0.45s cubic-bezier(0.34, 1.56, 0.64, 1) forwards; display: flex; flex-direction: column; align-items: center;">
          <div style="width: 32px; height: 32px; border-radius: 50% 50% 50% 0; background: linear-gradient(135deg, #f87171, #dc2626); transform: rotate(-45deg); border: 2.5px solid #ffffff; box-shadow: 0 0 16px rgba(220,38,38,0.75); display: flex; align-items: center; justify-content: center;">
            <div style="width: 10px; height: 10px; background: white; border-radius: 50%; transform: rotate(45deg);"></div>
          </div>
          <div style="width: 12px; height: 3px; background: rgba(0,0,0,0.5); border-radius: 50%; margin-top: 4px; filter: blur(1px);"></div>
        </div>
      </div>
    `;

    const destIcon = L.divIcon({
      html: destinationIconHtml,
      className: 'navisync-dest-marker',
      iconSize: [38, 48],
      iconAnchor: [19, 44]
    });

    if (!destinationMarkerRef.current) {
      destinationMarkerRef.current = L.marker([lat, lng], {
        icon: destIcon,
        zIndexOffset: 1200
      }).addTo(map);
    } else {
      destinationMarkerRef.current.setLatLng([lat, lng]);
      destinationMarkerRef.current.setIcon(destIcon);
    }

    if (destinationName) {
      destinationMarkerRef.current.bindTooltip(destinationName, {
        permanent: false,
        direction: 'top',
        className: 'bg-[#0d0d0d] text-white border border-[#2a2a2a] font-semibold text-xs px-2.5 py-1 rounded-lg shadow-2xl'
      });
    }
  }, [destinationCoordinate, destinationName]);

  // Render Nearby Places Pins simultaneously on map
  useEffect(() => {
    if (!mapInstanceRef.current || !placesLayerGroupRef.current) return;
    const layerGroup = placesLayerGroupRef.current;
    layerGroup.clearLayers();

    if (!nearbyPlaces || nearbyPlaces.length === 0) return;

    const categoryIcons: Record<string, { bg: string; border: string; emoji: string }> = {
      hospital: { bg: '#dc2626', border: '#f87171', emoji: '🏥' },
      pharmacy: { bg: '#059669', border: '#34d399', emoji: '💊' },
      fuel: { bg: '#d97706', border: '#fbbf24', emoji: '⛽' },
      ev_charging: { bg: '#0284c7', border: '#38bdf8', emoji: '⚡' },
      restaurant: { bg: '#ea580c', border: '#fb923c', emoji: '🍽️' },
      parking: { bg: '#2563eb', border: '#60a5fa', emoji: '🅿️' },
      police: { bg: '#4f46e5', border: '#818cf8', emoji: '👮' },
      poi: { bg: '#7c3aed', border: '#a78bfa', emoji: '📍' }
    };

    nearbyPlaces.forEach((place) => {
      const isSelected = selectedPlace?.id === place.id;
      const conf = categoryIcons[place.category] || { bg: '#2563eb', border: '#60a5fa', emoji: '📍' };

      const placeIconHtml = `
        <div style="position: relative; width: 34px; height: 34px; display: flex; align-items: center; justify-content: center; cursor: pointer;">
          <div style="
            width: ${isSelected ? '34px' : '28px'};
            height: ${isSelected ? '34px' : '28px'};
            border-radius: 50%;
            background: ${conf.bg};
            border: 2px solid ${isSelected ? '#ffffff' : conf.border};
            box-shadow: 0 3px 10px rgba(0,0,0,0.6)${isSelected ? `, 0 0 16px ${conf.border}` : ''};
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: ${isSelected ? '15px' : '12px'};
            transition: transform 0.15s ease;
          ">
            ${conf.emoji}
          </div>
        </div>
      `;

      const markerIcon = L.divIcon({
        html: placeIconHtml,
        className: 'place-marker',
        iconSize: [34, 34],
        iconAnchor: [17, 17]
      });

      const marker = L.marker([place.lat, place.lng], {
        icon: markerIcon,
        zIndexOffset: isSelected ? 800 : 300
      });

      marker.bindTooltip(`<b>${place.name}</b><br/><span style="color:#a0a0a0">${place.distanceKm !== undefined ? place.distanceKm + ' km away • ' : ''}${place.address}</span>`, {
        direction: 'top',
        className: 'bg-[#0d0d0d] text-white border border-[#222222] text-xs px-2.5 py-1 rounded-lg shadow-xl'
      });

      marker.on('click', () => {
        onSelectPlace(place);
      });

      layerGroup.addLayer(marker);
    });
  }, [nearbyPlaces, selectedPlace, onSelectPlace]);

  // Render Traditional DR Comparison (Red divergent trajectory vs NaviSync)
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    comparisonPolylineRef.current.forEach((p) => map.removeLayer(p));
    comparisonPolylineRef.current = [];

    if (traditionalMarkerRef.current) {
      map.removeLayer(traditionalMarkerRef.current);
      traditionalMarkerRef.current = null;
    }

    const isLost = gnssState === 'GNSS_LOST' || gnssState === 'NAVISYNC_INERTIAL';

    if (showTraditionalComparison && isLost && fusionState.rawDriftMetersWithoutNaviSync > 0) {
      // Calculate unconstrained traditional dead reckoning position drifting off-course
      const rad = (fusionState.headingDeg * Math.PI) / 180 + 0.35; // unconstrained gyro bias angle
      const dLat = (fusionState.rawDriftMetersWithoutNaviSync * Math.cos(rad)) / 111132;
      const dLng =
        (fusionState.rawDriftMetersWithoutNaviSync * Math.sin(rad)) /
        (111132 * Math.cos((fusionState.lat * Math.PI) / 180));

      const tradLat = fusionState.lat + dLat;
      const tradLng = fusionState.lng + dLng;

      // Draw red drifting trajectory
      const tradLine = L.polyline(
        [
          [fusionState.lat, fusionState.lng],
          [tradLat, tradLng]
        ],
        {
          color: '#ef4444',
          weight: 3,
          dashArray: '4, 6',
          opacity: 0.85
        }
      ).addTo(map);
      comparisonPolylineRef.current.push(tradLine);

      // Traditional position marker
      const tradIconHtml = `
        <div style="width: 22px; height: 22px; border-radius: 50%; background: #ef4444; border: 2px solid white; box-shadow: 0 0 8px rgba(239, 68, 68, 0.8); display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: bold; color: white;">
          ✕
        </div>
      `;
      const tradIcon = L.divIcon({
        html: tradIconHtml,
        className: 'trad-marker',
        iconSize: [22, 22],
        iconAnchor: [11, 11]
      });

      traditionalMarkerRef.current = L.marker([tradLat, tradLng], { icon: tradIcon }).addTo(map);
      traditionalMarkerRef.current.bindTooltip(
        `Traditional DR Error: +${Math.round(fusionState.rawDriftMetersWithoutNaviSync)}m`,
        { permanent: true, direction: 'top', className: 'bg-rose-950 text-rose-200 text-xs px-2 py-0.5 rounded border border-rose-600' }
      );
    }
  }, [showTraditionalComparison, fusionState, gnssState]);

  return (
    <div className="relative w-full h-full overflow-hidden">
      {/* Map Element */}
      <div id="navisync-map-canvas" ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Floating Map Controls */}
      <div className="absolute top-20 right-4 z-20 flex flex-col gap-2">
        {/* Recenter / Follow Mode */}
        <button
          id="btn-recenter-location"
          onClick={() => {
            setIsFollowMode(true);
            mapInstanceRef.current?.setView([fusionState.lat, fusionState.lng], 17, { animate: true });
          }}
          title="Center on vehicle"
          className={`p-3 rounded-xl border backdrop-blur-md shadow-2xl transition-all ${
            isFollowMode
              ? 'bg-blue-600/90 text-white border-blue-500'
              : 'bg-[#0d0d0d]/90 text-[#e0e0e0] border-[#1f1f1f] hover:bg-[#161616]'
          }`}
        >
          <Navigation className="w-5 h-5" />
        </button>

        {/* Compass Rose */}
        <div
          title={`Heading ${Math.round(fusionState.headingDeg)}°`}
          className="p-3 rounded-xl bg-[#0d0d0d]/90 border border-[#1f1f1f] text-[#e0e0e0] shadow-2xl flex items-center justify-center cursor-pointer hover:bg-[#161616] transition-colors"
          onClick={() => {
            mapInstanceRef.current?.setZoom(16);
          }}
        >
          <div
            style={{ transform: `rotate(${fusionState.headingDeg}deg)` }}
            className="transition-transform duration-200"
          >
            <Compass className="w-5 h-5 text-red-400" />
          </div>
        </div>

        {/* Layer Switcher */}
        <button
          id="btn-map-layer-switch"
          onClick={() => {
            setMapStyle((prev) => (prev === 'dark' ? 'streets' : prev === 'streets' ? 'satellite' : 'dark'));
          }}
          title={`Style: ${mapStyle}`}
          className="p-3 rounded-xl bg-[#0d0d0d]/90 border border-[#1f1f1f] text-[#e0e0e0] shadow-2xl hover:bg-[#161616] transition-all"
        >
          <Layers className="w-5 h-5" />
        </button>

        {/* Zoom Controls */}
        <div className="flex flex-col bg-[#0d0d0d]/90 border border-[#1f1f1f] rounded-xl overflow-hidden shadow-2xl">
          <button
            id="btn-zoom-in"
            onClick={() => mapInstanceRef.current?.zoomIn()}
            className="p-2.5 text-[#e0e0e0] hover:bg-[#161616] border-b border-[#1f1f1f] transition-colors"
            title="Zoom in"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            id="btn-zoom-out"
            onClick={() => mapInstanceRef.current?.zoomOut()}
            className="p-2.5 text-[#e0e0e0] hover:bg-[#161616] transition-colors"
            title="Zoom out"
          >
            <Minus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Floating Re-center Pill Button (appears when user manually pans/drags map) */}
      {!isFollowMode && (
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 pointer-events-auto animate-in fade-in slide-in-from-bottom-2 duration-150">
          <button
            id="btn-floating-recenter"
            onClick={() => {
              setIsFollowMode(true);
              const targetLat = navState ? navState.latitude : fusionState.lat;
              const targetLng = navState ? navState.longitude : fusionState.lng;
              mapInstanceRef.current?.setView([targetLat, targetLng], 17, { animate: true });
            }}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-full shadow-2xl flex items-center gap-2 text-xs font-bold border border-blue-400/50 backdrop-blur-md transition-all active:scale-95 cursor-pointer"
          >
            <Crosshair className="w-4 h-4 text-white animate-spin-slow" />
            <span>Re-center on Vehicle</span>
          </button>
        </div>
      )}

      {/* Map Attribution and Coordinates Watermark */}
      <div className="absolute bottom-2 left-3 z-10 text-[10px] text-[#8e8e8e] pointer-events-none bg-[#050505]/85 px-2.5 py-1 rounded-lg border border-[#1f1f1f] font-mono flex gap-2 backdrop-blur-sm">
        <span>© CARTO &amp; OpenStreetMap</span>
        <span>|</span>
        <span>
          {fusionState.lat.toFixed(5)}°, {fusionState.lng.toFixed(5)}°
        </span>
        <span>|</span>
        <span className={gnssState === 'GNSS_AVAILABLE' ? 'text-emerald-400' : 'text-amber-400'}>
          {gnssState.replace('_', ' ')}
        </span>
      </div>
    </div>
  );
};
