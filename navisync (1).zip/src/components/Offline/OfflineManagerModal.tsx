import React, { useState } from 'react';
import { OfflineRegion, globalOfflineService } from '../../services/OfflineService';
import { Download, Trash2, HardDrive, Wifi, WifiOff, CheckCircle2, Pause, Play, Plus, X } from 'lucide-react';

interface OfflineManagerModalProps {
  onClose: () => void;
  isOfflineMode: boolean;
  onToggleOfflineMode: () => void;
  currentLat: number;
  currentLng: number;
}

export const OfflineManagerModal: React.FC<OfflineManagerModalProps> = ({
  onClose,
  isOfflineMode,
  onToggleOfflineMode,
  currentLat,
  currentLng
}) => {
  const [regions, setRegions] = useState<OfflineRegion[]>(globalOfflineService.getRegions());
  const [newRegionName, setNewRegionName] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const handleDownloadNew = () => {
    if (!newRegionName.trim()) return;
    const reg = globalOfflineService.addRegion(newRegionName.trim(), currentLat, currentLng);
    setRegions([...globalOfflineService.getRegions()]);
    setNewRegionName('');
    setIsAdding(false);

    // Simulate download progress
    let p = 15;
    const interval = setInterval(() => {
      p += 25;
      if (p >= 100) {
        p = 100;
        globalOfflineService.updateRegionProgress(reg.id, 100, 'READY');
        clearInterval(interval);
      } else {
        globalOfflineService.updateRegionProgress(reg.id, p, 'DOWNLOADING');
      }
      setRegions([...globalOfflineService.getRegions()]);
    }, 600);
  };

  const handleDelete = (id: string) => {
    globalOfflineService.deleteRegion(id);
    setRegions([...globalOfflineService.getRegions()]);
  };

  const totalStorageMb = regions.reduce((sum, r) => sum + r.sizeMb, 0).toFixed(1);

  return (
    <div className="fixed inset-0 z-50 bg-[#050505]/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0d0d0d] border border-[#1f1f1f] rounded-2xl max-w-lg w-full p-6 shadow-2xl shadow-black/95 text-[#e0e0e0] animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between border-b border-[#1a1a1a] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600/15 border border-blue-500/30 text-blue-400 flex items-center justify-center">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Offline Maps &amp; Cache Manager</h2>
              <p className="text-xs text-[#8e8e8e]">IndexedDB Storage: {totalStorageMb} MB utilized</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8e8e8e] hover:text-white hover:bg-[#161616] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Offline Simulation Toggle */}
        <div className="mt-4 p-3.5 bg-[#080808] rounded-xl border border-[#1f1f1f] flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-2">
              {isOfflineMode ? (
                <WifiOff className="w-4 h-4 text-amber-400" />
              ) : (
                <Wifi className="w-4 h-4 text-emerald-400" />
              )}
              <span>Offline Navigation Test Mode</span>
            </div>
            <div className="text-[11px] text-[#8e8e8e] mt-0.5">
              {isOfflineMode
                ? 'Internet severed. Running completely from local IndexedDB cache.'
                : 'Connected to live online network services.'}
            </div>
          </div>

          <button
            id="btn-toggle-offline-mode"
            onClick={onToggleOfflineMode}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
              isOfflineMode
                ? 'bg-amber-600 text-white border-amber-500 shadow-md shadow-amber-600/30'
                : 'bg-[#141414] text-[#e0e0e0] border-[#1f1f1f] hover:bg-[#1c1c1c]'
            }`}
          >
            {isOfflineMode ? 'Simulate Online' : 'Simulate Offline'}
          </button>
        </div>

        {/* Regions List */}
        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-[#e0e0e0]">Downloaded Offline Regions:</span>
            {!isAdding && (
              <button
                onClick={() => setIsAdding(true)}
                className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Download Current Area</span>
              </button>
            )}
          </div>

          {/* Add region form */}
          {isAdding && (
            <div className="p-3 bg-[#080808] rounded-xl border border-blue-500/40 mb-3 flex items-center gap-2">
              <input
                type="text"
                placeholder="Region label (e.g. Hyderabad City)"
                value={newRegionName}
                onChange={(e) => setNewRegionName(e.target.value)}
                className="flex-1 bg-[#121212] border border-[#1f1f1f] rounded-lg px-2.5 py-1.5 text-xs text-[#e0e0e0] placeholder:text-[#666666] outline-none focus:border-blue-500/70"
              />
              <button
                onClick={handleDownloadNew}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
              >
                Save
              </button>
              <button
                onClick={() => setIsAdding(false)}
                className="px-2 py-1.5 bg-[#141414] hover:bg-[#1c1c1c] text-[#8e8e8e] hover:text-white border border-[#1f1f1f] rounded-lg text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
            </div>
          )}

          <div className="flex flex-col gap-2 max-h-48 overflow-y-auto">
            {regions.map((reg) => (
              <div
                key={reg.id}
                className="p-3 bg-[#080808] border border-[#1f1f1f] rounded-xl flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-950/60 border border-emerald-800/60 text-emerald-400 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">{reg.name}</div>
                    <div className="text-[10px] text-[#8e8e8e]">
                      {reg.sizeMb} MB • {reg.zoomRange} • Cached
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {reg.status === 'DOWNLOADING' && (
                    <span className="text-[10px] text-blue-400 font-mono">{reg.progress}%</span>
                  )}
                  <button
                    onClick={() => handleDelete(reg.id)}
                    className="p-1.5 text-[#666666] hover:text-rose-400 hover:bg-[#161616] rounded-lg transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-[#1a1a1a] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#141414] hover:bg-[#1c1c1c] text-[#e0e0e0] border border-[#1f1f1f] text-xs font-bold transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
