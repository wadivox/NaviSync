import React, { useState } from 'react';
import { RouteOption, NavigationMode, GeoCoordinate } from '../../types/navigation';
import { Car, Bike, Footprints, Navigation, Clock, ShieldAlert, Zap, ArrowRight, X } from 'lucide-react';

interface RoutePlannerProps {
  startCoordinate: GeoCoordinate;
  destinationName: string;
  routes: RouteOption[];
  selectedRouteId: string;
  onSelectRoute: (routeId: string) => void;
  onStartNavigation: () => void;
  onClose: () => void;
  mode: NavigationMode;
  onChangeMode: (mode: NavigationMode) => void;
}

export const RoutePlanner: React.FC<RoutePlannerProps> = ({
  destinationName,
  routes,
  selectedRouteId,
  onSelectRoute,
  onStartNavigation,
  onClose,
  mode,
  onChangeMode
}) => {
  const modes: { id: NavigationMode; label: string; icon: any }[] = [
    { id: 'driving', label: 'Car', icon: Car },
    { id: 'two_wheeler', label: 'Moto', icon: Bike },
    { id: 'cycling', label: 'Bicycle', icon: Bike },
    { id: 'walking', label: 'Walk', icon: Footprints }
  ];

  const selectedRoute = routes.find((r) => r.id === selectedRouteId) || routes[0];

  return (
    <div className="bg-[#0d0d0d]/95 border border-[#1f1f1f] shadow-2xl shadow-black/90 rounded-2xl p-4 text-[#e0e0e0] backdrop-blur-md max-w-md w-full flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1a1a1a] pb-2.5">
        <div>
          <div className="text-xs text-[#8e8e8e] font-medium">Route Plan</div>
          <h3 className="text-base font-bold text-white truncate max-w-xs">{destinationName}</h3>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-[#8e8e8e] hover:text-white hover:bg-[#161616] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Mode Selector */}
      <div className="flex items-center justify-between bg-[#050505] p-1 rounded-xl border border-[#1f1f1f]">
        {modes.map((m) => {
          const Icon = m.icon;
          const isActive = mode === m.id;
          return (
            <button
              key={m.id}
              onClick={() => onChangeMode(m.id)}
              className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-[#8e8e8e] hover:text-[#e0e0e0] hover:bg-[#121212]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{m.label}</span>
            </button>
          );
        })}
      </div>

      {/* Route Options List */}
      <div className="flex flex-col gap-2 max-h-56 overflow-y-auto pr-1">
        {routes.map((r) => {
          const isSelected = r.id === selectedRouteId;
          const hasTunnelRisk = r.tunnelSegments && r.tunnelSegments.length > 0;

          return (
            <div
              key={r.id}
              onClick={() => onSelectRoute(r.id)}
              className={`p-3 rounded-xl border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-blue-950/40 border-blue-500/70 shadow-md ring-1 ring-blue-500/40'
                  : 'bg-[#121212]/70 border-[#1f1f1f] hover:bg-[#181818] text-[#e0e0e0]'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="font-bold text-sm text-white flex items-center gap-2">
                  <span>{r.durationMinutes} min</span>
                  <span className="text-xs text-[#8e8e8e] font-normal">({r.distanceKm} km)</span>
                  {r.isFastest && (
                    <span className="text-[10px] bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 px-1.5 py-0.2 rounded font-semibold font-mono">
                      Fastest
                    </span>
                  )}
                  {r.isEco && (
                    <span className="text-[10px] bg-cyan-950/60 text-cyan-300 border border-cyan-800/60 px-1.5 py-0.2 rounded font-semibold font-mono">
                      Eco
                    </span>
                  )}
                </div>
                <span className="text-xs text-[#8e8e8e]">{r.trafficLevel} Traffic</span>
              </div>

              <div className="text-xs text-[#a0a0a0] mt-1 truncate">{r.summary}</div>

              {/* GNSS Risk Alert Pill */}
              {hasTunnelRisk && (
                <div className="mt-2 flex items-center gap-1.5 text-[11px] text-amber-300 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded-md">
                  <ShieldAlert className="w-3 h-3 text-amber-400 shrink-0" />
                  <span>GNSS Risk Ahead: {r.tunnelSegments?.[0].name} (Inertial Auto-Failover Ready)</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Start Navigation CTA */}
      <button
        id="btn-start-navigation"
        onClick={onStartNavigation}
        className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-4 rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/40 transition-all cursor-pointer"
      >
        <Navigation className="w-4 h-4 fill-white" />
        <span>Start Navigation</span>
      </button>
    </div>
  );
};
