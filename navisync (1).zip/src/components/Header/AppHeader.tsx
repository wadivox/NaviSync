import React, { useState, useEffect, useRef } from 'react';
import { SupportedLanguage, TRANSLATIONS } from '../../i18n/translations';
import { GNSSState } from '../../types/navigation';
import {
  Compass,
  Languages,
  Cpu,
  Zap,
  HardDrive,
  History,
  ChevronDown,
  Check,
  Shield,
  User
} from 'lucide-react';

interface AppHeaderProps {
  currentLanguage: SupportedLanguage;
  onChangeLanguage: (lang: SupportedLanguage) => void;
  gnssState: GNSSState;
  onOpenIntelligence: () => void;
  onOpenEvaluator: () => void;
  onOpenOffline: () => void;
  onOpenTravelHistory: () => void;
  voiceEnabled: boolean;
  onToggleVoice: () => void;
  persona: 'admin' | 'user';
  onTogglePersona: () => void;
  onOpenSIHDemo: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  currentLanguage,
  onChangeLanguage,
  gnssState,
  onOpenIntelligence,
  onOpenEvaluator,
  onOpenOffline,
  onOpenTravelHistory,
  voiceEnabled,
  onToggleVoice,
  persona,
  onTogglePersona,
  onOpenSIHDemo
}) => {
  const t = TRANSLATIONS[currentLanguage];
  const [isLangOpen, setIsLangOpen] = useState(false);
  const langDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent | TouchEvent) => {
      if (langDropdownRef.current && !langDropdownRef.current.contains(e.target as Node)) {
        setIsLangOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, []);

  const languagesList: { code: SupportedLanguage; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'hi', label: 'हिंदी (Hindi)' },
    { code: 'te', label: 'తెలుగు (Telugu)' },
    { code: 'ta', label: 'தமிழ் (Tamil)' },
    { code: 'kn', label: 'ಕನ್ನಡ (Kannada)' },
    { code: 'ml', label: 'മലയാളം (Malayalam)' },
    { code: 'mr', label: 'मराठी (Marathi)' },
    { code: 'bn', label: 'বাংলা (Bengali)' },
    { code: 'gu', label: 'ગુજરાતી (Gujarati)' },
    { code: 'pa', label: 'ਪੰਜਾਬੀ (Punjabi)' }
  ];

  return (
    <header className="absolute top-3 left-4 right-4 z-40 flex items-center justify-between pointer-events-none">
      {/* Brand Badge */}
      <div className="bg-[#0d0d0d]/90 border border-[#1f1f1f] rounded-2xl px-4 py-2 text-[#e0e0e0] shadow-2xl shadow-black/80 backdrop-blur-md pointer-events-auto flex items-center gap-3">
        <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-600/30">
          <Compass className="w-5 h-5 animate-spin-slow" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold tracking-tight text-white">{t.appName}</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-blue-950/60 text-blue-300 border border-blue-800/60">
              SIH26168
            </span>
          </div>
          <p className="text-[10px] text-[#8e8e8e] font-medium hidden sm:block">
            {t.tagline}
          </p>
        </div>
      </div>

      {/* Action Controls & Indicators */}
      <div className="flex items-center gap-2 pointer-events-auto">
        {/* Language Selector */}
        <div className="relative" ref={langDropdownRef}>
          <button
            id="btn-language-selector"
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsLangOpen((prev) => !prev);
            }}
            aria-expanded={isLangOpen}
            aria-label="Select application language"
            className="bg-[#0d0d0d]/95 border border-[#222222] rounded-xl px-2.5 py-2 text-[#e0e0e0] shadow-xl backdrop-blur-md hover:bg-[#161616] hover:border-[#333333] active:bg-[#202020] flex items-center gap-1.5 text-xs font-medium transition-colors"
          >
            <Languages className="w-3.5 h-3.5 text-blue-400" />
            <span className="uppercase font-semibold">{currentLanguage}</span>
            <ChevronDown className={`w-3 h-3 text-[#888888] transition-transform duration-150 ${isLangOpen ? 'rotate-180' : ''}`} />
          </button>

          {isLangOpen && (
            <div
              id="language-dropdown-menu"
              className="absolute right-0 mt-2 bg-[#0d0d0d]/98 border border-[#262626] rounded-xl shadow-2xl p-1.5 z-50 w-48 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-100 max-h-72 overflow-y-auto"
            >
              <div className="text-[10px] font-mono text-[#666666] px-2 py-1 uppercase tracking-wider border-b border-[#1c1c1c] mb-1">
                Select Language
              </div>
              {languagesList.map((lang) => (
                <button
                  key={lang.code}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onChangeLanguage(lang.code);
                    setIsLangOpen(false);
                  }}
                  className={`w-full text-left px-2.5 py-2 rounded-lg text-xs font-medium transition-colors flex items-center justify-between min-h-[38px] cursor-pointer ${
                    currentLanguage === lang.code
                      ? 'bg-blue-600 text-white font-bold'
                      : 'text-[#c0c0c0] hover:text-white hover:bg-[#181818] active:bg-[#222222]'
                  }`}
                >
                  <span>{lang.label}</span>
                  {currentLanguage === lang.code && <Check className="w-3.5 h-3.5 text-white" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Offline Cache Button */}
        <button
          id="btn-open-offline-modal"
          onClick={onOpenOffline}
          title="Offline Maps & Cache Manager"
          className="bg-[#0d0d0d]/90 border border-[#1f1f1f] rounded-xl p-2.5 text-[#e0e0e0] shadow-xl backdrop-blur-md hover:bg-[#161616] hover:border-[#2a2a2a] transition-colors"
        >
          <HardDrive className="w-4 h-4 text-emerald-400" />
        </button>

        {/* Travel History / Your Journeys Button */}
        <button
          id="btn-open-travel-history"
          onClick={onOpenTravelHistory}
          title="Your Journeys & Travel History"
          className="bg-[#0d0d0d]/90 border border-[#1f1f1f] rounded-xl p-2.5 text-[#e0e0e0] shadow-xl backdrop-blur-md hover:bg-[#161616] hover:border-[#2a2a2a] transition-colors flex items-center gap-1.5"
        >
          <History className="w-4 h-4 text-blue-400" />
          <span className="hidden lg:inline text-xs font-medium text-[#ccc]">Journeys</span>
        </button>

        {/* Evaluator Controls Trigger */}
        <button
          id="btn-open-evaluator-controls"
          onClick={onOpenEvaluator}
          title="SIH Evaluator Demo Scenarios"
          className="bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-xl px-3 py-2 text-xs font-semibold shadow-xl backdrop-blur-md hover:bg-amber-500/20 transition-all flex items-center gap-1.5"
        >
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden md:inline">Evaluator Demo</span>
        </button>

        {/* Persona Switcher Toggle */}
        <button
          id="btn-toggle-persona"
          onClick={onTogglePersona}
          title={`Active Persona: ${persona.toUpperCase()}. Click to switch persona.`}
          className={`rounded-xl px-2.5 py-2 text-xs font-semibold shadow-xl backdrop-blur-md border transition-all flex items-center gap-1.5 cursor-pointer ${
            persona === 'admin'
              ? 'bg-amber-950/60 border-amber-500/50 text-amber-300 hover:bg-amber-900/60'
              : 'bg-[#0d0d0d]/90 border-[#222222] text-[#888] hover:text-[#ccc] hover:bg-[#161616]'
          }`}
        >
          {persona === 'admin' ? (
            <Shield className="w-3.5 h-3.5 text-amber-400" />
          ) : (
            <User className="w-3.5 h-3.5 text-[#888]" />
          )}
          <span className="font-mono text-[11px] uppercase hidden sm:inline">
            {persona === 'admin' ? 'Admin' : 'User'}
          </span>
        </button>

        {/* SIH TRAVEL REPLAY DEMO (ONLY VISIBLE FOR ADMIN PERSONA) */}
        {persona === 'admin' && (
          <button
            id="btn-open-sih-demo"
            onClick={onOpenSIHDemo}
            title="Open SIH Travel Replay & Telemetry Demonstration"
            className="bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl px-3 py-2 text-xs font-bold shadow-lg shadow-emerald-600/30 transition-all flex items-center gap-1.5 cursor-pointer animate-pulse"
          >
            <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
            <span>SIH Demo</span>
          </button>
        )}

        {/* Intelligence Telemetry Dashboard */}
        <button
          id="btn-open-intelligence-dashboard"
          onClick={onOpenIntelligence}
          title="NaviSync Intelligence Telemetry"
          className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl px-3 py-2 text-xs font-semibold shadow-lg shadow-blue-600/25 transition-all flex items-center gap-1.5"
        >
          <Cpu className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">NaviSync Intelligence</span>
        </button>
      </div>
    </header>
  );
};

