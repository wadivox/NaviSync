import React, { useState } from 'react';
import { SIHBenchmarkMetrics, SIHJourneySummary, SIHExperimentRecord } from '../../types/sihReplay';
import { globalExperimentService } from '../../services/ExperimentHistoryService';
import {
  ShieldCheck,
  AlertTriangle,
  Download,
  FileText,
  BookmarkPlus,
  CheckCircle2,
  TrendingUp,
  Award,
  Sparkles
} from 'lucide-react';

interface SIHBenchmarkCardProps {
  summary: SIHJourneySummary;
  metrics: SIHBenchmarkMetrics;
  onOpenHistory?: () => void;
  onExportCSV: () => void;
  onExportReport: () => void;
}

export const SIHBenchmarkCard: React.FC<SIHBenchmarkCardProps> = ({
  summary,
  metrics,
  onOpenHistory,
  onExportCSV,
  onExportReport
}) => {
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveExperiment = async () => {
    const experimentId = `SIH-EXP-${Date.now().toString(36).toUpperCase()}`;
    const record: SIHExperimentRecord = {
      id: experimentId,
      date: new Date().toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' }),
      timestamp: Date.now(),
      routeName: summary.routeName,
      startLocation: summary.startLocation,
      endLocation: summary.destinationLocation,
      distanceKm: metrics.distanceTravelledKm,
      durationMinutes: metrics.durationMin,
      outageDurationSec: metrics.gnssOutageSec,
      averageSpeedKmh: metrics.averageSpeedKmh,
      maxSpeedKmh: metrics.maxSpeedKmh,
      baselineErrorM: metrics.baselineFinalErrorM,
      navisyncErrorM: metrics.navisyncFinalErrorM,
      baselineDriftPct: metrics.baselineDriftPct,
      navisyncDriftPct: metrics.navisyncDriftPct,
      baselineRmseM: metrics.baselineRmseM,
      navisyncRmseM: metrics.navisyncRmseM,
      improvementPct: metrics.improvementPct,
      sihTargetMet: metrics.isWithinTarget
    };

    await globalExperimentService.saveExperiment(record);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  return (
    <div className="bg-[#0e0e12] border border-[#22222a] rounded-2xl p-5 text-white shadow-2xl flex flex-col gap-5">
      {/* Title & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#202028] pb-4">
        <div>
          <div className="text-[10px] font-mono uppercase tracking-widest text-amber-400 font-bold">
            SIH Problem Statement SIH26168
          </div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            Performance Benchmark &amp; Telemetry Audit
          </h2>
        </div>

        {/* Experiment Buttons */}
        <div className="flex items-center gap-2">
          <button
            id="btn-sih-save-experiment"
            onClick={handleSaveExperiment}
            className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-600/30 flex items-center gap-1.5 transition-all cursor-pointer"
          >
            {savedSuccess ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                <span>SAVED!</span>
              </>
            ) : (
              <>
                <BookmarkPlus className="w-3.5 h-3.5" />
                <span>SAVE EXPERIMENT</span>
              </>
            )}
          </button>

          <button
            id="btn-sih-export-csv"
            onClick={onExportCSV}
            className="px-3 py-2 rounded-xl bg-[#17171f] hover:bg-[#22222a] text-[#ddd] hover:text-white border border-[#2a2a35] text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Export Raw Replay Telemetry CSV"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>EXPORT CSV</span>
          </button>

          <button
            id="btn-sih-export-report"
            onClick={onExportReport}
            className="px-3 py-2 rounded-xl bg-[#17171f] hover:bg-[#22222a] text-[#ddd] hover:text-white border border-[#2a2a35] text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Export Evaluator Summary Report"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>EXPORT REPORT</span>
          </button>
        </div>
      </div>

      {/* CORE STATS 3-COLUMN GRID */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Column 1: Journey Statistics */}
        <div className="bg-[#131319] border border-[#22222d] rounded-xl p-4 flex flex-col justify-between">
          <div className="text-xs font-bold font-mono text-[#aaa] uppercase border-b border-[#1f1f28] pb-2 mb-3">
            Journey Statistics
          </div>
          <div className="space-y-2.5 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-[#888]">Distance Travelled:</span>
              <strong className="text-white">{metrics.distanceTravelledKm.toFixed(1)} km</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-[#888]">Duration:</span>
              <strong className="text-white">{metrics.durationMin} min</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-[#888]">Average Speed:</span>
              <strong className="text-white">{metrics.averageSpeedKmh.toFixed(1)} km/h</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-[#888]">Maximum Speed:</span>
              <strong className="text-white">{metrics.maxSpeedKmh.toFixed(1)} km/h</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-[#888]">GNSS Outage Time:</span>
              <strong className="text-rose-400">{metrics.gnssOutageSec} sec</strong>
            </div>
          </div>
        </div>

        {/* Column 2: Baseline Dead Reckoning */}
        <div className="bg-[#191114] border border-rose-900/40 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold font-mono text-rose-400 uppercase border-b border-rose-900/40 pb-2 mb-3 flex items-center justify-between">
              <span>Baseline Dead Reckoning</span>
              <span className="text-[10px] px-1.5 py-0.2 bg-rose-950 text-rose-300 rounded border border-rose-800">
                Unconstrained
              </span>
            </div>
            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-[#aaa]">Final Position Error:</span>
                <strong className="text-rose-400">{metrics.baselineFinalErrorM.toFixed(1)} m</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-[#aaa]">RMSE (Error Spread):</span>
                <strong className="text-rose-400">{metrics.baselineRmseM.toFixed(1)} m</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-[#aaa]">Measured Drift:</span>
                <strong className="text-rose-400 font-bold">{metrics.baselineDriftPct.toFixed(2)}%</strong>
              </div>
            </div>
          </div>
          <div className="mt-3 text-[11px] text-rose-300/80 bg-rose-950/40 p-2 rounded border border-rose-900/30 leading-snug">
            Fails due to unbounded gyro bias &amp; lack of map matching / ZUPT clamping.
          </div>
        </div>

        {/* Column 3: NaviSync Pipeline */}
        <div className="bg-[#0f1715] border border-emerald-900/50 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold font-mono text-emerald-400 uppercase border-b border-emerald-900/40 pb-2 mb-3 flex items-center justify-between">
              <span>NaviSync Pipeline</span>
              <span className="text-[10px] px-1.5 py-0.2 bg-emerald-950 text-emerald-300 rounded border border-emerald-800">
                AI + ZUPT + NHC
              </span>
            </div>
            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-[#aaa]">Final Position Error:</span>
                <strong className="text-emerald-400">{metrics.navisyncFinalErrorM.toFixed(1)} m</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-[#aaa]">RMSE (Error Spread):</span>
                <strong className="text-emerald-400">{metrics.navisyncRmseM.toFixed(1)} m</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-[#aaa]">Measured Drift:</span>
                <strong className="text-emerald-400 font-bold">{metrics.navisyncDriftPct.toFixed(2)}%</strong>
              </div>
            </div>
          </div>
          <div className="mt-3 text-[11px] text-emerald-300/90 bg-emerald-950/40 p-2 rounded border border-emerald-900/30 flex items-center justify-between">
            <span className="font-semibold">Performance Advantage:</span>
            <strong className="text-sm font-mono font-bold text-emerald-300">
              +{metrics.improvementPct.toFixed(1)}%
            </strong>
          </div>
        </div>
      </div>

      {/* PERFORMANCE BENCHMARK CARD */}
      <div className={`rounded-xl p-4 border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
        metrics.isWithinTarget
          ? 'bg-emerald-950/30 border-emerald-500/60 text-emerald-100'
          : 'bg-amber-950/30 border-amber-500/60 text-amber-100'
      }`}>
        <div className="flex items-start gap-3">
          <div className={`p-2.5 rounded-xl border mt-0.5 ${
            metrics.isWithinTarget
              ? 'bg-emerald-900/60 border-emerald-600 text-emerald-300'
              : 'bg-amber-900/60 border-amber-600 text-amber-300'
          }`}>
            {metrics.isWithinTarget ? (
              <ShieldCheck className="w-6 h-6" />
            ) : (
              <AlertTriangle className="w-6 h-6" />
            )}
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider font-mono text-[#aaa]">
              NaviSync Benchmark Compliance
            </div>
            <div className="text-base font-extrabold text-white mt-0.5 flex items-center gap-2">
              <span>SIH Target: &lt;{metrics.sihTargetPct}% Drift</span>
              <span className="text-xs text-[#888]">|</span>
              <span className="text-emerald-400">Measured: {metrics.navisyncDriftPct.toFixed(2)}%</span>
            </div>
            <p className="text-xs text-[#bbb] mt-1">
              {metrics.isWithinTarget
                ? 'NaviSync strictly conforms to Smart India Hackathon requirements with bounded drift.'
                : 'Current prototype exceeds the target. Further optimization required.'}
            </p>
          </div>
        </div>

        {/* Status Badge */}
        <div className={`px-4 py-2 rounded-xl text-xs font-mono font-bold uppercase tracking-wider border shadow-lg ${
          metrics.isWithinTarget
            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500 shadow-emerald-950/50'
            : 'bg-amber-500/20 text-amber-300 border-amber-500 shadow-amber-950/50'
        }`}>
          {metrics.isWithinTarget ? '✓ WITHIN TARGET' : '⚠ ABOVE TARGET'}
        </div>
      </div>
    </div>
  );
};
