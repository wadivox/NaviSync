import React, { useState } from 'react';
import { SIHReplayFrame } from '../../types/sihReplay';

interface SIHTelemetryChartsProps {
  frames: SIHReplayFrame[];
  currentFrameIndex: number;
  onSeek: (frameIndex: number) => void;
}

export const SIHTelemetryCharts: React.FC<SIHTelemetryChartsProps> = ({
  frames,
  currentFrameIndex,
  onSeek
}) => {
  const [activeTab, setActiveTab] = useState<'error' | 'speed' | 'heading' | 'gnss'>('error');

  const width = 800;
  const height = 220;
  const padding = { top: 25, right: 30, bottom: 35, left: 55 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const totalFrames = frames.length;
  const currentFrame = frames[currentFrameIndex] || frames[0];

  // Outage boundaries
  const outageStartFrame = 28;
  const outageEndFrame = 68;

  const outageStartX = padding.left + (outageStartFrame / (totalFrames - 1)) * chartW;
  const outageEndX = padding.left + (outageEndFrame / (totalFrames - 1)) * chartW;
  const currentScrubX = padding.left + (currentFrameIndex / (totalFrames - 1)) * chartW;

  // 1. Position Error Chart
  const maxError = 80; // meters
  const getYError = (err: number) => padding.top + chartH - (Math.min(maxError, err) / maxError) * chartH;

  const baselinePath = frames.reduce((acc, f, i) => {
    const x = padding.left + (i / (totalFrames - 1)) * chartW;
    const y = getYError(f.baselineDR.errorMeters);
    return `${acc} ${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }, '');

  const navisyncPath = frames.reduce((acc, f, i) => {
    const x = padding.left + (i / (totalFrames - 1)) * chartW;
    const y = getYError(f.navisync.errorMeters);
    return `${acc} ${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }, '');

  // 2. Speed Chart
  const maxSpeed = 70; // km/h
  const getYSpeed = (spd: number) => padding.top + chartH - (Math.min(maxSpeed, spd) / maxSpeed) * chartH;

  const gnssSpeedSegments: string[] = [];
  let currentSegment = '';
  frames.forEach((f, i) => {
    const x = padding.left + (i / (totalFrames - 1)) * chartW;
    if (f.gnssReading.speedKmh !== null) {
      const y = getYSpeed(f.gnssReading.speedKmh);
      if (!currentSegment) {
        currentSegment = `M ${x.toFixed(1)} ${y.toFixed(1)}`;
      } else {
        currentSegment += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
      }
    } else {
      if (currentSegment) {
        gnssSpeedSegments.push(currentSegment);
        currentSegment = '';
      }
    }
  });
  if (currentSegment) gnssSpeedSegments.push(currentSegment);

  const navisyncSpeedPath = frames.reduce((acc, f, i) => {
    const x = padding.left + (i / (totalFrames - 1)) * chartW;
    const y = getYSpeed(f.navisync.speedKmh);
    return `${acc} ${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }, '');

  // 3. Heading Chart
  const minHeading = 260;
  const maxHeading = 315;
  const getYHeading = (hd: number) => padding.top + chartH - ((hd - minHeading) / (maxHeading - minHeading)) * chartH;

  const gtHeadingPath = frames.reduce((acc, f, i) => {
    const x = padding.left + (i / (totalFrames - 1)) * chartW;
    const y = getYHeading(f.groundTruth.headingDeg);
    return `${acc} ${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }, '');

  const navisyncHeadingPath = frames.reduce((acc, f, i) => {
    const x = padding.left + (i / (totalFrames - 1)) * chartW;
    const y = getYHeading(f.navisync.headingDeg);
    return `${acc} ${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }, '');

  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const scaleX = width / rect.width;
    const adjustedX = clickX * scaleX;
    if (adjustedX >= padding.left && adjustedX <= width - padding.right) {
      const ratio = (adjustedX - padding.left) / chartW;
      const targetIndex = Math.round(ratio * (totalFrames - 1));
      onSeek(Math.max(0, Math.min(totalFrames - 1, targetIndex)));
    }
  };

  return (
    <div className="bg-[#0f0f11] border border-[#222225] rounded-xl p-4 shadow-xl text-white">
      {/* Tab Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#222225] pb-3 mb-3">
        <div className="flex items-center gap-1.5 bg-[#17171a] p-1 rounded-lg border border-[#26262b]">
          <button
            onClick={() => setActiveTab('error')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'error'
                ? 'bg-rose-600 text-white shadow-md'
                : 'text-[#999] hover:text-white hover:bg-[#202025]'
            }`}
          >
            Position Error vs Time
          </button>
          <button
            onClick={() => setActiveTab('speed')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'speed'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-[#999] hover:text-white hover:bg-[#202025]'
            }`}
          >
            Speed Telemetry vs Time
          </button>
          <button
            onClick={() => setActiveTab('heading')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'heading'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-[#999] hover:text-white hover:bg-[#202025]'
            }`}
          >
            Heading vs Time
          </button>
          <button
            onClick={() => setActiveTab('gnss')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'gnss'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-[#999] hover:text-white hover:bg-[#202025]'
            }`}
          >
            GNSS State Timeline
          </button>
        </div>

        {/* Live Values readout for chart */}
        <div className="text-xs font-mono flex items-center gap-3">
          <span className="text-[#888]">Time: <strong className="text-white">{currentFrame.timeFormatted}</strong></span>
          {activeTab === 'error' && (
            <>
              <span className="text-rose-400">Baseline: <strong>{currentFrame.baselineDR.errorMeters.toFixed(1)}m</strong></span>
              <span className="text-emerald-400">NaviSync: <strong>{currentFrame.navisync.errorMeters.toFixed(1)}m</strong></span>
            </>
          )}
          {activeTab === 'speed' && (
            <>
              <span className="text-blue-400">GNSS: <strong>{currentFrame.gnssReading.speedKmh !== null ? `${currentFrame.gnssReading.speedKmh.toFixed(1)} km/h` : 'OFFLINE'}</strong></span>
              <span className="text-emerald-400">NaviSync: <strong>{currentFrame.navisync.speedKmh.toFixed(1)} km/h</strong></span>
            </>
          )}
          {activeTab === 'heading' && (
            <>
              <span className="text-blue-400">True: <strong>{currentFrame.groundTruth.headingDeg}°</strong></span>
              <span className="text-emerald-400">NaviSync: <strong>{currentFrame.navisync.headingDeg}°</strong></span>
            </>
          )}
        </div>
      </div>

      {/* SVG Chart Surface */}
      <div className="relative w-full overflow-hidden select-none cursor-crosshair">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-56 block"
          onClick={handleSvgClick}
        >
          {/* Shaded Outage Window */}
          <rect
            x={outageStartX}
            y={padding.top}
            width={outageEndX - outageStartX}
            height={chartH}
            fill="#e11d48"
            fillOpacity="0.08"
            stroke="#f43f5e"
            strokeWidth="1"
            strokeDasharray="4 3"
            strokeOpacity="0.4"
          />
          <text
            x={(outageStartX + outageEndX) / 2}
            y={padding.top + 14}
            fill="#f43f5e"
            fontSize="10"
            fontFamily="monospace"
            textAnchor="middle"
            fontWeight="bold"
          >
            GNSS OUTAGE ZONE (40s Subterranean Underpass)
          </text>

          {/* Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const y = padding.top + chartH * (1 - ratio);
            return (
              <g key={ratio}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#26262e"
                  strokeDasharray="2 2"
                />
              </g>
            );
          })}

          {/* TAB 1: POSITION ERROR */}
          {activeTab === 'error' && (
            <>
              {/* Y Axis Labels */}
              {[0, 20, 40, 60, 80].map((val) => (
                <text
                  key={val}
                  x={padding.left - 8}
                  y={getYError(val) + 4}
                  fill="#777"
                  fontSize="10"
                  fontFamily="monospace"
                  textAnchor="end"
                >
                  {val}m
                </text>
              ))}

              {/* SIH Target line at 10% drift (~ 7m error at distance) */}
              <line
                x1={padding.left}
                y1={getYError(10)}
                x2={width - padding.right}
                y2={getYError(10)}
                stroke="#10b981"
                strokeWidth="1"
                strokeDasharray="4 2"
              />
              <text
                x={width - padding.right - 5}
                y={getYError(10) - 4}
                fill="#10b981"
                fontSize="9"
                fontFamily="monospace"
                textAnchor="end"
              >
                SIH Target (&lt;10% Drift)
              </text>

              {/* Baseline Path */}
              <path
                d={baselinePath}
                fill="none"
                stroke="#f43f5e"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* NaviSync Path */}
              <path
                d={navisyncPath}
                fill="none"
                stroke="#10b981"
                strokeWidth="3"
                strokeLinecap="round"
              />
            </>
          )}

          {/* TAB 2: SPEED TELEMETRY */}
          {activeTab === 'speed' && (
            <>
              {[0, 20, 40, 60].map((val) => (
                <text
                  key={val}
                  x={padding.left - 8}
                  y={getYSpeed(val) + 4}
                  fill="#777"
                  fontSize="10"
                  fontFamily="monospace"
                  textAnchor="end"
                >
                  {val}k
                </text>
              ))}

              {/* GNSS Speed (cuts off during outage) */}
              {gnssSpeedSegments.map((seg, idx) => (
                <path
                  key={idx}
                  d={seg}
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="2.5"
                  strokeDasharray="4 2"
                />
              ))}

              {/* NaviSync Speed (continuous inertial estimation) */}
              <path
                d={navisyncSpeedPath}
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Annotation during outage */}
              <text
                x={(outageStartX + outageEndX) / 2}
                y={padding.top + 60}
                fill="#888"
                fontSize="10"
                fontFamily="monospace"
                textAnchor="middle"
              >
                GNSS Speed unavailable — NaviSync IMU velocity maintains track
              </text>
            </>
          )}

          {/* TAB 3: HEADING */}
          {activeTab === 'heading' && (
            <>
              {[260, 280, 300].map((val) => (
                <text
                  key={val}
                  x={padding.left - 8}
                  y={getYHeading(val) + 4}
                  fill="#777"
                  fontSize="10"
                  fontFamily="monospace"
                  textAnchor="end"
                >
                  {val}°
                </text>
              ))}

              <path
                d={gtHeadingPath}
                fill="none"
                stroke="#3b82f6"
                strokeWidth="2"
                strokeDasharray="3 3"
              />
              <path
                d={navisyncHeadingPath}
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
            </>
          )}

          {/* TAB 4: GNSS STATE TIMELINE */}
          {activeTab === 'gnss' && (
            <g>
              {/* Available block 1 */}
              <rect
                x={padding.left}
                y={padding.top + 30}
                width={outageStartX - padding.left}
                height={24}
                fill="#10b981"
                rx={4}
              />
              <text
                x={(padding.left + outageStartX) / 2}
                y={padding.top + 46}
                fill="#fff"
                fontSize="10"
                fontFamily="monospace"
                fontWeight="bold"
                textAnchor="middle"
              >
                AVAILABLE (14 Satellites, HDOP 0.9)
              </text>

              {/* Lost block */}
              <rect
                x={outageStartX}
                y={padding.top + 70}
                width={outageEndX - outageStartX}
                height={24}
                fill="#ef4444"
                rx={4}
              />
              <text
                x={(outageStartX + outageEndX) / 2}
                y={padding.top + 86}
                fill="#fff"
                fontSize="10"
                fontFamily="monospace"
                fontWeight="bold"
                textAnchor="middle"
              >
                LOST (0 Satellites — Dead Reckoning Active)
              </text>

              {/* Restored block */}
              <rect
                x={outageEndX}
                y={padding.top + 110}
                width={width - padding.right - outageEndX}
                height={24}
                fill="#3b82f6"
                rx={4}
              />
              <text
                x={(outageEndX + width - padding.right) / 2}
                y={padding.top + 126}
                fill="#fff"
                fontSize="10"
                fontFamily="monospace"
                fontWeight="bold"
                textAnchor="middle"
              >
                RESTORED (Re-converged)
              </text>
            </g>
          )}

          {/* Time Scrubber vertical line */}
          <line
            x1={currentScrubX}
            y1={padding.top}
            x2={currentScrubX}
            y2={padding.top + chartH}
            stroke="#ffffff"
            strokeWidth="2"
            strokeDasharray="3 2"
          />
          <circle
            cx={currentScrubX}
            cy={
              activeTab === 'error'
                ? getYError(currentFrame.navisync.errorMeters)
                : activeTab === 'speed'
                ? getYSpeed(currentFrame.navisync.speedKmh)
                : activeTab === 'heading'
                ? getYHeading(currentFrame.navisync.headingDeg)
                : padding.top + chartH / 2
            }
            r={5}
            fill="#10b981"
            stroke="#ffffff"
            strokeWidth="2"
          />

          {/* X Axis Time markers */}
          {[0, 15, 30, 45, 60, 75, 89].map((sec) => {
            const x = padding.left + (sec / (totalFrames - 1)) * chartW;
            const min = Math.floor(sec / 60);
            const rem = sec % 60;
            const label = `${min.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
            return (
              <text
                key={sec}
                x={x}
                y={padding.top + chartH + 18}
                fill="#888"
                fontSize="10"
                fontFamily="monospace"
                textAnchor="middle"
              >
                {label}
              </text>
            );
          })}
        </svg>
      </div>

      {/* Interactive Legend */}
      <div className="flex flex-wrap items-center justify-between text-xs text-[#999] pt-2 border-t border-[#1d1d22] mt-2">
        <div className="flex items-center gap-4">
          {activeTab === 'error' && (
            <>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-rose-500 rounded" />
                <span className="text-white font-medium">Basic Dead Reckoning (Divergent)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-emerald-500 rounded" />
                <span className="text-white font-medium">NaviSync (ZUPT + Map Matching + NHC)</span>
              </div>
            </>
          )}
          {activeTab === 'speed' && (
            <>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-blue-500 rounded" />
                <span className="text-white font-medium">GNSS Speed (Drops to offline in outage)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-emerald-500 rounded" />
                <span className="text-white font-medium">NaviSync Estimated Speed (Continuous)</span>
              </div>
            </>
          )}
          {activeTab === 'heading' && (
            <>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-blue-500 rounded" />
                <span className="text-white font-medium">Reference Ground Truth Heading</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-emerald-500 rounded" />
                <span className="text-white font-medium">NaviSync Gyroscope + Alignment Heading</span>
              </div>
            </>
          )}
        </div>
        <div className="text-[11px] text-[#666] font-mono">
          Click anywhere on graph to seek
        </div>
      </div>
    </div>
  );
};
