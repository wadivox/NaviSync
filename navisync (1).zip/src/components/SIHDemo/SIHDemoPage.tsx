import React, { useState, useEffect, useRef } from 'react';
import {
  SIH_REPLAY_FRAMES,
  SIH_JOURNEY_SUMMARY,
  SIH_DEFAULT_METRICS,
  calculateSIHBenchmarkMetrics
} from '../../data/sihReplayData';
import { SIHReplayMap } from './SIHReplayMap';
import { SIHJourneyTimeline } from './SIHJourneyTimeline';
import { SIHLiveTelemetryPanel } from './SIHLiveTelemetryPanel';
import { SIHTelemetryCharts } from './SIHTelemetryCharts';
import { SIHBenchmarkCard } from './SIHBenchmarkCard';
import { SIHTravelSummaryModal } from './SIHTravelSummaryModal';
import { SIHExperimentHistoryModal } from './SIHExperimentHistoryModal';
import { globalExperimentService } from '../../services/ExperimentHistoryService';
import {
  ArrowLeft,
  Sparkles,
  Zap,
  Activity,
  History,
  Download,
  FileText,
  BookmarkPlus,
  ShieldCheck,
  CheckCircle2,
  Compass,
  Layers,
  Award
} from 'lucide-react';

interface SIHDemoPageProps {
  onBackToRealNavigation: () => void;
}

export const SIHDemoPage: React.FC<SIHDemoPageProps> = ({ onBackToRealNavigation }) => {
  const [currentFrameIndex, setCurrentFrameIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1); // 1x, 2x, 4x
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  const animationTimerRef = useRef<number | null>(null);

  const totalFrames = SIH_REPLAY_FRAMES.length;
  const currentFrame = SIH_REPLAY_FRAMES[currentFrameIndex] || SIH_REPLAY_FRAMES[0];
  const metrics = SIH_DEFAULT_METRICS;
  const summary = SIH_JOURNEY_SUMMARY;

  // Animation playback loop
  useEffect(() => {
    if (!isPlaying) {
      if (animationTimerRef.current) {
        clearInterval(animationTimerRef.current);
        animationTimerRef.current = null;
      }
      return;
    }

    const intervalMs = Math.round(500 / playbackSpeed); // default 500ms per 1s sim step at 1x
    animationTimerRef.current = window.setInterval(() => {
      setCurrentFrameIndex((prev) => {
        if (prev >= totalFrames - 1) {
          setIsPlaying(false);
          setShowSummaryModal(true);
          return prev;
        }
        return prev + 1;
      });
    }, intervalMs);

    return () => {
      if (animationTimerRef.current) {
        clearInterval(animationTimerRef.current);
      }
    };
  }, [isPlaying, playbackSpeed, totalFrames]);

  const handleTogglePlay = () => {
    if (currentFrameIndex >= totalFrames - 1) {
      setCurrentFrameIndex(0);
    }
    setIsPlaying((prev) => !prev);
  };

  const handleRestart = () => {
    setCurrentFrameIndex(0);
    setIsPlaying(true);
    setShowSummaryModal(false);
  };

  const handleCycleSpeed = () => {
    setPlaybackSpeed((prev) => (prev === 1 ? 2 : prev === 2 ? 4 : 1));
  };

  const handleSeek = (index: number) => {
    setCurrentFrameIndex(Math.max(0, Math.min(totalFrames - 1, index)));
  };

  const handleExportCSV = () => {
    globalExperimentService.exportCSV(SIH_REPLAY_FRAMES);
  };

  const handleExportReport = () => {
    globalExperimentService.exportReport(summary, metrics);
  };

  const handleSaveExperiment = async () => {
    const experimentId = `SIH-EXP-${Date.now().toString(36).toUpperCase()}`;
    await globalExperimentService.saveExperiment({
      id: experimentId,
      date: new Date().toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' }),
      timestamp: Date.now(),
      routeName: summary.routeName,
      startLocation: summary.startLocation,
      endLocation: summary.destinationLocation,
      distanceKm: metrics.distanceTravelledKm,
      durationMinutes: metrics.durationMin,
      outageDurationSec: metrics.gnssOutageSec,
      averageSpeedKmh: metrics.averageSpeedKmh,
      maxSpeedKmh: metrics.maxSpeedKmh,
      baselineErrorM: metrics.baselineFinalErrorM,
      navisyncErrorM: metrics.navisyncFinalErrorM,
      baselineDriftPct: metrics.baselineDriftPct,
      navisyncDriftPct: metrics.navisyncDriftPct,
      baselineRmseM: metrics.baselineRmseM,
      navisyncRmseM: metrics.navisyncRmseM,
      improvementPct: metrics.improvementPct,
      sihTargetMet: metrics.isWithinTarget
    });
    alert(`Experiment ${experimentId} saved to local IndexedDB storage.`);
  };

  return (
    <div className="min-h-screen bg-[#070709] text-[#e0e0e0] flex flex-col font-sans pb-16">
      {/* 1. TOP NAVBAR / HEADER WITH ADMIN PERSONA INDICATOR */}
      <header className="sticky top-0 z-40 bg-[#0d0d12]/95 border-b border-[#1f1f28] backdrop-blur-xl px-4 py-3 flex items-center justify-between shadow-2xl">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToRealNavigation}
            className="px-3 py-1.5 rounded-xl bg-[#171720] hover:bg-[#22222d] text-white border border-[#262635] text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-emerald-400" />
            <span>Live Navigation</span>
          </button>

          <div className="h-4 w-px bg-[#262633]" />

          {/* Admin Mode Badge */}
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
              ADMIN PERSONA • SIH DEMO MODE
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowHistoryModal(true)}
            className="px-3 py-1.5 rounded-xl bg-[#14141d] hover:bg-[#20202c] text-[#ccc] hover:text-white border border-[#252535] text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <History className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">Experiment History</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 rounded-xl bg-[#14141d] hover:bg-[#20202c] text-emerald-300 border border-emerald-900/60 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Export CSV</span>
          </button>

          <button
            onClick={handleExportReport}
            className="px-3 py-1.5 rounded-xl bg-[#14141d] hover:bg-[#20202c] text-amber-300 border border-amber-900/60 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Export Report</span>
          </button>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="max-w-7xl mx-auto w-full px-3 sm:px-6 py-5 flex flex-col gap-6">
        {/* SECTION 1: TRAVEL REPLAY OVERVIEW BANNER */}
        <div className="bg-[#0e0e13] border border-[#22222d] rounded-2xl p-5 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-full bg-gradient-to-l from-blue-900/10 via-emerald-900/5 to-transparent pointer-events-none" />

          <div className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold mb-1">
            Smart India Hackathon • Problem Statement SIH26168
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            NAVISYNC JOURNEY REPLAY
          </h1>

          {/* Journey Header Card Required in Spec */}
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 items-center bg-[#13131b] border border-[#242432] rounded-xl p-4">
            {/* Route path */}
            <div className="space-y-1 font-mono">
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                <span>Hyderabad (Lakdikapul / Mehdipatnam)</span>
              </div>
              <div className="pl-1 text-[#666] text-xs font-bold leading-none">
                ↓ (Via Tolichowki &amp; Shaikpet Underpass)
              </div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <span>Gachibowli (Bio-Diversity Junction)</span>
              </div>
            </div>

            {/* Top Stat Specs */}
            <div className="grid grid-cols-3 gap-2 text-xs font-mono border-t md:border-t-0 md:border-l border-[#242432] pt-3 md:pt-0 md:pl-4">
              <div>
                <span className="text-[#888] block text-[10px] uppercase">Distance</span>
                <strong className="text-white text-sm">{summary.distanceKm.toFixed(1)} km</strong>
              </div>
              <div>
                <span className="text-[#888] block text-[10px] uppercase">Duration</span>
                <strong className="text-white text-sm">{summary.durationMinutes} min</strong>
              </div>
              <div>
                <span className="text-[#888] block text-[10px] uppercase">Avg Speed</span>
                <strong className="text-white text-sm">{summary.averageSpeedKmh.toFixed(0)} km/h</strong>
              </div>
              <div className="mt-1">
                <span className="text-[#888] block text-[10px] uppercase">Max Speed</span>
                <strong className="text-white text-sm">{summary.maxSpeedKmh.toFixed(0)} km/h</strong>
              </div>
              <div className="mt-1">
                <span className="text-emerald-400 block text-[10px] uppercase">GNSS Avail</span>
                <strong className="text-emerald-300 text-sm">{summary.gnssAvailabilityPct}%</strong>
              </div>
              <div className="mt-1">
                <span className="text-rose-400 block text-[10px] uppercase">GNSS Outage</span>
                <strong className="text-rose-300 text-sm">{summary.gnssOutageSeconds} sec</strong>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 2 & 4: MAP VISUALIZATION + LIVE REPLAY TELEMETRY */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left / Center: Interactive Map & Timeline */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            <SIHReplayMap frames={SIH_REPLAY_FRAMES} currentFrameIndex={currentFrameIndex} />

            {/* SECTION 3: JOURNEY TIMELINE UNDERNEATH MAP */}
            <SIHJourneyTimeline
              frames={SIH_REPLAY_FRAMES}
              currentFrameIndex={currentFrameIndex}
              isPlaying={isPlaying}
              playbackSpeed={playbackSpeed}
              onTogglePlay={handleTogglePlay}
              onRestart={handleRestart}
              onCycleSpeed={handleCycleSpeed}
              onSeek={handleSeek}
            />
          </div>

          {/* Right: Live Replay Telemetry Panel */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <SIHLiveTelemetryPanel frame={currentFrame} />

            {/* Quick Benchmark Mini-Card */}
            <div className="bg-[#0f0f14] border border-[#232330] rounded-2xl p-4 text-xs font-mono space-y-2">
              <div className="text-[10px] text-[#888] uppercase font-bold">
                SIH Benchmark Spec (SIH26168)
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#aaa]">Target Threshold:</span>
                <span className="text-white font-bold">&lt; 10% Drift</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#aaa]">Current NaviSync Drift:</span>
                <span className="text-emerald-400 font-bold">
                  {currentFrame.navisync.accumulatedDriftPct.toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#aaa]">Baseline Conventional Drift:</span>
                <span className="text-rose-400 font-bold">
                  {currentFrame.baselineDR.accumulatedDriftPct.toFixed(2)}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 9-12: ANALYTICAL TELEMETRY GRAPHS */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#aaa] font-mono">
              Synchronized Telemetry Curves
            </h2>
            <span className="text-xs text-[#666] font-mono">
              Continuous IMU Double-Integration vs AI Filter
            </span>
          </div>
          <SIHTelemetryCharts
            frames={SIH_REPLAY_FRAMES}
            currentFrameIndex={currentFrameIndex}
            onSeek={handleSeek}
          />
        </div>

        {/* SECTION 7, 8, 14, 15: PERFORMANCE STATISTICS & BENCHMARK AUDIT */}
        <SIHBenchmarkCard
          summary={summary}
          metrics={metrics}
          onOpenHistory={() => setShowHistoryModal(true)}
          onExportCSV={handleExportCSV}
          onExportReport={handleExportReport}
        />
      </main>

      {/* TRAVEL SUMMARY MODAL (Section 13) */}
      {showSummaryModal && (
        <SIHTravelSummaryModal
          summary={summary}
          metrics={metrics}
          onClose={() => setShowSummaryModal(false)}
          onRestart={handleRestart}
          onSaveExperiment={handleSaveExperiment}
          onExportCSV={handleExportCSV}
          onExportReport={handleExportReport}
        />
      )}

      {/* EXPERIMENT HISTORY MODAL (Section 14) */}
      {showHistoryModal && (
        <SIHExperimentHistoryModal onClose={() => setShowHistoryModal(false)} />
      )}
    </div>
  );
};
