import React, { useEffect, useState } from 'react';
import { SIHExperimentRecord } from '../../types/sihReplay';
import { globalExperimentService } from '../../services/ExperimentHistoryService';
import {
  History,
  X,
  Trash2,
  FileText,
  Download,
  ShieldCheck,
  AlertTriangle,
  Award,
  Calendar,
  MapPin
} from 'lucide-react';

interface SIHExperimentHistoryModalProps {
  onClose: () => void;
}

export const SIHExperimentHistoryModal: React.FC<SIHExperimentHistoryModalProps> = ({ onClose }) => {
  const [experiments, setExperiments] = useState<SIHExperimentRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadExperiments();
  }, []);

  const loadExperiments = async () => {
    setLoading(true);
    const data = await globalExperimentService.getExperiments();
    setExperiments(data);
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    await globalExperimentService.deleteExperiment(id);
    await loadExperiments();
  };

  return (
    <div className="fixed inset-0 z-[1200] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#0f0f13] border border-[#262632] rounded-3xl max-w-3xl w-full p-6 shadow-2xl text-white relative flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#22222d] pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600/20 border border-blue-500/40 text-blue-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Saved Experiment History</h2>
              <p className="text-xs text-[#888]">
                Review previously recorded evaluator runs and benchmark telemetry results
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#888] hover:text-white hover:bg-[#1a1a22] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto py-4 space-y-3">
          {loading ? (
            <div className="text-center py-12 text-xs text-[#888] font-mono">
              Loading saved experiments from IndexedDB...
            </div>
          ) : experiments.length === 0 ? (
            <div className="text-center py-12 text-[#888] space-y-2">
              <History className="w-8 h-8 mx-auto text-[#555]" />
              <p className="text-sm font-medium">No saved experiments found yet</p>
              <p className="text-xs text-[#666]">
                Click "SAVE EXPERIMENT" on the SIH Demo page to store benchmarks here.
              </p>
            </div>
          ) : (
            experiments.map((exp) => (
              <div
                key={exp.id}
                className="bg-[#14141c] border border-[#232330] rounded-2xl p-4 hover:border-[#353545] transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#1e1e28] text-amber-300 border border-[#303040]">
                      {exp.id}
                    </span>
                    <span className="text-xs text-[#888] flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {exp.date}
                    </span>
                    {exp.sihTargetMet ? (
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-400" />
                        TARGET MET
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-800 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-amber-400" />
                        ABOVE TARGET
                      </span>
                    )}
                  </div>

                  <div className="text-sm font-bold text-white flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-blue-400" />
                    <span>{exp.startLocation} → {exp.endLocation}</span>
                  </div>

                  {/* Metric Chips */}
                  <div className="flex flex-wrap items-center gap-3 text-xs font-mono pt-1 text-[#aaa]">
                    <span>Dist: <strong className="text-white">{exp.distanceKm.toFixed(1)}km</strong></span>
                    <span>Outage: <strong className="text-rose-400">{exp.outageDurationSec}s</strong></span>
                    <span>NaviSync Drift: <strong className="text-emerald-400">{exp.navisyncDriftPct.toFixed(2)}%</strong></span>
                    <span>Baseline Drift: <strong className="text-rose-400">{exp.baselineDriftPct.toFixed(2)}%</strong></span>
                    <span>Improvement: <strong className="text-emerald-300">+{exp.improvementPct.toFixed(1)}%</strong></span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => handleDelete(exp.id)}
                    className="p-2 rounded-xl text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 transition-colors border border-transparent hover:border-rose-800/40"
                    title="Delete Experiment Record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-[#20202a] pt-3 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#1a1a24] hover:bg-[#252533] text-white text-xs font-bold border border-[#2d2d3c] transition-all cursor-pointer"
          >
            Close History
          </button>
        </div>
      </div>
    </div>
  );
};
