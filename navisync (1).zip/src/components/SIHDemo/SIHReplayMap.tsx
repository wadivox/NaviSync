import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { SIHReplayFrame } from '../../types/sihReplay';
import { Layers, Maximize2, Compass, MapPin } from 'lucide-react';

interface SIHReplayMapProps {
  frames: SIHReplayFrame[];
  currentFrameIndex: number;
}

const CARTO_API_KEY = (import.meta.env.VITE_CARTO_API_KEY as string) || 'cb1_2wsb_1_1ce327a00cc6c5aedcb3471b';

export const SIHReplayMap: React.FC<SIHReplayMapProps> = ({ frames, currentFrameIndex }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);

  // Layer references
  const groundTruthPolylineRef = useRef<L.Polyline | null>(null);
  const baselinePolylineRef = useRef<L.Polyline | null>(null);
  const navisyncPolylineRef = useRef<L.Polyline | null>(null);

  // Marker references
  const navisyncMarkerRef = useRef<L.Marker | null>(null);
  const baselineMarkerRef = useRef<L.Marker | null>(null);
  const groundTruthMarkerRef = useRef<L.Marker | null>(null);

  const [followMode, setFollowMode] = useState(true);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    const initialCenter: [number, number] = [17.4168, 78.3942]; // Shaikpet corridor center
    const map = L.map(mapContainerRef.current, {
      center: initialCenter,
      zoom: 13,
      zoomControl: false
    });

    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // Dark Map Tiles
    L.tileLayer(`https://{s}.basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}{r}.png?key=${CARTO_API_KEY}`, {
      subdomains: 'abcd',
      maxZoom: 20,
      attribution: '&copy; OpenStreetMap &copy; CARTO'
    }).addTo(map);

    // Add Start & End Pin Markers
    const startPoint = frames[0]?.groundTruth;
    const endPoint = frames[frames.length - 1]?.groundTruth;

    if (startPoint) {
      const startIcon = L.divIcon({
        className: 'start-pin-icon',
        html: `<div style="background:#10b981;width:12px;height:12px;border-radius:50%;border:2px solid #ffffff;box-shadow:0 0 8px rgba(16,185,129,0.8);"></div>`,
        iconSize: [12, 12],
        iconAnchor: [6, 6]
      });
      L.marker([startPoint.lat, startPoint.lng], { icon: startIcon })
        .bindTooltip('START: Hyderabad (Mehdipatnam)', { permanent: true, direction: 'top', className: 'sih-map-tooltip' })
        .addTo(map);
    }

    if (endPoint) {
      const endIcon = L.divIcon({
        className: 'end-pin-icon',
        html: `<div style="background:#ef4444;width:12px;height:12px;border-radius:50%;border:2px solid #ffffff;box-shadow:0 0 8px rgba(239,68,68,0.8);"></div>`,
        iconSize: [12, 12],
        iconAnchor: [6, 6]
      });
      L.marker([endPoint.lat, endPoint.lng], { icon: endIcon })
        .bindTooltip('DESTINATION: Gachibowli', { permanent: true, direction: 'top', className: 'sih-map-tooltip' })
        .addTo(map);
    }

    // Outage Zone Corridor Rectangle / Banner (Shaikpet Underpass)
    const outageBounds: L.LatLngBoundsExpression = [
      [17.4089, 78.4015],
      [17.4342, 78.3582]
    ];
    L.rectangle(outageBounds, {
      color: '#f43f5e',
      weight: 1,
      dashArray: '6 4',
      fillColor: '#e11d48',
      fillOpacity: 0.12
    })
      .bindTooltip('GNSS OUTAGE ZONE (Shaikpet Subterranean Underpass — 40s)', {
        permanent: true,
        direction: 'center',
        className: 'sih-outage-tooltip'
      })
      .addTo(map);

    // Complete Ground Truth Background Polyline (Ghost)
    const allGTPositions: [number, number][] = frames.map((f) => [f.groundTruth.lat, f.groundTruth.lng]);
    L.polyline(allGTPositions, {
      color: '#3b82f6',
      weight: 3,
      opacity: 0.35,
      dashArray: '4 4'
    }).addTo(map);

    // Active Polyline Layers
    groundTruthPolylineRef.current = L.polyline([], {
      color: '#3b82f6',
      weight: 4,
      opacity: 0.9
    }).addTo(map);

    baselinePolylineRef.current = L.polyline([], {
      color: '#f43f5e',
      weight: 3,
      dashArray: '5 5',
      opacity: 0.9
    }).addTo(map);

    navisyncPolylineRef.current = L.polyline([], {
      color: '#10b981',
      weight: 5,
      opacity: 0.95
    }).addTo(map);

    // Initial Marker Setup
    const vehicleIcon = L.divIcon({
      className: 'navisync-vehicle-arrow',
      html: `<div id="sih-nav-arrow" style="transform: rotate(0deg); transition: transform 0.1s linear; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;">
        <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
          <circle cx="17" cy="17" r="16" fill="rgba(16, 185, 129, 0.25)" stroke="#10b981" stroke-width="1.5" />
          <path d="M17 5L25 25L17 20L9 25L17 5Z" fill="#10b981" stroke="#ffffff" stroke-width="1.5" stroke-linejoin="round" />
        </svg>
      </div>`,
      iconSize: [36, 36],
      iconAnchor: [18, 18]
    });

    const baselineIcon = L.divIcon({
      className: 'baseline-vehicle-dot',
      html: `<div style="background:#f43f5e;width:14px;height:14px;border-radius:50%;border:2px solid #ffffff;box-shadow:0 0 10px rgba(244,63,94,0.9);"></div>`,
      iconSize: [14, 14],
      iconAnchor: [7, 7]
    });

    const gtIcon = L.divIcon({
      className: 'gt-vehicle-dot',
      html: `<div style="background:#3b82f6;width:10px;height:10px;border-radius:50%;border:1.5px solid #ffffff;"></div>`,
      iconSize: [10, 10],
      iconAnchor: [5, 5]
    });

    navisyncMarkerRef.current = L.marker(initialCenter, { icon: vehicleIcon, zIndexOffset: 1000 }).addTo(map);
    baselineMarkerRef.current = L.marker(initialCenter, { icon: baselineIcon, zIndexOffset: 900 }).addTo(map);
    groundTruthMarkerRef.current = L.marker(initialCenter, { icon: gtIcon, zIndexOffset: 800 }).addTo(map);

    mapRef.current = map;

    // Fit initial route
    map.fitBounds(L.latLngBounds(allGTPositions), { padding: [40, 40] });

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Update Dynamic Replay Positions
  useEffect(() => {
    const map = mapRef.current;
    if (!map || frames.length === 0) return;

    const frame = frames[currentFrameIndex] || frames[0];
    const subFrames = frames.slice(0, currentFrameIndex + 1);

    // Update Polylines
    const gtCoords: [number, number][] = subFrames.map((f) => [f.groundTruth.lat, f.groundTruth.lng]);
    const baselineCoords: [number, number][] = subFrames.map((f) => [f.baselineDR.lat, f.baselineDR.lng]);
    const navisyncCoords: [number, number][] = subFrames.map((f) => [f.navisync.lat, f.navisync.lng]);

    if (groundTruthPolylineRef.current) groundTruthPolylineRef.current.setLatLngs(gtCoords);
    if (baselinePolylineRef.current) baselinePolylineRef.current.setLatLngs(baselineCoords);
    if (navisyncPolylineRef.current) navisyncPolylineRef.current.setLatLngs(navisyncCoords);

    // Update Markers
    if (navisyncMarkerRef.current) {
      navisyncMarkerRef.current.setLatLng([frame.navisync.lat, frame.navisync.lng]);
      const arrowElem = document.getElementById('sih-nav-arrow');
      if (arrowElem) {
        arrowElem.style.transform = `rotate(${frame.navisync.headingDeg}deg)`;
      }
    }

    if (baselineMarkerRef.current) {
      baselineMarkerRef.current.setLatLng([frame.baselineDR.lat, frame.baselineDR.lng]);
    }

    if (groundTruthMarkerRef.current) {
      groundTruthMarkerRef.current.setLatLng([frame.groundTruth.lat, frame.groundTruth.lng]);
    }

    // Follow Mode Centering
    if (followMode) {
      map.panTo([frame.navisync.lat, frame.navisync.lng], { animate: true, duration: 0.2 });
    }
  }, [currentFrameIndex, frames, followMode]);

  const handleFitRoute = () => {
    if (!mapRef.current || frames.length === 0) return;
    const allCoords: [number, number][] = frames.map((f) => [f.groundTruth.lat, f.groundTruth.lng]);
    mapRef.current.fitBounds(L.latLngBounds(allCoords), { padding: [40, 40] });
    setFollowMode(false);
  };

  return (
    <div className="relative w-full h-[400px] lg:h-[480px] rounded-2xl overflow-hidden border border-[#22222a] shadow-2xl">
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* Floating Legend */}
      <div className="absolute top-3 left-3 z-[1000] bg-[#0c0c10]/92 border border-[#23232c] rounded-xl p-3 shadow-xl backdrop-blur-md text-xs text-white">
        <div className="text-[10px] uppercase font-mono text-[#888] font-bold mb-2">
          Replay Trajectory Legend
        </div>
        <div className="flex flex-col gap-1.5 font-medium">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-blue-500 inline-block border border-white/50" />
            <span className="text-[#ddd]">Ground Truth / Reference</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-500 inline-block border border-white/50" />
            <span className="text-[#ddd]">Basic Dead Reckoning (Diverges)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block border border-white/50" />
            <span className="text-[#ddd] font-bold">NaviSync (True-Track Constraint)</span>
          </div>
        </div>
      </div>

      {/* Map Control Buttons */}
      <div className="absolute top-3 right-3 z-[1000] flex flex-col gap-2">
        <button
          onClick={() => setFollowMode(!followMode)}
          className={`p-2 rounded-xl text-xs font-semibold shadow-xl backdrop-blur-md border transition-all flex items-center gap-1.5 ${
            followMode
              ? 'bg-emerald-600 text-white border-emerald-500'
              : 'bg-[#121217]/90 text-[#ccc] border-[#252530] hover:bg-[#1a1a22]'
          }`}
          title="Toggle Auto-Follow Vehicle"
        >
          <Compass className="w-4 h-4" />
          <span className="text-[11px]">{followMode ? 'Following' : 'Free Cam'}</span>
        </button>

        <button
          onClick={handleFitRoute}
          className="p-2 rounded-xl text-xs font-semibold shadow-xl backdrop-blur-md bg-[#121217]/90 text-[#ccc] border border-[#252530] hover:bg-[#1a1a22] transition-all flex items-center gap-1.5"
          title="Fit Full Hyderabad Corridor"
        >
          <Maximize2 className="w-4 h-4" />
          <span className="text-[11px]">Overview</span>
        </button>
      </div>

      {/* Location Badge */}
      <div className="absolute bottom-3 left-3 z-[1000] bg-[#0c0c10]/90 border border-[#22222a] rounded-lg px-3 py-1.5 text-xs text-[#bbb] flex items-center gap-2 backdrop-blur-md">
        <MapPin className="w-3.5 h-3.5 text-emerald-400" />
        <span className="font-mono text-white">
          {frames[currentFrameIndex]?.locationName || 'Hyderabad Corridor'}
        </span>
      </div>
    </div>
  );
};
