import React from 'react';
import { SIHReplayFrame } from '../../types/sihReplay';
import {
  Play,
  Pause,
  RotateCcw,
  FastForward,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Satellite
} from 'lucide-react';

interface SIHJourneyTimelineProps {
  frames: SIHReplayFrame[];
  currentFrameIndex: number;
  isPlaying: boolean;
  playbackSpeed: number;
  onTogglePlay: () => void;
  onRestart: () => void;
  onCycleSpeed: () => void;
  onSeek: (index: number) => void;
}

export const SIHJourneyTimeline: React.FC<SIHJourneyTimelineProps> = ({
  frames,
  currentFrameIndex,
  isPlaying,
  playbackSpeed,
  onTogglePlay,
  onRestart,
  onCycleSpeed,
  onSeek
}) => {
  const totalFrames = frames.length;
  const currentFrame = frames[currentFrameIndex] || frames[0];

  const outageStart = 28;
  const outageEnd = 68;

  const outageLeftPct = (outageStart / (totalFrames - 1)) * 100;
  const outageWidthPct = ((outageEnd - outageStart) / (totalFrames - 1)) * 100;
  const currentProgressPct = (currentFrameIndex / (totalFrames - 1)) * 100;

  return (
    <div className="bg-[#0e0e12] border border-[#202028] rounded-2xl p-4 text-white shadow-2xl flex flex-col gap-3">
      {/* Control Buttons & Replay State Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Buttons: Play, Pause, Restart, Speed */}
        <div className="flex items-center gap-2">
          <button
            id="btn-sih-play-pause"
            onClick={onTogglePlay}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-all cursor-pointer active:scale-95"
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-white" />
                <span>PAUSE</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                <span>PLAY JOURNEY</span>
              </>
            )}
          </button>

          <button
            id="btn-sih-restart"
            onClick={onRestart}
            className="p-2 rounded-xl bg-[#17171d] hover:bg-[#22222b] text-[#ccc] hover:text-white border border-[#2a2a35] transition-all cursor-pointer"
            title="Restart Journey Replay"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            id="btn-sih-speed"
            onClick={onCycleSpeed}
            className="px-3 py-2 rounded-xl bg-[#17171d] hover:bg-[#22222b] text-amber-300 border border-[#2a2a35] text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Toggle Playback Speed"
          >
            <FastForward className="w-3.5 h-3.5 text-amber-400" />
            <span>{playbackSpeed}X SPEED</span>
          </button>
        </div>

        {/* Current Time Readout */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="bg-[#14141a] border border-[#252532] px-3 py-1.5 rounded-lg flex items-center gap-2">
            <span className="text-[#888]">Timeline:</span>
            <span className="text-white font-bold">{currentFrame.timeFormatted}</span>
            <span className="text-[#666]">/</span>
            <span className="text-[#aaa]">{frames[totalFrames - 1]?.timeFormatted}</span>
          </div>

          {/* Current Active Phase Tag */}
          <div className="hidden sm:flex items-center">
            {currentFrame.phase === 'GNSS_AVAILABLE' && (
              <span className="px-2.5 py-1 rounded-md bg-emerald-950 text-emerald-300 border border-emerald-700/60 text-[11px] font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                GNSS AVAILABLE
              </span>
            )}
            {currentFrame.phase === 'DEAD_RECKONING' && (
              <span className="px-2.5 py-1 rounded-md bg-red-950 text-red-300 border border-red-700/60 text-[11px] font-bold flex items-center gap-1.5 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-red-500" />
                🔴 GNSS LOST • 🟡 DEAD RECKONING
              </span>
            )}
            {currentFrame.phase === 'GNSS_RESTORED' && (
              <span className="px-2.5 py-1 rounded-md bg-blue-950 text-blue-300 border border-blue-700/60 text-[11px] font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-400" />
                GNSS RESTORED
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Progress Track & Scrubber */}
      <div className="relative pt-4 pb-2">
        {/* Timeline Bar Track */}
        <div className="relative h-4 bg-[#14141c] rounded-full overflow-hidden border border-[#272733] cursor-pointer">
          {/* Outage Highlight Box (Shaikpet tunnel) */}
          <div
            className="absolute top-0 bottom-0 bg-red-600/40 border-x-2 border-red-500"
            style={{
              left: `${outageLeftPct}%`,
              width: `${outageWidthPct}%`
            }}
            title="GNSS Denied Zone (Shaikpet Underpass)"
          />

          {/* Played progress fill */}
          <div
            className="h-full bg-gradient-to-r from-blue-600 via-emerald-500 to-emerald-400 opacity-60 transition-all duration-75"
            style={{ width: `${currentProgressPct}%` }}
          />
        </div>

        {/* Interactive Native Range Scrubber */}
        <input
          type="range"
          min={0}
          max={totalFrames - 1}
          value={currentFrameIndex}
          onChange={(e) => onSeek(Number(e.target.value))}
          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
          aria-label="Seek journey replay"
        />

        {/* Phase Milestone Markers Under Track */}
        <div className="relative mt-2 text-[10px] font-mono flex items-center justify-between text-[#777]">
          {/* 00:00 START */}
          <div className="flex flex-col items-start">
            <span className="text-[#aaa]">00:00</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              🟢 GNSS AVAILABLE
            </span>
          </div>

          {/* 00:28 OUTAGE */}
          <div
            className="absolute flex flex-col items-center"
            style={{ left: `${outageLeftPct}%`, transform: 'translateX(-50%)' }}
          >
            <span className="text-red-400 font-bold">00:28</span>
            <span className="text-red-300 font-bold flex items-center gap-1">
              🔴 GNSS LOST
            </span>
          </div>

          {/* 01:08 RESTORED */}
          <div
            className="absolute flex flex-col items-center"
            style={{ left: `${outageLeftPct + outageWidthPct}%`, transform: 'translateX(-50%)' }}
          >
            <span className="text-blue-400 font-bold">01:08</span>
            <span className="text-blue-300 font-bold flex items-center gap-1">
              🟢 RESTORED
            </span>
          </div>

          {/* END */}
          <div className="flex flex-col items-end">
            <span className="text-[#aaa]">{frames[totalFrames - 1]?.timeFormatted}</span>
            <span className="text-emerald-400 font-bold">ARRIVED</span>
          </div>
        </div>
      </div>
    </div>
  );
};
