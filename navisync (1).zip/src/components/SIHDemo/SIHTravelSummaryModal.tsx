import React from 'react';
import { SIHBenchmarkMetrics, SIHJourneySummary } from '../../types/sihReplay';
import {
  CheckCircle2,
  X,
  Award,
  Sparkles,
  ShieldCheck,
  RotateCcw,
  Download,
  FileText,
  BookmarkPlus
} from 'lucide-react';

interface SIHTravelSummaryModalProps {
  summary: SIHJourneySummary;
  metrics: SIHBenchmarkMetrics;
  onClose: () => void;
  onRestart: () => void;
  onSaveExperiment: () => void;
  onExportCSV: () => void;
  onExportReport: () => void;
}

export const SIHTravelSummaryModal: React.FC<SIHTravelSummaryModalProps> = ({
  summary,
  metrics,
  onClose,
  onRestart,
  onSaveExperiment,
  onExportCSV,
  onExportReport
}) => {
  return (
    <div className="fixed inset-0 z-[1200] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#0f0f13] border border-[#262632] rounded-3xl max-w-xl w-full p-6 shadow-2xl text-white relative flex flex-col gap-5">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-[#888] hover:text-white hover:bg-[#1a1a22] transition-colors"
          title="Close summary"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Badge & Title */}
        <div className="text-center pt-2">
          <div className="inline-flex p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 mb-3 shadow-lg shadow-emerald-950/50">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div className="text-[11px] font-mono uppercase tracking-widest text-emerald-400 font-bold">
            Evaluation Run Complete
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            NAVISYNC JOURNEY COMPLETE
          </h2>
          <div className="text-sm font-semibold text-[#bbb] mt-1">
            Hyderabad → Gachibowli
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-[#14141c] border border-[#232330] rounded-2xl p-4 text-center font-mono">
          <div>
            <div className="text-[10px] text-[#888] uppercase">Distance</div>
            <div className="text-base font-bold text-white mt-0.5">
              {metrics.distanceTravelledKm.toFixed(1)} km
            </div>
          </div>
          <div>
            <div className="text-[10px] text-[#888] uppercase">Duration</div>
            <div className="text-base font-bold text-white mt-0.5">
              {metrics.durationMin} min
            </div>
          </div>
          <div>
            <div className="text-[10px] text-[#888] uppercase">Avg Speed</div>
            <div className="text-base font-bold text-white mt-0.5">
              {metrics.averageSpeedKmh.toFixed(0)} km/h
            </div>
          </div>
          <div>
            <div className="text-[10px] text-[#888] uppercase">Max Speed</div>
            <div className="text-base font-bold text-white mt-0.5">
              {metrics.maxSpeedKmh.toFixed(0)} km/h
            </div>
          </div>

          <div className="pt-2 border-t border-[#22222e]">
            <div className="text-[10px] text-rose-400 uppercase">GNSS Outage</div>
            <div className="text-sm font-bold text-rose-300 mt-0.5">
              {metrics.gnssOutageSec} sec
            </div>
          </div>
          <div className="pt-2 border-t border-[#22222e]">
            <div className="text-[10px] text-emerald-400 uppercase">NaviSync Drift</div>
            <div className="text-sm font-bold text-emerald-300 mt-0.5">
              {metrics.navisyncDriftPct.toFixed(2)}%
            </div>
          </div>
          <div className="pt-2 border-t border-[#22222e]">
            <div className="text-[10px] text-[#aaa] uppercase">Position Error</div>
            <div className="text-sm font-bold text-white mt-0.5">
              {metrics.navisyncFinalErrorM.toFixed(1)} m
            </div>
          </div>
          <div className="pt-2 border-t border-[#22222e]">
            <div className="text-[10px] text-[#aaa] uppercase">Confidence</div>
            <div className="text-sm font-bold text-purple-300 mt-0.5">
              98%
            </div>
          </div>
        </div>

        {/* Highlight Banner */}
        <div className="bg-emerald-950/40 border border-emerald-500/50 rounded-2xl p-4 text-center">
          <div className="text-xs font-mono font-bold text-emerald-300 uppercase tracking-wider flex items-center justify-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            NAVISYNC SUCCESSFULLY MAINTAINED NAVIGATION DURING GNSS OUTAGE
          </div>
          <p className="text-[11px] text-emerald-200/80 mt-1">
            Zero telemetry loss during 40-second subterranean tunnel underpass with <strong>+{metrics.improvementPct.toFixed(1)}%</strong> lower error than conventional dead reckoning.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2 border-t border-[#20202a]">
          <button
            onClick={onRestart}
            className="px-4 py-2.5 rounded-xl bg-[#1c1c26] hover:bg-[#252533] text-white text-xs font-bold border border-[#2d2d3c] flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>REPLAY AGAIN</span>
          </button>

          <button
            onClick={onSaveExperiment}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/30 flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <BookmarkPlus className="w-4 h-4" />
            <span>SAVE EXPERIMENT</span>
          </button>

          <button
            onClick={onExportCSV}
            className="px-4 py-2.5 rounded-xl bg-[#1c1c26] hover:bg-[#252533] text-emerald-400 text-xs font-bold border border-[#2d2d3c] flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>EXPORT CSV</span>
          </button>

          <button
            onClick={onExportReport}
            className="px-4 py-2.5 rounded-xl bg-[#1c1c26] hover:bg-[#252533] text-amber-400 text-xs font-bold border border-[#2d2d3c] flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>EXPORT REPORT</span>
          </button>
        </div>
      </div>
    </div>
  );
};
