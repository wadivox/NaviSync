import React from 'react';
import { SIHReplayFrame } from '../../types/sihReplay';
import {
  Satellite,
  Gauge,
  Compass,
  Layers,
  Activity,
  ShieldCheck,
  Cpu,
  MapPin,
  Clock,
  AlertTriangle,
  Flame,
  CheckCircle2
} from 'lucide-react';

interface SIHLiveTelemetryPanelProps {
  frame: SIHReplayFrame;
}

export const SIHLiveTelemetryPanel: React.FC<SIHLiveTelemetryPanelProps> = ({ frame }) => {
  const isLost = frame.gnssReading.status === 'LOST';
  const isRestored = frame.gnssReading.status === 'RESTORED';
  const isAvailable = frame.gnssReading.status === 'AVAILABLE';

  return (
    <div className="bg-[#0e0e11] border border-[#1e1e24] rounded-2xl p-4 text-white shadow-2xl flex flex-col gap-4">
      {/* Top Status Header */}
      <div className="flex items-center justify-between border-b border-[#1c1c22] pb-3">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
          <span className="text-xs font-bold uppercase tracking-wider text-[#bbb]">
            Live Replay Telemetry
          </span>
        </div>

        {/* GNSS Status Badge */}
        <div className="flex items-center gap-2">
          {isLost && (
            <div className="px-3 py-1 rounded-lg bg-red-950/80 border border-red-500/80 text-red-300 text-xs font-mono font-bold flex items-center gap-1.5 animate-pulse shadow-lg shadow-red-900/30">
              <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
              <span>GNSS: LOST</span>
            </div>
          )}
          {isRestored && (
            <div className="px-3 py-1 rounded-lg bg-blue-950/80 border border-blue-500/80 text-blue-300 text-xs font-mono font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
              <span>GNSS: RESTORED</span>
            </div>
          )}
          {isAvailable && (
            <div className="px-3 py-1 rounded-lg bg-emerald-950/80 border border-emerald-500/80 text-emerald-300 text-xs font-mono font-bold flex items-center gap-1.5">
              <Satellite className="w-3.5 h-3.5 text-emerald-400" />
              <span>GNSS: AVAILABLE</span>
            </div>
          )}
        </div>
      </div>

      {/* OUTAGE ALERT BANNER (Active during outage) */}
      {isLost && (
        <div className="bg-red-950/40 border border-red-600/60 rounded-xl p-3 flex items-center justify-between text-red-200">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-red-900/60 border border-red-700/50">
              <Flame className="w-4 h-4 text-red-400 animate-bounce" />
            </div>
            <div>
              <div className="text-xs font-bold text-red-300 uppercase tracking-wide">
                Active GNSS Blackout (Underpass)
              </div>
              <div className="text-[11px] text-red-400/90 font-mono">
                NaviSync Inertial Dead Reckoning engaged
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] uppercase font-mono text-red-400">Outage Duration</div>
            <div className="text-sm font-mono font-bold text-white">
              +{frame.outageElapsedSec.toString().padStart(2, '0')}s
            </div>
          </div>
        </div>
      )}

      {/* Main Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {/* 1. POSITION */}
        <div className="bg-[#141419] border border-[#23232c] rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#888] text-[11px] font-medium">
            <span className="flex items-center gap-1">
              <MapPin className="w-3 h-3 text-blue-400" /> POSITION
            </span>
            <span className="text-[10px] font-mono text-[#666]">WGS84</span>
          </div>
          <div className="mt-2 font-mono text-xs text-white">
            <div>{frame.navisync.lat.toFixed(6)} N</div>
            <div className="text-[#aaa]">{frame.navisync.lng.toFixed(6)} E</div>
          </div>
        </div>

        {/* 2. SPEED */}
        <div className="bg-[#141419] border border-[#23232c] rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#888] text-[11px] font-medium">
            <span className="flex items-center gap-1">
              <Gauge className="w-3 h-3 text-emerald-400" /> SPEED
            </span>
            {frame.navisync.zuptActive && (
              <span className="text-[9px] px-1 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-800">
                ZUPT
              </span>
            )}
          </div>
          <div className="mt-2">
            <div className="font-mono text-xl font-extrabold text-white">
              {frame.navisync.speedKmh.toFixed(1)} <span className="text-xs font-normal text-[#888]">km/h</span>
            </div>
            <div className="text-[10px] font-mono text-[#777]">
              GNSS: {frame.gnssReading.speedKmh !== null ? `${frame.gnssReading.speedKmh.toFixed(1)}` : 'N/A'}
            </div>
          </div>
        </div>

        {/* 3. HEADING */}
        <div className="bg-[#141419] border border-[#23232c] rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#888] text-[11px] font-medium">
            <span className="flex items-center gap-1">
              <Compass className="w-3 h-3 text-amber-400" /> HEADING
            </span>
            <span className="text-[10px] font-mono text-[#777]">Yaw</span>
          </div>
          <div className="mt-2">
            <div className="font-mono text-xl font-extrabold text-white">
              {frame.navisync.headingDeg}°
            </div>
            <div className="text-[10px] font-mono text-[#777]">
              Gyro gz: {frame.imu.gz.toFixed(2)}°/s
            </div>
          </div>
        </div>

        {/* 4. NAVIGATION MODE */}
        <div className="bg-[#141419] border border-[#23232c] rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#888] text-[11px] font-medium">
            <span className="flex items-center gap-1">
              <Layers className="w-3 h-3 text-purple-400" /> NAV MODE
            </span>
          </div>
          <div className="mt-2">
            <div className={`font-mono text-xs font-bold leading-tight ${
              isLost ? 'text-amber-400' : isRestored ? 'text-blue-400' : 'text-emerald-400'
            }`}>
              {frame.navisync.navigationMode}
            </div>
            <div className="text-[10px] font-mono text-[#777] mt-0.5">
              Confidence: {frame.navisync.confidencePct}%
            </div>
          </div>
        </div>
      </div>

      {/* Sub-system Status Matrix */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-[#1a1a20]">
        {/* IMU */}
        <div className="bg-[#121217] rounded-lg px-3 py-2 border border-[#202028] flex items-center justify-between">
          <span className="text-xs text-[#999] flex items-center gap-1.5">
            <Activity className="w-3 h-3 text-blue-400" /> IMU
          </span>
          <span className="text-[11px] font-mono font-bold text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
            ACTIVE
          </span>
        </div>

        {/* AI MOTION FILTER */}
        <div className="bg-[#121217] rounded-lg px-3 py-2 border border-[#202028] flex items-center justify-between">
          <span className="text-xs text-[#999] flex items-center gap-1.5">
            <Cpu className="w-3 h-3 text-purple-400" /> AI FILTER
          </span>
          <span className="text-[11px] font-mono font-bold text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
            ACTIVE
          </span>
        </div>

        {/* MAP MATCHING */}
        <div className="bg-[#121217] rounded-lg px-3 py-2 border border-[#202028] flex items-center justify-between">
          <span className="text-xs text-[#999] flex items-center gap-1.5">
            <MapPin className="w-3 h-3 text-amber-400" /> MAP MATCH
          </span>
          <span className="text-[11px] font-mono font-bold text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
            ACTIVE
          </span>
        </div>

        {/* ZUPT */}
        <div className="bg-[#121217] rounded-lg px-3 py-2 border border-[#202028] flex items-center justify-between">
          <span className="text-xs text-[#999] flex items-center gap-1.5">
            <ShieldCheck className="w-3 h-3 text-teal-400" /> ZUPT
          </span>
          <span className={`text-[11px] font-mono font-bold ${
            frame.navisync.zuptActive ? 'text-amber-400' : 'text-[#666]'
          }`}>
            {frame.navisync.zuptActive ? 'CLAMPED' : 'INACTIVE'}
          </span>
        </div>
      </div>

      {/* Real-Time Error & Drift Comparison Card */}
      <div className="bg-[#121218] border border-[#22222d] rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-4">
          <div>
            <div className="text-[10px] text-[#777] uppercase font-mono">Estimated Drift</div>
            <div className="text-sm font-mono font-bold text-emerald-400">
              {frame.navisync.driftMeters.toFixed(1)} m{' '}
              <span className="text-[10px] font-normal text-[#888]">
                ({frame.navisync.accumulatedDriftPct.toFixed(1)}%)
              </span>
            </div>
          </div>
          <div className="border-l border-[#242430] pl-4">
            <div className="text-[10px] text-[#777] uppercase font-mono">Baseline Divergence</div>
            <div className="text-sm font-mono font-bold text-rose-400">
              {frame.baselineDR.errorMeters.toFixed(1)} m{' '}
              <span className="text-[10px] font-normal text-[#888]">
                ({frame.baselineDR.accumulatedDriftPct.toFixed(1)}%)
              </span>
            </div>
          </div>
        </div>

        {/* Live Improvement Badge */}
        {frame.baselineDR.errorMeters > 0.5 && (
          <div className="text-right">
            <div className="text-[10px] text-[#777] uppercase font-mono">Drift Suppression</div>
            <div className="text-xs font-mono font-bold text-emerald-300 bg-emerald-950/60 border border-emerald-700/50 px-2 py-0.5 rounded">
              +{Math.max(0, Math.round(((frame.baselineDR.errorMeters - frame.navisync.errorMeters) / frame.baselineDR.errorMeters) * 100))}%
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
