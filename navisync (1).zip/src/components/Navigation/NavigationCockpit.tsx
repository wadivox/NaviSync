import React from 'react';
import { RouteOption, FusionState, GNSSState, RouteStep, NaviSyncNavigationState } from '../../types/navigation';
import { TranslationDictionary } from '../../i18n/translations';
import {
  ArrowUp,
  ArrowUpLeft,
  ArrowUpRight,
  CornerUpLeft,
  CornerUpRight,
  RotateCcw,
  Volume2,
  VolumeX,
  X,
  Gauge,
  ShieldCheck,
  AlertTriangle,
  Radio,
  PauseCircle
} from 'lucide-react';

interface NavigationCockpitProps {
  route: RouteOption;
  currentStepIndex: number;
  fusionState: FusionState;
  navState?: NaviSyncNavigationState;
  gnssState: GNSSState;
  t: TranslationDictionary;
  voiceEnabled: boolean;
  onToggleVoice: () => void;
  onStopNavigation: () => void;
}

export const NavigationCockpit: React.FC<NavigationCockpitProps> = ({
  route,
  currentStepIndex,
  fusionState,
  navState,
  gnssState,
  t,
  voiceEnabled,
  onToggleVoice,
  onStopNavigation
}) => {
  const currentStep: RouteStep | undefined = route.steps[currentStepIndex] || route.steps[0];
  const nextStep: RouteStep | undefined = route.steps[currentStepIndex + 1];

  // Authoritative values from navState if provided
  const speedKmh = navState ? navState.speedKmh : fusionState.speedKmh;
  const confidence = navState ? navState.positionConfidence : fusionState.confidence;
  const isStationary = navState ? navState.isStationary : fusionState.isZuptActive;
  const driftMeters = navState ? navState.estimatedDriftMeters : fusionState.driftMeters;
  const speedSourceLabel = navState
    ? navState.speedSource === 'ZUPT_ZERO'
      ? 'ZUPT Stopped'
      : navState.speedSource === 'IMU_ESTIMATOR'
      ? 'IMU Estimator'
      : navState.speedSource === 'GNSS_DISPLACEMENT'
      ? 'GNSS Delta'
      : 'Live GNSS'
    : fusionState.isZuptActive
    ? 'ZUPT Stopped'
    : fusionState.activeEngine === 'INERTIAL_DEAD_RECKONING'
    ? 'IMU Estimator'
    : 'Live GNSS';

  // Maneuver Icon Resolver
  const renderManeuverIcon = (maneuver: RouteStep['maneuver'], size = 'w-9 h-9') => {
    switch (maneuver) {
      case 'turn-left':
        return <CornerUpLeft className={size} />;
      case 'turn-right':
        return <CornerUpRight className={size} />;
      case 'slight-left':
        return <ArrowUpLeft className={size} />;
      case 'slight-right':
        return <ArrowUpRight className={size} />;
      case 'u-turn':
        return <RotateCcw className={size} />;
      default:
        return <ArrowUp className={size} />;
    }
  };

  const isGNSSLost = gnssState === 'GNSS_LOST' || gnssState === 'NAVISYNC_INERTIAL';
  const isRestoring = gnssState === 'GNSS_RESTORING';

  return (
    <div className="absolute top-4 left-4 right-4 z-30 max-w-xl mx-auto flex flex-col gap-3 pointer-events-none">
      {/* 1. Primary Maneuver Card */}
      <div className="bg-[#0d0d0d]/95 border border-[#1f1f1f] shadow-2xl shadow-black/90 rounded-2xl p-4 text-[#e0e0e0] backdrop-blur-md pointer-events-auto flex items-center justify-between gap-4">
        {/* Maneuver Direction Icon */}
        <div className="w-16 h-16 rounded-xl bg-blue-600/15 border border-blue-500/30 text-blue-400 flex items-center justify-center shrink-0 shadow-inner">
          {renderManeuverIcon(currentStep.maneuver)}
        </div>

        {/* Turn Instruction Text */}
        <div className="flex-1 min-w-0">
          <div className="text-2xl font-bold tracking-tight text-white truncate font-mono">
            {currentStep.distanceMeters > 1000
              ? `${(currentStep.distanceMeters / 1000).toFixed(1)} km`
              : `${currentStep.distanceMeters} m`}
          </div>
          <div className="text-sm text-[#e0e0e0] font-medium truncate mt-0.5">
            {currentStep.instruction}
          </div>
          <div className="text-xs text-[#8e8e8e] truncate flex items-center gap-1.5 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
            <span>{currentStep.streetName}</span>
          </div>
        </div>

        {/* Top Controls: Voice Toggle & Stop Navigation */}
        <div className="flex flex-col gap-2 shrink-0">
          <button
            id="btn-voice-toggle"
            onClick={onToggleVoice}
            title="Toggle Voice Guidance"
            className={`p-2.5 rounded-lg border transition-all ${
              voiceEnabled
                ? 'bg-blue-600/20 border-blue-500/40 text-blue-400 hover:bg-blue-600/30'
                : 'bg-[#141414] border-[#1f1f1f] text-[#8e8e8e] hover:bg-[#1a1a1a]'
            }`}
          >
            {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            id="btn-stop-nav"
            onClick={onStopNavigation}
            title="Stop Navigation"
            className="p-2.5 rounded-lg bg-rose-500/15 border border-rose-500/40 text-rose-300 hover:bg-rose-500/25 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Secondary Preview Maneuver (if available) */}
      {nextStep && (
        <div className="bg-[#0d0d0d]/90 border border-[#1f1f1f] rounded-xl px-4 py-2 text-xs text-[#8e8e8e] backdrop-blur-sm pointer-events-auto flex items-center gap-2.5 shadow-md">
          <span className="text-[#666666] uppercase tracking-wider font-semibold text-[10px]">Then:</span>
          <div className="text-blue-400 shrink-0">{renderManeuverIcon(nextStep.maneuver, 'w-3.5 h-3.5')}</div>
          <span className="truncate text-[#a0a0a0]">{nextStep.instruction}</span>
        </div>
      )}

      {/* 3. GNSS & NaviSync Intelligence Status Pill Bar */}
      <div className="flex flex-wrap items-center gap-2 pointer-events-auto">
        {/* GNSS State Badge */}
        <div
          className={`px-3 py-1.5 rounded-full border text-xs font-semibold flex items-center gap-1.5 shadow-md backdrop-blur-md ${
            isGNSSLost
              ? 'bg-amber-950/90 border-amber-600/80 text-amber-300 animate-pulse'
              : isRestoring
              ? 'bg-cyan-950/90 border-cyan-600/80 text-cyan-300'
              : gnssState === 'GNSS_DEGRADED'
              ? 'bg-yellow-950/90 border-yellow-600/80 text-yellow-300'
              : 'bg-emerald-950/90 border-emerald-600/80 text-emerald-300'
          }`}
        >
          {isGNSSLost ? (
            <>
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{t.navisyncInertial}</span>
            </>
          ) : isRestoring ? (
            <>
              <Radio className="w-3.5 h-3.5" />
              <span>{t.gnssRestoring}</span>
            </>
          ) : (
            <>
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{gnssState.replace('_', ' ')}</span>
            </>
          )}
        </div>

        {/* ZUPT Active Badge */}
        {isStationary && (
          <div className="px-3 py-1.5 rounded-full bg-indigo-950/90 border border-indigo-500/80 text-indigo-200 text-xs font-semibold flex items-center gap-1.5 shadow-md">
            <PauseCircle className="w-3.5 h-3.5 text-indigo-400" />
            <span>{t.zuptActive}</span>
          </div>
        )}

        {/* Confidence Badge */}
        <div className="px-3 py-1.5 rounded-full bg-[#0d0d0d]/90 border border-[#1f1f1f] text-[#e0e0e0] text-xs font-mono flex items-center gap-1.5 shadow-md">
          <span className="text-[#8e8e8e] text-[10px] uppercase">Conf:</span>
          <span
            className={
              confidence >= 0.8
                ? 'text-emerald-400 font-bold'
                : confidence >= 0.6
                ? 'text-amber-400 font-bold'
                : 'text-rose-400 font-bold'
            }
          >
            {Math.round(confidence * 100)}%
          </span>
          {driftMeters > 0 && (
            <span className="text-[#8e8e8e] text-[11px] border-l border-[#1f1f1f] pl-1.5">
              Drift: <span className="text-amber-300 font-bold">{driftMeters}m</span>
            </span>
          )}
        </div>
      </div>

      {/* 4. Bottom Driving Cockpit Bar (Speedometer, Distance, ETA) */}
      <div className="fixed bottom-6 left-4 right-4 max-w-xl mx-auto bg-[#0d0d0d]/95 border border-[#1f1f1f] shadow-2xl shadow-black/90 rounded-2xl p-4 text-[#e0e0e0] backdrop-blur-md pointer-events-auto flex items-center justify-between">
        {/* Speedometer */}
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-full bg-[#141414] border-2 border-blue-500/40 flex flex-col items-center justify-center text-center shadow-inner">
            <span className="text-xl font-black text-white leading-none font-mono">
              {speedKmh === null || speedKmh === undefined || isNaN(speedKmh)
                ? '—'
                : speedKmh < 0.5
                ? '0'
                : Math.round(speedKmh)}
            </span>
            <span className="text-[9px] font-semibold uppercase text-[#8e8e8e] tracking-wider">km/h</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs text-[#8e8e8e] flex items-center gap-1">
              <Gauge className="w-3.5 h-3.5 text-blue-400" />
              <span>{speedSourceLabel}</span>
            </span>
            <span className="text-xs text-emerald-400 font-medium">Limit: 80 km/h</span>
          </div>
        </div>

        {/* Route Stats (Remaining Distance & ETA) */}
        <div className="text-right">
          <div className="text-2xl font-bold text-white font-mono">
            {route.durationMinutes} <span className="text-sm font-normal text-[#8e8e8e]">min</span>
          </div>
          <div className="text-xs text-[#8e8e8e] flex items-center justify-end gap-2 mt-0.5">
            <span>{route.distanceKm} km</span>
            <span>•</span>
            <span className="text-emerald-400">
              ETA {new Date(Date.now() + route.durationMinutes * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
