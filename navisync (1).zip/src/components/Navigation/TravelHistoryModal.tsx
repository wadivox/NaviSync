import React, { useState, useEffect } from 'react';
import {
  globalTravelHistoryService,
  TravelHistoryRecord
} from '../../services/TravelHistoryService';
import { NavigationMode } from '../../types/navigation';
import {
  Car,
  Bike,
  Footprints,
  Calendar,
  Clock,
  Trash2,
  MapPin,
  X,
  History,
  Navigation,
  Download,
  AlertTriangle,
  ShieldCheck,
  Zap,
  ChevronRight,
  TrendingUp
} from 'lucide-react';

interface TravelHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onReopenTripRoute: (entry: TravelHistoryRecord) => void;
}

export const TravelHistoryModal: React.FC<TravelHistoryModalProps> = ({
  isOpen,
  onClose,
  onReopenTripRoute
}) => {
  const [trips, setTrips] = useState<TravelHistoryRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [confirmClearAll, setConfirmClearAll] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState<TravelHistoryRecord | null>(null);

  const loadTrips = async () => {
    setIsLoading(true);
    try {
      const data = await globalTravelHistoryService.getTrips();
      setTrips(data);
    } catch (err) {
      console.error('Failed to load trips', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadTrips();
      setConfirmClearAll(false);
      setSelectedTrip(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDeleteTrip = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await globalTravelHistoryService.deleteTrip(id);
    setTrips((prev) => prev.filter((t) => t.id !== id));
    if (selectedTrip?.id === id) setSelectedTrip(null);
  };

  const handleClearAll = async () => {
    await globalTravelHistoryService.clearAll();
    setTrips([]);
    setSelectedTrip(null);
    setConfirmClearAll(false);
  };

  const handleExportJSON = async () => {
    const jsonStr = await globalTravelHistoryService.exportHistoryJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `navisync-travel-history-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getModeIcon = (mode: NavigationMode) => {
    switch (mode) {
      case 'driving':
        return <Car className="w-4 h-4 text-blue-400" />;
      case 'two_wheeler':
        return <Bike className="w-4 h-4 text-amber-400" />;
      case 'cycling':
        return <Bike className="w-4 h-4 text-emerald-400" />;
      case 'walking':
        return <Footprints className="w-4 h-4 text-purple-400" />;
      default:
        return <Car className="w-4 h-4 text-blue-400" />;
    }
  };

  const totalDistanceKm = trips.reduce((acc, t) => acc + (t.distanceKm || 0), 0);
  const totalMinutes = trips.reduce((acc, t) => acc + (t.durationMinutes || 0), 0);
  const avgSpeed = trips.length > 0
    ? Math.round((trips.reduce((acc, t) => acc + (t.averageSpeedKmh || 0), 0) / trips.length) * 10) / 10
    : 0;
  const longestTrip = trips.length > 0
    ? Math.max(...trips.map((t) => t.distanceKm || 0))
    : 0;

  return (
    <div
      id="travel-history-backdrop"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        id="travel-history-container"
        className="bg-[#0e0e0e] border border-[#222222] rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl shadow-black text-[#e0e0e0] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#1c1c1c] flex items-center justify-between bg-[#141414]/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 shadow-inner">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Travel History &amp; Journey Logs
              </h2>
              <p className="text-xs text-[#888888]">
                Local-first encrypted IndexedDB storage • Trajectory recording &amp; GNSS outage tracking
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {trips.length > 0 && (
              <button
                id="btn-export-history"
                onClick={handleExportJSON}
                title="Export Travel History (JSON)"
                className="p-2 rounded-xl bg-[#1a1a1a] hover:bg-[#252525] border border-[#262626] text-[#aaa] hover:text-white transition-colors flex items-center gap-1.5 text-xs"
              >
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Export</span>
              </button>
            )}
            <button
              id="btn-close-travel-history"
              onClick={onClose}
              className="p-2 rounded-xl text-[#888888] hover:text-white hover:bg-[#202020] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Summary Stats Strip (Requirement 23) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 px-4 py-3 bg-[#0a0a0a] border-b border-[#1a1a1a] text-center">
          <div className="p-2.5 rounded-xl bg-[#121212] border border-[#1e1e1e]">
            <div className="text-[10px] uppercase font-semibold text-[#777]">Total Trips</div>
            <div className="text-base sm:text-lg font-black text-white font-mono mt-0.5">{trips.length}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-[#121212] border border-[#1e1e1e]">
            <div className="text-[10px] uppercase font-semibold text-[#777]">Total Distance</div>
            <div className="text-base sm:text-lg font-black text-blue-400 font-mono mt-0.5">
              {totalDistanceKm.toFixed(1)} <span className="text-xs font-normal text-[#888]">km</span>
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-[#121212] border border-[#1e1e1e]">
            <div className="text-[10px] uppercase font-semibold text-[#777]">Driving Time</div>
            <div className="text-base sm:text-lg font-black text-emerald-400 font-mono mt-0.5">
              {Math.floor(totalMinutes / 60)}h {totalMinutes % 60}m
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-[#121212] border border-[#1e1e1e]">
            <div className="text-[10px] uppercase font-semibold text-[#777]">Avg / Longest</div>
            <div className="text-base sm:text-lg font-black text-purple-400 font-mono mt-0.5">
              {avgSpeed} <span className="text-xs font-normal text-[#888]">km/h</span> / {longestTrip.toFixed(1)}k
            </div>
          </div>
        </div>

        {/* Trip Detail Sub-Modal or List */}
        {selectedTrip ? (
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
            <button
              onClick={() => setSelectedTrip(null)}
              className="self-start text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 font-semibold"
            >
              ← Back to All Trips
            </button>

            {/* Trip Detailed Card */}
            <div className="p-4 rounded-xl bg-[#141414] border border-[#222] flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className="text-base font-bold text-white flex items-center gap-2">
                  <span>{selectedTrip.startLocation}</span>
                  <span className="text-[#666]">→</span>
                  <span>{selectedTrip.endLocation}</span>
                </div>
                <span className="text-xs text-[#888] font-mono">{selectedTrip.dateFormatted}</span>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-[#1f1f1f]">
                <div className="bg-[#0f0f0f] p-2.5 rounded-lg border border-[#1a1a1a]">
                  <span className="text-[10px] text-[#777] uppercase block">Distance</span>
                  <span className="text-sm font-bold text-white font-mono">{selectedTrip.distanceKm} km</span>
                </div>
                <div className="bg-[#0f0f0f] p-2.5 rounded-lg border border-[#1a1a1a]">
                  <span className="text-[10px] text-[#777] uppercase block">Duration</span>
                  <span className="text-sm font-bold text-white font-mono">{selectedTrip.durationMinutes} min</span>
                </div>
                <div className="bg-[#0f0f0f] p-2.5 rounded-lg border border-[#1a1a1a]">
                  <span className="text-[10px] text-[#777] uppercase block">Avg / Max Speed</span>
                  <span className="text-sm font-bold text-blue-400 font-mono">
                    {Math.round(selectedTrip.averageSpeedKmh)} / {Math.round(selectedTrip.maxSpeedKmh)} km/h
                  </span>
                </div>
                <div className="bg-[#0f0f0f] p-2.5 rounded-lg border border-[#1a1a1a]">
                  <span className="text-[10px] text-[#777] uppercase block">GNSS Availability</span>
                  <span className="text-sm font-bold text-emerald-400 font-mono">
                    {selectedTrip.gnssAvailabilityPercentage}%
                  </span>
                </div>
              </div>

              {/* GNSS Outage Breakdown (Requirement 25) */}
              <div className="p-3 rounded-lg bg-[#181205] border border-amber-900/40 flex flex-col gap-2">
                <div className="flex items-center justify-between text-xs font-semibold text-amber-300">
                  <span className="flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>GNSS Outage &amp; NaviSync Inertial DR</span>
                  </span>
                  <span>Outage Duration: {selectedTrip.gnssOutageDurationSeconds}s</span>
                </div>
                <div className="text-xs text-[#b89555] flex flex-wrap gap-4">
                  <span>Estimated Peak Drift: <strong>{selectedTrip.estimatedDriftMeters} m</strong></span>
                  <span>NaviSync DR Active: <strong>{selectedTrip.drPercentage}%</strong> of journey</span>
                  <span>Position Confidence: <strong>{Math.round(selectedTrip.overallConfidence * 100)}%</strong></span>
                </div>
                {selectedTrip.gnssOutageSegments && selectedTrip.gnssOutageSegments.length > 0 && (
                  <div className="text-[11px] text-[#8c7340] border-t border-amber-900/30 pt-1.5 mt-1">
                    Recorded {selectedTrip.gnssOutageSegments.length} GNSS blackout segment(s) seamlessly bridged by NaviSync Dead Reckoning.
                  </div>
                )}
              </div>

              {/* Trajectory points count */}
              <div className="text-xs text-[#777] flex items-center justify-between pt-1">
                <span>Traveled trajectory: {selectedTrip.routeCoordinates?.length || 0} GPS points logged</span>
                <button
                  onClick={() => {
                    onReopenTripRoute(selectedTrip);
                    onClose();
                  }}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Display Trajectory on Map</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Trips List */
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
            {isLoading ? (
              <div className="py-12 text-center text-sm text-[#777]">Loading your journeys from IndexedDB...</div>
            ) : trips.length === 0 ? (
              <div className="py-16 text-center flex flex-col items-center justify-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-[#161616] border border-[#262626] flex items-center justify-center text-[#555]">
                  <History className="w-7 h-7" />
                </div>
                <div className="text-sm font-semibold text-[#aaa]">No travel history yet</div>
                <p className="text-xs text-[#666] max-w-sm">
                  Whenever you start driving or complete a route, the journey trajectory is automatically recorded and stored here.
                </p>
              </div>
            ) : (
              trips.map((trip) => (
                <div
                  key={trip.id}
                  id={`trip-card-${trip.id}`}
                  onClick={() => setSelectedTrip(trip)}
                  className="p-3.5 sm:p-4 rounded-xl bg-[#121212] hover:bg-[#161616] border border-[#202020] hover:border-[#2a2a2a] transition-all flex flex-col gap-3 cursor-pointer group"
                >
                  {/* Top line: Mode, Date & Actions */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-lg text-[11px] font-semibold border flex items-center gap-1.5 uppercase tracking-wider bg-blue-500/15 text-blue-300 border-blue-500/30">
                        {getModeIcon(trip.navigationMode)}
                        <span>{trip.navigationMode.replace('_', ' ')}</span>
                      </span>
                      <span className="text-[11px] text-[#777] flex items-center gap-1 font-mono">
                        <Calendar className="w-3 h-3" />
                        <span>{trip.dateFormatted}</span>
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {trip.gnssOutageDurationSeconds > 0 && (
                        <span className="px-2 py-0.5 rounded-md bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-semibold flex items-center gap-1">
                          <Zap className="w-3 h-3" />
                          <span>DR {trip.drPercentage}%</span>
                        </span>
                      )}
                      <button
                        id={`btn-delete-trip-${trip.id}`}
                        onClick={(e) => handleDeleteTrip(trip.id, e)}
                        title="Delete journey entry"
                        className="p-1.5 rounded-lg text-[#666] hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Route Path (Origin -> Destination) */}
                  <div className="flex items-start gap-2.5">
                    <div className="flex flex-col items-center gap-1 pt-1 shrink-0">
                      <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                      <span className="w-0.5 h-6 bg-[#262626]"></span>
                      <MapPin className="w-3.5 h-3.5 text-rose-400" />
                    </div>
                    <div className="flex-1 min-w-0 flex flex-col gap-1.5">
                      <div className="text-xs text-[#999] truncate">
                        <span className="text-[#666] font-medium mr-1.5">From:</span>
                        <span className="text-[#bbb] font-medium">{trip.startLocation || 'Current Location'}</span>
                      </div>
                      <div className="text-sm font-bold text-white truncate">
                        <span className="text-[#666] font-medium mr-1.5 text-xs">To:</span>
                        <span>{trip.endLocation}</span>
                      </div>
                    </div>
                  </div>

                  {/* Metrics Row (Requirement 23) */}
                  <div className="pt-2.5 border-t border-[#1c1c1c] flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-4 text-xs font-mono">
                      <div>
                        <span className="text-[#666] text-[10px] uppercase block">Distance</span>
                        <span className="text-white font-bold">{trip.distanceKm} km</span>
                      </div>
                      <div>
                        <span className="text-[#666] text-[10px] uppercase block">Duration</span>
                        <span className="text-white font-bold">{trip.durationMinutes} min</span>
                      </div>
                      <div>
                        <span className="text-[#666] text-[10px] uppercase block">Avg / Max</span>
                        <span className="text-blue-400 font-bold">{Math.round(trip.averageSpeedKmh)} / {Math.round(trip.maxSpeedKmh)} km/h</span>
                      </div>
                      <div>
                        <span className="text-[#666] text-[10px] uppercase block">GNSS / DR</span>
                        <span className="text-emerald-400 font-bold">{trip.gnssAvailabilityPercentage}% / {trip.drPercentage}%</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-blue-400 font-semibold group-hover:translate-x-1 transition-transform">
                      <span>View Journey</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Footer Actions */}
        {trips.length > 0 && !selectedTrip && (
          <div className="p-3 sm:p-4 border-t border-[#1c1c1c] bg-[#111111] flex items-center justify-between">
            {confirmClearAll ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-rose-300 font-medium">Clear all history permanently?</span>
                <button
                  id="btn-confirm-clear-all"
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold transition-colors"
                >
                  Yes, Clear All
                </button>
                <button
                  onClick={() => setConfirmClearAll(false)}
                  className="px-2.5 py-1.5 bg-[#202020] text-[#999] hover:text-white rounded-lg text-xs transition-colors"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                id="btn-clear-all-history"
                onClick={() => setConfirmClearAll(true)}
                className="text-xs text-[#888] hover:text-rose-400 flex items-center gap-1.5 transition-colors p-1.5 rounded-lg"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All Travel History</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#202020] hover:bg-[#2a2a2a] text-white rounded-xl text-xs font-semibold transition-colors"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
