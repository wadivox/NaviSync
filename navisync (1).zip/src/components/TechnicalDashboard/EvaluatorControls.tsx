import React from 'react';
import { GNSSState } from '../../types/navigation';
import {
  AlertTriangle,
  PauseCircle,
  RefreshCw,
  Mountain,
  Bomb,
  Building2,
  CheckCircle2,
  X,
  RotateCcw,
  RotateCw,
  Compass
} from 'lucide-react';

interface EvaluatorControlsProps {
  gnssState: GNSSState;
  isVehicleStopped: boolean;
  currentHeadingDeg?: number;
  onRotateHeading?: (deltaDeg: number) => void;
  onTriggerBlackout: () => void;
  onTriggerStop: () => void;
  onReconnectGNSS: () => void;
  onTriggerTunnel: () => void;
  onTriggerPothole: () => void;
  onTriggerUrbanCanyon: () => void;
  onResetNormal: () => void;
  onClose: () => void;
}

export const EvaluatorControls: React.FC<EvaluatorControlsProps> = ({
  gnssState,
  isVehicleStopped,
  currentHeadingDeg = 45,
  onRotateHeading,
  onTriggerBlackout,
  onTriggerStop,
  onReconnectGNSS,
  onTriggerTunnel,
  onTriggerPothole,
  onTriggerUrbanCanyon,
  onResetNormal,
  onClose
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-[#050505]/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0d0d0d] border border-[#1f1f1f] rounded-2xl max-w-lg w-full p-5 shadow-2xl shadow-black/95 text-[#e0e0e0] animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between border-b border-[#1a1a1a] pb-3">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400 font-mono">
              SIH26168 Judge &amp; Evaluator Sandbox
            </div>
            <h3 className="text-base font-bold text-white">Interactive Scenario Controls</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#8e8e8e] hover:text-white hover:bg-[#161616] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-[#8e8e8e] mt-3 leading-relaxed">
          These live controls modify the positioning engine's state in real time to demonstrate GNSS loss detection, ZUPT standstill clamping, AI vibration suppression, and smooth re-synchronization.
        </p>

        {/* Buttons Grid */}
        <div className="grid grid-cols-2 gap-2.5 mt-4">
          {/* 1. Trigger GNSS Blackout */}
          <button
            id="eval-btn-blackout"
            onClick={() => {
              onTriggerBlackout();
              onClose();
            }}
            className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 hover:bg-amber-500/20 flex flex-col gap-1 text-left transition-all"
          >
            <div className="flex items-center gap-2 font-bold text-xs">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>1. Trigger Blackout</span>
            </div>
            <span className="text-[10px] text-amber-300/70">
              Cuts GNSS signal. Transitions to NaviSync Inertial dead reckoning.
            </span>
          </button>

          {/* 2. Trigger Traffic Stop (ZUPT) */}
          <button
            id="eval-btn-stop"
            onClick={() => {
              onTriggerStop();
              onClose();
            }}
            className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-200 hover:bg-indigo-500/20 flex flex-col gap-1 text-left transition-all"
          >
            <div className="flex items-center gap-2 font-bold text-xs">
              <PauseCircle className="w-4 h-4 text-indigo-400" />
              <span>2. Traffic Stop (ZUPT)</span>
            </div>
            <span className="text-[10px] text-indigo-300/70">
              Stops vehicle in tunnel. ZUPT clamps speed to 0.0 m/s and halts drift.
            </span>
          </button>

          {/* 3. Reconnect GNSS */}
          <button
            id="eval-btn-reconnect"
            onClick={() => {
              onReconnectGNSS();
              onClose();
            }}
            className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-200 hover:bg-cyan-500/20 flex flex-col gap-1 text-left transition-all"
          >
            <div className="flex items-center gap-2 font-bold text-xs">
              <RefreshCw className="w-4 h-4 text-cyan-400" />
              <span>3. Reconnect GNSS</span>
            </div>
            <span className="text-[10px] text-cyan-300/70">
              Signal returns. Smooth Kalman fusion corrects position without teleporting.
            </span>
          </button>

          {/* 4. Mountain Tunnel */}
          <button
            id="eval-btn-tunnel"
            onClick={() => {
              onTriggerTunnel();
              onClose();
            }}
            className="p-3 rounded-xl bg-[#141414] border border-[#1f1f1f] text-[#e0e0e0] hover:bg-[#1a1a1a] flex flex-col gap-1 text-left transition-all"
          >
            <div className="flex items-center gap-2 font-bold text-xs">
              <Mountain className="w-4 h-4 text-[#8e8e8e]" />
              <span>4. Enter Tunnel</span>
            </div>
            <span className="text-[10px] text-[#8e8e8e]">
              Enters 2.4 km Patalganga Mountain Tunnel GNSS risk corridor.
            </span>
          </button>

          {/* 5. Pothole / Shock Spike */}
          <button
            id="eval-btn-pothole"
            onClick={() => {
              onTriggerPothole();
              onClose();
            }}
            className="p-3 rounded-xl bg-[#141414] border border-[#1f1f1f] text-[#e0e0e0] hover:bg-[#1a1a1a] flex flex-col gap-1 text-left transition-all"
          >
            <div className="flex items-center gap-2 font-bold text-xs">
              <Bomb className="w-4 h-4 text-rose-400" />
              <span>5. Pothole Shock</span>
            </div>
            <span className="text-[10px] text-[#8e8e8e]">
              Spikes vertical acceleration to test AI vibration filter.
            </span>
          </button>

          {/* 6. Urban Canyon Multipath */}
          <button
            id="eval-btn-canyon"
            onClick={() => {
              onTriggerUrbanCanyon();
              onClose();
            }}
            className="p-3 rounded-xl bg-[#141414] border border-[#1f1f1f] text-[#e0e0e0] hover:bg-[#1a1a1a] flex flex-col gap-1 text-left transition-all"
          >
            <div className="flex items-center gap-2 font-bold text-xs">
              <Building2 className="w-4 h-4 text-yellow-400" />
              <span>6. Urban Canyon</span>
            </div>
            <span className="text-[10px] text-[#8e8e8e]">
              Skyscraper multipath reflections degrade accuracy to 35m.
            </span>
          </button>
        </div>

        {/* Heading & Arrow Rotation Test */}
        {onRotateHeading && (
          <div className="mt-3 p-3 rounded-xl bg-[#111111] border border-[#1f1f1f] flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
                <Compass className="w-3.5 h-3.5 text-blue-400" />
                <span>Directional Arrow & Heading Test</span>
              </div>
              <span className="text-[11px] font-mono text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                {Math.round(currentHeadingDeg)}°
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                id="eval-heading-left-45"
                type="button"
                onClick={() => onRotateHeading(-45)}
                className="flex-1 py-1.5 px-2 bg-[#1a1a1a] hover:bg-[#222] border border-[#2a2a2a] rounded-lg text-xs text-[#e0e0e0] flex items-center justify-center gap-1.5 transition-all"
              >
                <RotateCcw className="w-3 h-3 text-blue-400" />
                <span>-45° Left</span>
              </button>
              <button
                id="eval-heading-right-45"
                type="button"
                onClick={() => onRotateHeading(45)}
                className="flex-1 py-1.5 px-2 bg-[#1a1a1a] hover:bg-[#222] border border-[#2a2a2a] rounded-lg text-xs text-[#e0e0e0] flex items-center justify-center gap-1.5 transition-all"
              >
                <RotateCw className="w-3 h-3 text-blue-400" />
                <span>+45° Right</span>
              </button>
              <button
                id="eval-heading-flip-180"
                type="button"
                onClick={() => onRotateHeading(180)}
                className="flex-1 py-1.5 px-2 bg-[#1a1a1a] hover:bg-[#222] border border-[#2a2a2a] rounded-lg text-xs text-[#e0e0e0] flex items-center justify-center gap-1.5 transition-all"
              >
                <span>180° Flip</span>
              </button>
            </div>
            <p className="text-[10px] text-[#777]">
              Works in all modes. In GPS-denied mode, arrow smoothly updates via NaviSync IMU heading fusion.
            </p>
          </div>
        )}

        {/* Reset Normal Button */}
        <div className="mt-4 pt-3 border-t border-[#1a1a1a] flex justify-end">
          <button
            onClick={() => {
              onResetNormal();
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Reset to Normal Open-Sky Navigation</span>
          </button>
        </div>
      </div>
    </div>
  );
};
