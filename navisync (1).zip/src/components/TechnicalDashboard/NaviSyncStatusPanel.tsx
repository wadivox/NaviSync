import React, { useState } from 'react';
import { GNSSState, FusionState } from '../../types/navigation';
import { ChevronDown, ChevronUp, Activity, Terminal } from 'lucide-react';

interface NaviSyncStatusPanelProps {
  gnssState: GNSSState;
  fusionState?: FusionState;
  isCollapsible?: boolean;
  defaultExpanded?: boolean;
  className?: string;
  onOpenIntelligence?: () => void;
}

export const NaviSyncStatusPanel: React.FC<NaviSyncStatusPanelProps> = ({
  gnssState,
  fusionState,
  isCollapsible = true,
  defaultExpanded = true,
  className = '',
  onOpenIntelligence
}) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  // Status mapping
  const isGnssAvailable = gnssState === 'GNSS_AVAILABLE';
  const isGnssLost = gnssState === 'GNSS_LOST' || gnssState === 'NAVISYNC_INERTIAL';
  const isGnssRestoring = gnssState === 'GNSS_RESTORING';
  const isGnssDegraded = gnssState === 'GNSS_DEGRADED';

  // GNSS Row
  let gnssDotClass = 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]';
  let gnssText = 'LOCKED';
  let gnssTextColor = 'text-emerald-400';

  if (isGnssLost) {
    gnssDotClass = 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.9)] animate-pulse';
    gnssText = 'LOST';
    gnssTextColor = 'text-red-400';
  } else if (isGnssDegraded) {
    gnssDotClass = 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]';
    gnssText = 'DEGRADED';
    gnssTextColor = 'text-amber-400';
  } else if (isGnssRestoring) {
    gnssDotClass = 'bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)] animate-pulse';
    gnssText = 'SYNCING';
    gnssTextColor = 'text-cyan-400';
  }

  // DR Mode Row
  // Active when GNSS is lost or degraded, STANDBY (gray/dim) when GNSS is available
  let drDotClass = 'bg-[#555555] opacity-60';
  let drText = 'STANDBY';
  let drTextColor = 'text-[#777777]';

  if (isGnssLost) {
    drDotClass = 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]';
    drText = 'ACTIVE';
    drTextColor = 'text-emerald-400';
  } else if (isGnssDegraded) {
    drDotClass = 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]';
    drText = 'ACTIVE';
    drTextColor = 'text-amber-400';
  } else if (isGnssRestoring) {
    drDotClass = 'bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]';
    drText = 'SYNCING';
    drTextColor = 'text-cyan-400';
  }

  const rows = [
    { label: 'GNSS', dotClass: gnssDotClass, text: gnssText, textColor: gnssTextColor },
    { label: 'IMU', dotClass: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]', text: 'ACTIVE', textColor: 'text-emerald-400' },
    { label: 'Orientation', dotClass: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]', text: 'CALIBRATED', textColor: 'text-emerald-400' },
    { label: 'AI Filter', dotClass: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]', text: 'ACTIVE', textColor: 'text-emerald-400' },
    { label: 'INS', dotClass: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]', text: 'ACTIVE', textColor: 'text-emerald-400' },
    { label: 'NHC', dotClass: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]', text: 'ACTIVE', textColor: 'text-emerald-400' },
    { label: 'Map Matching', dotClass: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]', text: 'ACTIVE', textColor: 'text-emerald-400' },
    { label: 'DR Mode', dotClass: drDotClass, text: drText, textColor: drTextColor }
  ];

  return (
    <div
      id="navisync-status-panel"
      className={`bg-[#0a0a0a]/90 border border-[#222222] shadow-2xl shadow-black/90 rounded-xl backdrop-blur-md text-[#e0e0e0] font-mono select-none overflow-hidden transition-all duration-200 ${className}`}
      style={{ minWidth: '230px' }}
    >
      {/* Header / Toggle */}
      <div
        onClick={() => isCollapsible && setIsExpanded(!isExpanded)}
        className={`px-3.5 py-2.5 flex items-center justify-between border-b border-[#1c1c1c] ${
          isCollapsible ? 'cursor-pointer hover:bg-[#141414]/70' : ''
        }`}
      >
        <div className="flex items-center gap-2">
          <Terminal className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-[11px] font-bold tracking-wider text-white uppercase">
            NAVISYNC STATUS
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          {/* Real-time pulse indicator in header */}
          <span
            className={`w-2 h-2 rounded-full ${
              isGnssLost ? 'bg-red-500 animate-pulse' : 'bg-emerald-400'
            }`}
          />
          {isCollapsible && (
            <button
              aria-label="Toggle NaviSync Status Panel"
              className="text-[#888888] hover:text-white p-0.5"
            >
              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>
      </div>

      {/* Rows Content */}
      {isExpanded && (
        <div className="p-3 flex flex-col gap-1.5 text-[11px] leading-snug">
          {rows.map((row) => (
            <div key={row.label} className="flex items-center justify-between py-0.5">
              <span className="text-[#a0a0a0] font-medium tracking-tight">{row.label}</span>
              <div className="flex items-center gap-1.5">
                <span className={`w-1.5 h-1.5 rounded-full inline-block ${row.dotClass}`} />
                <span className={`font-bold text-[10px] tracking-wider ${row.textColor}`}>
                  {row.text}
                </span>
              </div>
            </div>
          ))}

          {onOpenIntelligence && (
            <div className="pt-2 mt-1 border-t border-[#1a1a1a] flex justify-between items-center text-[10px]">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenIntelligence();
                }}
                className="text-blue-400 hover:text-blue-300 underline font-sans flex items-center gap-1"
              >
                <span>Telemetry View</span>
                <span>&rarr;</span>
              </button>
              {fusionState && (
                <span className="text-[#666666] font-mono">
                  {(fusionState.confidence * 100).toFixed(0)}% Conf
                </span>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
