import React from 'react';
import { Database, Award, ArrowRight, ShieldCheck, CheckCircle, X } from 'lucide-react';

interface IOVNBDModalProps {
  onClose: () => void;
}

export const IOVNBDModal: React.FC<IOVNBDModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-[#050505]/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0d0d0d] border border-[#1f1f1f] rounded-2xl max-w-2xl w-full p-6 shadow-2xl shadow-black/95 text-[#e0e0e0] animate-in fade-in zoom-in-95 duration-150 max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#1a1a1a] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-400 flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 font-mono">
                SIH26168 Benchmark Architecture
              </span>
              <h2 className="text-base font-bold text-white">IO-VNBD Dataset &amp; Methodology</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8e8e8e] hover:text-white hover:bg-[#161616] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Overview */}
        <div className="mt-4 flex flex-col gap-4 text-xs text-[#8e8e8e] leading-relaxed">
          <div className="p-3.5 bg-[#080808] rounded-xl border border-[#1f1f1f]">
            <div className="font-bold text-white mb-1 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Core SIH Innovation: IMU-to-Motion Training Target</span>
            </div>
            <p className="text-[#a0a0a0]">
              Unlike flawed approaches that attempt to predict GPS coordinates directly from IMU readings, NaviSync trains a temporal deep learning model (TCN / 1D-CNN) on the <strong>IO-VNBD</strong> (Inertial Odometry - Vehicle Navigation Benchmark Dataset) to predict <strong>forward delta-velocity (Δv)</strong>, <strong>heading rate (Δθ)</strong>, and <strong>motion uncertainty bounds</strong>.
            </p>
          </div>

          {/* Masking Methodology */}
          <div>
            <h4 className="font-bold text-white mb-2">GNSS Outage Masking Protocol:</h4>
            <div className="grid grid-cols-3 gap-2 text-center font-mono">
              <div className="bg-[#080808] p-2.5 rounded-xl border border-[#1f1f1f]">
                <div className="text-amber-400 font-bold text-sm">30s Outage</div>
                <div className="text-[10px] text-[#8e8e8e] mt-1">NaviSync Drift: &lt; 3.8m</div>
                <div className="text-[10px] text-rose-400 mt-0.5">Raw IMU: 38.2m</div>
              </div>
              <div className="bg-[#080808] p-2.5 rounded-xl border border-[#1f1f1f]">
                <div className="text-amber-400 font-bold text-sm">60s Outage</div>
                <div className="text-[10px] text-[#8e8e8e] mt-1">NaviSync Drift: &lt; 8.4m</div>
                <div className="text-[10px] text-rose-400 mt-0.5">Raw IMU: 114.6m</div>
              </div>
              <div className="bg-[#080808] p-2.5 rounded-xl border border-[#1f1f1f]">
                <div className="text-amber-400 font-bold text-sm">120s Outage</div>
                <div className="text-[10px] text-[#8e8e8e] mt-1">NaviSync Drift: &lt; 18.2m</div>
                <div className="text-[10px] text-rose-400 mt-0.5">Raw IMU: 340.5m</div>
              </div>
            </div>
          </div>

          {/* Pipeline */}
          <div className="p-3.5 bg-[#080808] rounded-xl border border-[#1f1f1f] font-mono text-[11px] text-[#e0e0e0]">
            <div className="text-[#8e8e8e] mb-1 font-bold">End-to-End Positioning Pipeline:</div>
            <div className="flex flex-wrap items-center gap-1.5 text-blue-400">
              <span>Raw IMU</span> <ArrowRight className="w-3 h-3 text-[#666666]" />
              <span>AI Vibration Filter</span> <ArrowRight className="w-3 h-3 text-[#666666]" />
              <span>Gravity Removal</span> <ArrowRight className="w-3 h-3 text-[#666666]" />
              <span>IMU Speed Estimator</span> <ArrowRight className="w-3 h-3 text-[#666666]" />
              <span>ZUPT Detector</span> <ArrowRight className="w-3 h-3 text-[#666666]" />
              <span>NHC Kinematics</span> <ArrowRight className="w-3 h-3 text-[#666666]" />
              <span>Road Map Match</span> <ArrowRight className="w-3 h-3 text-[#666666]" />
              <span className="text-emerald-400 font-bold">Kalman / ESKF State</span>
            </div>
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-[#1a1a1a] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
          >
            Close Benchmark Overview
          </button>
        </div>
      </div>
    </div>
  );
};
