import { NaviSyncNavigationState, NavigationMode, TravelHistoryRecord, GNSSOutageSegment, TravelTrajectoryPoint } from '../types/navigation';
import { globalTravelHistoryService } from './TravelHistoryService';

export class TripRecorder {
  private isRecording = false;
  private tripStartTime: number = 0;
  private startCoordinate: { lat: number; lng: number } | null = null;
  private startLocationName = 'Current Location';
  private endLocationName = 'Destination';
  private navigationMode: NavigationMode = 'driving';

  private routeCoordinates: [number, number][] = [];
  private trajectoryPoints: TravelTrajectoryPoint[] = [];

  private totalDistanceMeters = 0;
  private maxSpeedKmh = 0;
  private speedSamples: number[] = [];
  private stoppedDurationSeconds = 0;
  private consecutiveStationarySeconds = 0;

  // GNSS outage tracking
  private activeOutageSegment: GNSSOutageSegment | null = null;
  private completedOutageSegments: GNSSOutageSegment[] = [];
  private totalOutageSeconds = 0;

  private lastLat: number | null = null;
  private lastLng: number | null = null;
  private lastTimestamp = 0;

  private listeners: Set<(status: { isRecording: boolean; distanceKm: number; durationMinutes: number; currentSpeed: number }) => void> = new Set();

  public update(navState: NaviSyncNavigationState, isNavigating = false, routeName?: string) {
    const now = navState.timestamp || Date.now();
    const dt = this.lastTimestamp > 0 ? (now - this.lastTimestamp) / 1000 : 1;
    this.lastTimestamp = now;

    // Automatic trip start detection
    if (!this.isRecording) {
      if (navState.speedKmh > 3.0 && !navState.isStationary) {
        // Meaningful movement detected
        this.startTrip(navState, routeName);
      }
      return;
    }

    // --- Active Trip Recording ---
    const currentCoord: [number, number] = [navState.latitude, navState.longitude];

    // Check stationary duration for auto-stop
    if (navState.isStationary || navState.speedKmh < 1.0) {
      this.stoppedDurationSeconds += dt;
      this.consecutiveStationarySeconds += dt;

      // If stationary for > 120 seconds and not in active guided navigation, auto-finalize
      if (this.consecutiveStationarySeconds >= 120 && !isNavigating) {
        this.endTrip(navState, true);
        return;
      }
    } else {
      this.consecutiveStationarySeconds = 0;
    }

    // Distance accumulation
    if (this.lastLat !== null && this.lastLng !== null) {
      const stepDist = this.calculateDistanceMeters(this.lastLat, this.lastLng, navState.latitude, navState.longitude);
      // Sanity check: discard GPS teleportation glitches > 200m in 1s
      if (stepDist > 0.5 && stepDist < 150) {
        this.totalDistanceMeters += stepDist;
        this.routeCoordinates.push(currentCoord);
      }
    } else {
      this.routeCoordinates.push(currentCoord);
    }

    this.lastLat = navState.latitude;
    this.lastLng = navState.longitude;

    // Speed tracking
    if (navState.speedKmh > this.maxSpeedKmh) {
      this.maxSpeedKmh = navState.speedKmh;
    }
    this.speedSamples.push(navState.speedKmh);

    // Trajectory timeline sampling (every ~1s)
    if (this.trajectoryPoints.length === 0 || now - this.trajectoryPoints[this.trajectoryPoints.length - 1].timestamp >= 1000) {
      this.trajectoryPoints.push({
        lat: navState.latitude,
        lng: navState.longitude,
        speedKmh: navState.speedKmh,
        heading: navState.heading,
        gnssStatus: navState.gnssStatus,
        confidence: navState.positionConfidence,
        timestamp: now
      });
    }

    // GNSS Outage Segment tracking
    const isOutage = navState.gnssStatus === 'LOST' || navState.navigationMode === 'DEAD_RECKONING';
    if (isOutage) {
      this.totalOutageSeconds += dt;
      if (!this.activeOutageSegment) {
        this.activeOutageSegment = {
          startTime: now,
          durationSeconds: 0,
          startCoordinate: currentCoord,
          maxDriftMeters: navState.estimatedDriftMeters,
          recoveredConfidence: navState.positionConfidence,
          cause: 'SIGNAL_DROP'
        };
      } else {
        this.activeOutageSegment.durationSeconds += dt;
        if (navState.estimatedDriftMeters > this.activeOutageSegment.maxDriftMeters) {
          this.activeOutageSegment.maxDriftMeters = navState.estimatedDriftMeters;
        }
      }
    } else {
      // Outage ended / GNSS restored
      if (this.activeOutageSegment) {
        this.activeOutageSegment.endTime = now;
        this.activeOutageSegment.endCoordinate = currentCoord;
        this.activeOutageSegment.recoveredConfidence = navState.positionConfidence;
        this.completedOutageSegments.push(this.activeOutageSegment);
        this.activeOutageSegment = null;
      }
    }

    this.notify();
  }

  public startTrip(
    navStateOrName?: NaviSyncNavigationState | string,
    routeNameOrMode?: string | NavigationMode,
    mode: NavigationMode = 'driving'
  ) {
    this.isRecording = true;
    const now = Date.now();
    let lat = 17.4504;
    let lng = 78.3808;
    let speed = 0;
    let heading = 0;
    let routeName: string | undefined = undefined;
    let actualMode = mode;

    if (typeof navStateOrName === 'object' && navStateOrName !== null && 'latitude' in navStateOrName) {
      lat = navStateOrName.latitude;
      lng = navStateOrName.longitude;
      speed = navStateOrName.speedKmh;
      heading = navStateOrName.heading;
      if (typeof routeNameOrMode === 'string') {
        routeName = routeNameOrMode;
      }
    } else if (typeof navStateOrName === 'string') {
      routeName = navStateOrName;
      if (typeof routeNameOrMode === 'string') {
        actualMode = routeNameOrMode as NavigationMode;
      }
      if (this.lastLat !== null && this.lastLng !== null) {
        lat = this.lastLat;
        lng = this.lastLng;
      }
    }

    this.tripStartTime = now;
    this.startCoordinate = { lat, lng };
    this.startLocationName = routeName ? `Origin (${routeName})` : 'Trip Start';
    this.endLocationName = 'Trip Destination';
    this.navigationMode = actualMode;

    this.routeCoordinates = [[lat, lng]];
    this.trajectoryPoints = [{
      lat,
      lng,
      speedKmh: speed,
      heading,
      gnssStatus: 'AVAILABLE',
      confidence: 1.0,
      timestamp: this.tripStartTime
    }];

    this.totalDistanceMeters = 0;
    this.maxSpeedKmh = speed;
    this.speedSamples = [speed];
    this.stoppedDurationSeconds = 0;
    this.consecutiveStationarySeconds = 0;

    this.activeOutageSegment = null;
    this.completedOutageSegments = [];
    this.totalOutageSeconds = 0;

    this.lastLat = lat;
    this.lastLng = lng;
    this.lastTimestamp = this.tripStartTime;

    this.notify();
  }

  public async endTrip(
    navStateOrCompleted?: NaviSyncNavigationState | boolean,
    completedNaturally = true
  ): Promise<TravelHistoryRecord | null> {
    if (!this.isRecording) return null;

    let isCompleted = completedNaturally;
    let navState: NaviSyncNavigationState | undefined = undefined;

    if (typeof navStateOrCompleted === 'boolean') {
      isCompleted = navStateOrCompleted;
    } else if (typeof navStateOrCompleted === 'object' && navStateOrCompleted !== null) {
      navState = navStateOrCompleted;
      isCompleted = completedNaturally;
    }

    this.isRecording = false;
    const now = Date.now();
    const durationSeconds = Math.max(10, Math.round((now - this.tripStartTime) / 1000));
    const durationMinutes = Math.max(1, Math.round(durationSeconds / 60));

    // Close any unclosed outage segment
    if (this.activeOutageSegment) {
      this.activeOutageSegment.endTime = now;
      this.activeOutageSegment.endCoordinate = this.routeCoordinates[this.routeCoordinates.length - 1];
      this.completedOutageSegments.push(this.activeOutageSegment);
      this.activeOutageSegment = null;
    }

    const distanceKm = Math.round((this.totalDistanceMeters / 1000) * 10) / 10;
    const avgSpeed = this.speedSamples.length > 0
      ? Math.round((this.speedSamples.reduce((a, b) => a + b, 0) / this.speedSamples.length) * 10) / 10
      : 0;

    const outageSecs = Math.round(this.totalOutageSeconds);
    const gnssAvailabilityPct = durationSeconds > 0
      ? Math.max(0, Math.min(100, Math.round(((durationSeconds - outageSecs) / durationSeconds) * 100)))
      : 100;
    const drPercentage = 100 - gnssAvailabilityPct;

    const lastCoord = this.routeCoordinates[this.routeCoordinates.length - 1] || [navState?.latitude || 17.385, navState?.longitude || 78.486];

    // Discard trips that moved less than 30 meters
    if (this.totalDistanceMeters < 30) {
      this.notify();
      return null;
    }

    const record: Omit<TravelHistoryRecord, 'id' | 'dateFormatted'> = {
      startTime: this.tripStartTime,
      endTime: now,
      startLocation: this.startLocationName,
      endLocation: this.endLocationName,
      startCoordinate: this.startCoordinate || { lat: this.routeCoordinates[0][0], lng: this.routeCoordinates[0][1] },
      endCoordinate: { lat: lastCoord[0], lng: lastCoord[1] },
      routeCoordinates: this.routeCoordinates,
      trajectoryPoints: this.trajectoryPoints,
      distanceKm,
      durationMinutes,
      stoppedDurationSeconds: Math.round(this.stoppedDurationSeconds),
      averageSpeedKmh: avgSpeed,
      maxSpeedKmh: Math.round(this.maxSpeedKmh * 10) / 10,
      navigationMode: this.navigationMode,
      gnssOutageDurationSeconds: outageSecs,
      gnssOutageSegments: this.completedOutageSegments,
      gnssAvailabilityPercentage: gnssAvailabilityPct,
      drPercentage,
      estimatedDriftMeters: navState ? navState.estimatedDriftMeters : 0,
      overallConfidence: navState ? navState.positionConfidence : 0.95,
      completedNaturally
    };

    const saved = await globalTravelHistoryService.saveTrip(record);
    this.notify();
    return saved;
  }

  public getStatus() {
    const durationMinutes = this.isRecording ? Math.max(1, Math.round((Date.now() - this.tripStartTime) / 60000)) : 0;
    const distanceKm = Math.round((this.totalDistanceMeters / 1000) * 10) / 10;
    const currentSpeed = this.speedSamples.length > 0 ? this.speedSamples[this.speedSamples.length - 1] : 0;

    return {
      isRecording: this.isRecording,
      distanceKm,
      durationMinutes,
      currentSpeed
    };
  }

  public subscribe(cb: (status: { isRecording: boolean; distanceKm: number; durationMinutes: number; currentSpeed: number }) => void) {
    this.listeners.add(cb);
    cb(this.getStatus());
    return () => this.listeners.delete(cb);
  }

  private notify() {
    const status = this.getStatus();
    this.listeners.forEach((cb) => cb(status));
  }

  private calculateDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const toRad = (deg: number) => (deg * Math.PI) / 180;
    const R = 6371000;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }
}

export const globalTripRecorder = new TripRecorder();
