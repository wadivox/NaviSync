import { SupportedLanguage } from '../i18n/translations';

export class VoiceService {
  private isEnabled = true;
  private currentLanguage: SupportedLanguage = 'en';
  private lastSpokenText = '';
  private lastSpokenTime = 0;

  constructor() {
    // Check speech synthesis availability
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      // Warm up voices
      window.speechSynthesis.getVoices();
    }
  }

  public setEnabled(enabled: boolean) {
    this.isEnabled = enabled;
    if (!enabled && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  public getIsEnabled(): boolean {
    return this.isEnabled;
  }

  public setLanguage(lang: SupportedLanguage) {
    this.currentLanguage = lang;
  }

  public speak(text: string, force = false) {
    if (!this.isEnabled) return;
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    const now = Date.now();
    // Throttle repeat utterances
    if (!force && text === this.lastSpokenText && now - this.lastSpokenTime < 5000) {
      return;
    }

    this.lastSpokenText = text;
    this.lastSpokenTime = now;

    try {
      window.speechSynthesis.cancel(); // Cancel any ongoing speech for immediate turn instruction
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;

      // Select voice based on language
      const voices = window.speechSynthesis.getVoices();
      const langCodeMap: Record<SupportedLanguage, string> = {
        en: 'en-US',
        hi: 'hi-IN',
        te: 'te-IN',
        ta: 'ta-IN',
        kn: 'kn-IN',
        ml: 'ml-IN',
        mr: 'mr-IN',
        bn: 'bn-IN',
        gu: 'gu-IN',
        pa: 'pa-IN'
      };

      const targetPrefix = langCodeMap[this.currentLanguage] || 'en';
      const matchedVoice = voices.find(v => v.lang.startsWith(targetPrefix));
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn('Speech synthesis utterance error:', err);
    }
  }
}

export const globalVoiceService = new VoiceService();
