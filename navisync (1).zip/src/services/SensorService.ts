import { IMURawData } from '../types/navigation';
import { globalSensorCapabilityManager } from './SensorCapabilityManager';

type SensorCallback = (data: IMURawData) => void;
type OrientationCallback = (headingDeg: number, pitch: number, roll: number) => void;

export class SensorService {
  private listeners: Set<SensorCallback> = new Set();
  private orientationListeners: Set<OrientationCallback> = new Set();
  private timer: any = null;
  private isUsingSimulated = true;
  private isRealMotionDetected = false;
  private isRealOrientationDetected = false;

  // Real sensor readings
  private lastCompassHeading: number | null = null;
  private lastPitch: number = 0;
  private lastRoll: number = 0;

  // Simulation dynamics (used strictly when device has no motion hardware or when evaluator demo scenario is explicitly running)
  private currentForwardAccel = 0.0;
  private currentYawRate = 0.0;
  private potholeImpulse = 0;
  private isVehicleStopped = true;

  constructor() {
    this.attachDeviceListeners();
    this.startSimulationLoop();
  }

  private attachDeviceListeners() {
    if (typeof window === 'undefined') return;

    // 1. DeviceMotion Listener
    if ('DeviceMotionEvent' in window) {
      try {
        window.addEventListener('devicemotion', (evt) => {
          const acc = evt.accelerationIncludingGravity || evt.acceleration;
          const rot = evt.rotationRate;

          if (acc && acc.x !== null && acc.x !== undefined) {
            this.isRealMotionDetected = true;
            this.isUsingSimulated = false;
            globalSensorCapabilityManager.recordSensorActivity('deviceMotion', true);
            globalSensorCapabilityManager.recordSensorActivity('accelerometer', true);
            if (rot && rot.alpha !== null) {
              globalSensorCapabilityManager.recordSensorActivity('gyroscope', true);
            }

            const raw: IMURawData = {
              ax: acc.y || 0, // Phone held in vehicle dock (forward is y)
              ay: acc.x || 0, // Lateral is x
              az: acc.z || 9.81, // Vertical is z
              gx: ((rot?.alpha || 0) * Math.PI) / 180,
              gy: ((rot?.beta || 0) * Math.PI) / 180,
              gz: ((rot?.gamma || 0) * Math.PI) / 180,
              timestamp: Date.now(),
              isSimulated: false
            };
            this.notify(raw);
          }
        });
      } catch (e) {
        console.warn('Real motion sensor error:', e);
      }
    }

    // 2. DeviceOrientation Listener (Compass / Magnetometer)
    if ('DeviceOrientationEvent' in window) {
      try {
        window.addEventListener('deviceorientation', (evt: any) => {
          let heading: number | null = null;

          // iOS webkitCompassHeading is absolute north (0 = North, 90 = East, etc.)
          if (typeof evt.webkitCompassHeading === 'number' && !isNaN(evt.webkitCompassHeading)) {
            heading = evt.webkitCompassHeading;
            globalSensorCapabilityManager.recordSensorActivity('magnetometer', true);
          } else if (evt.absolute && typeof evt.alpha === 'number' && !isNaN(evt.alpha)) {
            // Android absolute alpha
            heading = (360 - evt.alpha) % 360;
            globalSensorCapabilityManager.recordSensorActivity('magnetometer', true);
          } else if (typeof evt.alpha === 'number' && !isNaN(evt.alpha)) {
            // Relative orientation
            heading = (360 - evt.alpha) % 360;
          }

          if (heading !== null) {
            this.isRealOrientationDetected = true;
            this.lastCompassHeading = heading;
            this.lastPitch = evt.beta || 0;
            this.lastRoll = evt.gamma || 0;
            globalSensorCapabilityManager.recordSensorActivity('deviceOrientation', true);
            this.notifyOrientation(heading, this.lastPitch, this.lastRoll);
          }
        });
      } catch (e) {
        console.warn('Device orientation error:', e);
      }
    }
  }

  private startSimulationLoop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => {
      // If real motion sensors are firing on a physical phone, don't generate synthetic data
      if (this.isRealMotionDetected) return;

      const now = Date.now();
      let ax = 0;
      let ay = 0;
      let az = 9.81;
      let gz = 0;

      // Only add harmonic vibration or acceleration if vehicle is NOT stopped
      if (!this.isVehicleStopped) {
        const engineJitterX = (Math.sin(now / 70) * 0.04 + (Math.random() - 0.5) * 0.03);
        const engineJitterY = (Math.cos(now / 65) * 0.03 + (Math.random() - 0.5) * 0.02);
        const engineJitterZ = (Math.sin(now / 50) * 0.06 + (Math.random() - 0.5) * 0.04);

        ax = this.currentForwardAccel + engineJitterX;
        ay = engineJitterY;
        az = 9.81 + engineJitterZ;
        gz = this.currentYawRate + (Math.random() - 0.5) * 0.005;
      }

      // Apply temporary pothole shock if triggered
      if (this.potholeImpulse > 0) {
        az += this.potholeImpulse;
        ax += (Math.random() - 0.5) * 2.5;
        this.potholeImpulse *= 0.45;
        if (this.potholeImpulse < 0.2) this.potholeImpulse = 0;
      }

      const raw: IMURawData = {
        ax,
        ay,
        az,
        gx: 0,
        gy: 0,
        gz,
        timestamp: now,
        isSimulated: true
      };

      this.notify(raw);
    }, 100); // 10 Hz
  }

  public subscribe(cb: SensorCallback) {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  public subscribeOrientation(cb: OrientationCallback) {
    this.orientationListeners.add(cb);
    if (this.lastCompassHeading !== null) {
      cb(this.lastCompassHeading, this.lastPitch, this.lastRoll);
    }
    return () => this.orientationListeners.delete(cb);
  }

  private notify(data: IMURawData) {
    this.listeners.forEach((cb) => cb(data));
  }

  private notifyOrientation(heading: number, pitch: number, roll: number) {
    this.orientationListeners.forEach((cb) => cb(heading, pitch, roll));
  }

  public setSimulatedForwardAccel(accel: number) {
    this.currentForwardAccel = accel;
  }

  public setSimulatedYawRate(rate: number) {
    this.currentYawRate = rate;
  }

  public triggerPothole() {
    this.potholeImpulse = 6.8;
  }

  public setVehicleStopped(stopped: boolean) {
    this.isVehicleStopped = stopped;
    if (stopped) {
      this.currentForwardAccel = 0;
      this.currentYawRate = 0;
    }
  }

  public getIsUsingSimulated(): boolean {
    return this.isUsingSimulated;
  }

  public getLastCompassHeading(): number | null {
    return this.lastCompassHeading;
  }
}

export const globalSensorService = new SensorService();
