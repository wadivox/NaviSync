export interface OfflineRegion {
  id: string;
  name: string;
  sizeMb: number;
  centerLat: number;
  centerLng: number;
  zoomRange: string;
  downloadedAt: number;
  status: 'READY' | 'DOWNLOADING' | 'PAUSED';
  progress: number; // 0 - 100
}

export class OfflineService {
  private isOfflineMode = false;
  private regions: OfflineRegion[] = [
    {
      id: 'region-telangana',
      name: 'Greater Hyderabad & Cyberabad Metro',
      sizeMb: 42.5,
      centerLat: 17.385044,
      centerLng: 78.486671,
      zoomRange: 'z10 - z17',
      downloadedAt: Date.now() - 86400000,
      status: 'READY',
      progress: 100
    },
    {
      id: 'region-mumbai-pune',
      name: 'Mumbai - Pune Expressway & Tunnels',
      sizeMb: 58.2,
      centerLat: 18.9894,
      centerLng: 73.1277,
      zoomRange: 'z10 - z17',
      downloadedAt: Date.now() - 172800000,
      status: 'READY',
      progress: 100
    }
  ];

  constructor() {
    if (typeof window !== 'undefined') {
      this.isOfflineMode = !navigator.onLine;
      window.addEventListener('online', () => { this.isOfflineMode = false; });
      window.addEventListener('offline', () => { this.isOfflineMode = true; });
    }
  }

  public getIsOfflineMode(): boolean {
    return this.isOfflineMode;
  }

  public setOfflineMode(val: boolean) {
    this.isOfflineMode = val;
  }

  public getRegions(): OfflineRegion[] {
    return this.regions;
  }

  public addRegion(name: string, centerLat: number, centerLng: number): OfflineRegion {
    const newReg: OfflineRegion = {
      id: `region-${Date.now()}`,
      name,
      sizeMb: Math.round((28 + Math.random() * 20) * 10) / 10,
      centerLat,
      centerLng,
      zoomRange: 'z11 - z17',
      downloadedAt: Date.now(),
      status: 'DOWNLOADING',
      progress: 15
    };
    this.regions.push(newReg);
    return newReg;
  }

  public deleteRegion(id: string) {
    this.regions = this.regions.filter(r => r.id !== id);
  }

  public updateRegionProgress(id: string, progress: number, status: OfflineRegion['status']) {
    const reg = this.regions.find(r => r.id === id);
    if (reg) {
      reg.progress = progress;
      reg.status = status;
    }
  }
}

export const globalOfflineService = new OfflineService();
