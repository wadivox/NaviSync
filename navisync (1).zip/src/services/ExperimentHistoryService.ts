import { SIHExperimentRecord, SIHReplayFrame, SIHBenchmarkMetrics, SIHJourneySummary } from '../types/sihReplay';

const DB_NAME = 'navisync_experiments_db';
const DB_VERSION = 1;
const STORE_NAME = 'sih_experiments';
const LOCAL_STORAGE_KEY = 'navisync_sih_experiments';

class ExperimentHistoryService {
  private dbPromise: Promise<IDBDatabase | null> | null = null;

  constructor() {
    this.initDB();
  }

  private initDB(): Promise<IDBDatabase | null> {
    if (this.dbPromise) return this.dbPromise;

    if (typeof window === 'undefined' || !window.indexedDB) {
      this.dbPromise = Promise.resolve(null);
      return this.dbPromise;
    }

    this.dbPromise = new Promise((resolve) => {
      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
            store.createIndex('timestamp', 'timestamp', { unique: false });
          }
        };

        request.onsuccess = () => {
          resolve(request.result);
        };

        request.onerror = () => {
          console.warn('IndexedDB for experiments unavailable, using localStorage fallback');
          resolve(null);
        };
      } catch (err) {
        console.warn('Error opening IndexedDB for experiments:', err);
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  private getLocalStorageExperiments(): SIHExperimentRecord[] {
    try {
      const data = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Error reading experiments from localStorage', e);
    }
    return [];
  }

  private setLocalStorageExperiments(records: SIHExperimentRecord[]) {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(records));
    } catch (e) {
      console.error('Error saving experiments to localStorage', e);
    }
  }

  public async saveExperiment(record: SIHExperimentRecord): Promise<void> {
    const db = await this.initDB();
    if (db) {
      return new Promise((resolve, reject) => {
        try {
          const tx = db.transaction(STORE_NAME, 'readwrite');
          const store = tx.objectStore(STORE_NAME);
          const req = store.put(record);

          req.onsuccess = () => resolve();
          req.onerror = () => {
            console.warn('IndexedDB put error, falling back to localStorage', req.error);
            this.saveToLocalStorageFallback(record);
            resolve();
          };
        } catch (err) {
          console.warn('Transaction error, falling back to localStorage', err);
          this.saveToLocalStorageFallback(record);
          resolve();
        }
      });
    } else {
      this.saveToLocalStorageFallback(record);
    }
  }

  private saveToLocalStorageFallback(record: SIHExperimentRecord) {
    const records = this.getLocalStorageExperiments();
    const existingIndex = records.findIndex((r) => r.id === record.id);
    if (existingIndex >= 0) {
      records[existingIndex] = record;
    } else {
      records.unshift(record);
    }
    this.setLocalStorageExperiments(records);
  }

  public async getExperiments(): Promise<SIHExperimentRecord[]> {
    const db = await this.initDB();
    if (db) {
      return new Promise((resolve) => {
        try {
          const tx = db.transaction(STORE_NAME, 'readonly');
          const store = tx.objectStore(STORE_NAME);
          const req = store.getAll();

          req.onsuccess = () => {
            const results: SIHExperimentRecord[] = req.result || [];
            results.sort((a, b) => b.timestamp - a.timestamp);
            resolve(results);
          };

          req.onerror = () => {
            resolve(this.getLocalStorageExperiments());
          };
        } catch (err) {
          resolve(this.getLocalStorageExperiments());
        }
      });
    } else {
      return this.getLocalStorageExperiments();
    }
  }

  public async deleteExperiment(id: string): Promise<void> {
    const db = await this.initDB();
    if (db) {
      try {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        store.delete(id);
      } catch (err) {
        console.warn('Error deleting experiment from IndexedDB:', err);
      }
    }
    const local = this.getLocalStorageExperiments().filter((r) => r.id !== id);
    this.setLocalStorageExperiments(local);
  }

  // Export full telemetry stream as CSV
  public exportCSV(frames: SIHReplayFrame[], filename = 'navisync-sih-telemetry.csv') {
    const headers = [
      'timestamp_sec',
      'time_formatted',
      'ground_truth_lat',
      'ground_truth_lng',
      'ground_truth_speed_kmh',
      'ground_truth_heading_deg',
      'gnss_status',
      'gnss_satellites',
      'gnss_hdop',
      'navisync_lat',
      'navisync_lng',
      'navisync_speed_kmh',
      'navisync_heading_deg',
      'navisync_error_m',
      'navisync_drift_pct',
      'navisync_confidence_pct',
      'navigation_mode',
      'baseline_dr_lat',
      'baseline_dr_lng',
      'baseline_dr_speed_kmh',
      'baseline_dr_heading_deg',
      'baseline_dr_error_m',
      'baseline_dr_drift_pct',
      'zupt_active',
      'ai_motion_active',
      'map_matching_active'
    ];

    const rows = frames.map((f) => [
      f.timeSec,
      `"${f.timeFormatted}"`,
      f.groundTruth.lat,
      f.groundTruth.lng,
      f.groundTruth.speedKmh,
      f.groundTruth.headingDeg,
      `"${f.gnssReading.status}"`,
      f.gnssReading.satellites,
      f.gnssReading.hdop ?? '',
      f.navisync.lat,
      f.navisync.lng,
      f.navisync.speedKmh,
      f.navisync.headingDeg,
      f.navisync.errorMeters,
      f.navisync.accumulatedDriftPct,
      f.navisync.confidencePct,
      `"${f.navisync.navigationMode}"`,
      f.baselineDR.lat,
      f.baselineDR.lng,
      f.baselineDR.speedKmh,
      f.baselineDR.headingDeg,
      f.baselineDR.errorMeters,
      f.baselineDR.accumulatedDriftPct,
      f.navisync.zuptActive ? 1 : 0,
      f.navisync.aiMotionActive ? 1 : 0,
      f.navisync.mapMatchingActive ? 1 : 0
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  // Export clean Evaluator Benchmark Report
  public exportReport(
    summary: SIHJourneySummary,
    metrics: SIHBenchmarkMetrics,
    experimentId = `EXP-${Date.now().toString(36).toUpperCase()}`
  ) {
    const reportText = `================================================================================
NAVISYNC (SIH26168) — EVALUATION & REPLAY BENCHMARK REPORT
================================================================================
Experiment ID    : ${experimentId}
Date Generated   : ${new Date().toLocaleString()}
Evaluator Target : SIH Problem Statement SIH26168 (<10% Drift Threshold)

1. JOURNEY METADATA
--------------------------------------------------------------------------------
Route            : ${summary.routeName}
Origin           : ${summary.startLocation}
Destination      : ${summary.destinationLocation}
Distance         : ${metrics.distanceTravelledKm} km
Duration         : ${metrics.durationMin} minutes
Average Speed    : ${metrics.averageSpeedKmh} km/h
Max Speed        : ${metrics.maxSpeedKmh} km/h
GNSS Availability: ${summary.gnssAvailabilityPct}%
GNSS Outage Time : ${metrics.gnssOutageSec} seconds (Subterranean Underpass)

2. CORE EXPERIMENTAL RESULTS (GNSS OUTAGE SEGMENT)
--------------------------------------------------------------------------------
Metric                     Baseline Conventional DR     NaviSync Pipeline
--------------------------------------------------------------------------------
Final Position Error       ${metrics.baselineFinalErrorM.toFixed(1)} meters                 ${metrics.navisyncFinalErrorM.toFixed(1)} meters
Root Mean Sq Error (RMSE)  ${metrics.baselineRmseM.toFixed(1)} meters                 ${metrics.navisyncRmseM.toFixed(1)} meters
Measured Drift Rate        ${metrics.baselineDriftPct.toFixed(2)}%                       ${metrics.navisyncDriftPct.toFixed(2)}%
Pipeline Advantage         ---                          +${metrics.improvementPct.toFixed(1)}% Improvement

3. SIH BENCHMARK VERIFICATION
--------------------------------------------------------------------------------
Required Target  : < ${metrics.sihTargetPct.toFixed(1)}% Drift
NaviSync Result  : ${metrics.navisyncDriftPct.toFixed(2)}% Drift
Compliance State : ${metrics.isWithinTarget ? '✓ WITHIN TARGET (PASSED)' : '⚠ ABOVE TARGET (REQUIRES OPTIMIZATION)'}

Verification Note:
All telemetry generated from synchronized inertial-sensor replay feed with
active AI motion filtering, Zero-Velocity Update (ZUPT) clamping, and road
network orthogonal map-matching.
================================================================================
`;

    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `navisync-evaluation-report-${experimentId}.txt`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

export const globalExperimentService = new ExperimentHistoryService();
