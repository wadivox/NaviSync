import { SensorCapabilityReport, SensorStatusType, VehicleAlignment } from '../types/navigation';

class SensorCapabilityManager {
  private report: SensorCapabilityReport = {
    geolocation: 'PROMPT',
    deviceOrientation: 'PROMPT',
    deviceMotion: 'PROMPT',
    accelerometer: 'UNAVAILABLE',
    gyroscope: 'UNAVAILABLE',
    magnetometer: 'UNAVAILABLE',
    highAccuracyGeo: false,
    hasOrientationPermission: false,
    needsUserGesture: false,
    lastUpdated: Date.now()
  };

  private vehicleAlignment: VehicleAlignment = {
    deviceVehicleYawOffset: 0,
    deviceVehiclePitchOffset: 0,
    deviceVehicleRollOffset: 0,
    isCalibrated: false
  };

  private listeners: Set<(report: SensorCapabilityReport) => void> = new Set();
  private alignmentListeners: Set<(alignment: VehicleAlignment) => void> = new Set();

  constructor() {
    this.loadAlignmentFromStorage();
    this.detectCapabilities();
  }

  private loadAlignmentFromStorage() {
    try {
      if (typeof window !== 'undefined') {
        const stored = localStorage.getItem('navisync_vehicle_alignment');
        if (stored) {
          this.vehicleAlignment = JSON.parse(stored);
        }
      }
    } catch (e) {
      console.warn('Failed to load alignment from storage', e);
    }
  }

  public detectCapabilities() {
    if (typeof window === 'undefined') return;

    // 1. Geolocation API check
    if ('geolocation' in navigator) {
      this.report.geolocation = 'AVAILABLE';
      if ('permissions' in navigator) {
        navigator.permissions.query({ name: 'geolocation' as PermissionName }).then((result) => {
          if (result.state === 'granted') {
            this.report.geolocation = 'ACTIVE';
            this.report.highAccuracyGeo = true;
          } else if (result.state === 'denied') {
            this.report.geolocation = 'DENIED';
            this.report.highAccuracyGeo = false;
          } else {
            this.report.geolocation = 'PROMPT';
          }
          this.notify();
        }).catch(() => {
          // Permissions query not supported or failed
        });
      }
    } else {
      this.report.geolocation = 'UNSUPPORTED';
    }

    // 2. DeviceOrientation check & iOS permission detection
    if ('DeviceOrientationEvent' in window) {
      const DeviceOrientationAny = window.DeviceOrientationEvent as any;
      if (typeof DeviceOrientationAny.requestPermission === 'function') {
        this.report.deviceOrientation = 'PROMPT';
        this.report.needsUserGesture = true;
      } else {
        this.report.deviceOrientation = 'AVAILABLE';
        this.report.needsUserGesture = false;
      }
    } else {
      this.report.deviceOrientation = 'UNSUPPORTED';
    }

    // 3. DeviceMotion check
    if ('DeviceMotionEvent' in window) {
      this.report.deviceMotion = 'AVAILABLE';
    } else {
      this.report.deviceMotion = 'UNSUPPORTED';
    }

    this.report.lastUpdated = Date.now();
    this.notify();
  }

  public async requestSensorsPermission(): Promise<boolean> {
    if (typeof window === 'undefined') return false;

    let granted = true;
    try {
      const DeviceOrientationAny = window.DeviceOrientationEvent as any;
      if (typeof DeviceOrientationAny?.requestPermission === 'function') {
        const orientationRes = await DeviceOrientationAny.requestPermission();
        if (orientationRes === 'granted') {
          this.report.deviceOrientation = 'ACTIVE';
          this.report.hasOrientationPermission = true;
        } else {
          this.report.deviceOrientation = 'DENIED';
          granted = false;
        }
      }

      const DeviceMotionAny = window.DeviceMotionEvent as any;
      if (typeof DeviceMotionAny?.requestPermission === 'function') {
        const motionRes = await DeviceMotionAny.requestPermission();
        if (motionRes === 'granted') {
          this.report.deviceMotion = 'ACTIVE';
        } else {
          this.report.deviceMotion = 'DENIED';
          granted = false;
        }
      }
    } catch (e) {
      console.warn('Error requesting device orientation/motion permission:', e);
      granted = false;
    }

    this.report.lastUpdated = Date.now();
    this.notify();
    return granted;
  }

  public async requestPermissions(): Promise<boolean> {
    return this.requestSensorsPermission();
  }

  public recordSensorActivity(
    type: 'geolocation' | 'accelerometer' | 'gyroscope' | 'magnetometer' | 'deviceOrientation' | 'deviceMotion',
    active: boolean
  ) {
    if (type === 'geolocation') {
      this.report.geolocation = active ? 'ACTIVE' : 'UNAVAILABLE';
      if (active) this.report.highAccuracyGeo = true;
    } else if (type === 'accelerometer') {
      this.report.accelerometer = active ? 'ACTIVE' : 'UNAVAILABLE';
    } else if (type === 'gyroscope') {
      this.report.gyroscope = active ? 'ACTIVE' : 'UNAVAILABLE';
    } else if (type === 'magnetometer') {
      this.report.magnetometer = active ? 'ACTIVE' : 'UNAVAILABLE';
    } else if (type === 'deviceOrientation') {
      this.report.deviceOrientation = active ? 'ACTIVE' : 'UNAVAILABLE';
    } else if (type === 'deviceMotion') {
      this.report.deviceMotion = active ? 'ACTIVE' : 'UNAVAILABLE';
    }
    this.report.lastUpdated = Date.now();
    this.notify();
  }

  public getReport(): SensorCapabilityReport {
    return { ...this.report };
  }

  public getVehicleAlignment(): VehicleAlignment {
    return { ...this.vehicleAlignment };
  }

  public setVehicleAlignment(alignment: Partial<VehicleAlignment>) {
    this.vehicleAlignment = {
      ...this.vehicleAlignment,
      ...alignment,
      isCalibrated: true,
      lastCalibratedAt: Date.now()
    };
    try {
      localStorage.setItem('navisync_vehicle_alignment', JSON.stringify(this.vehicleAlignment));
    } catch (e) {
      console.warn('Failed to save alignment', e);
    }
    this.alignmentListeners.forEach((cb) => cb(this.vehicleAlignment));
  }

  public resetVehicleAlignment() {
    this.vehicleAlignment = {
      deviceVehicleYawOffset: 0,
      deviceVehiclePitchOffset: 0,
      deviceVehicleRollOffset: 0,
      isCalibrated: false
    };
    try {
      localStorage.removeItem('navisync_vehicle_alignment');
    } catch (e) {
      console.warn('Failed to reset alignment', e);
    }
    this.alignmentListeners.forEach((cb) => cb(this.vehicleAlignment));
  }

  public subscribe(cb: (report: SensorCapabilityReport) => void) {
    this.listeners.add(cb);
    cb(this.getReport());
    return () => this.listeners.delete(cb);
  }

  public subscribeAlignment(cb: (alignment: VehicleAlignment) => void) {
    this.alignmentListeners.add(cb);
    cb(this.getVehicleAlignment());
    return () => this.alignmentListeners.delete(cb);
  }

  private notify() {
    this.listeners.forEach((cb) => cb(this.getReport()));
  }
}

export const globalSensorCapabilityManager = new SensorCapabilityManager();
