import { NavigationMode, GeoCoordinate, TravelHistoryRecord, GNSSOutageSegment, TravelTrajectoryPoint } from '../types/navigation';

export type TravelHistoryEntry = TravelHistoryRecord;
export type { TravelHistoryRecord };

const DB_NAME = 'navisync_travel_db';
const DB_VERSION = 2;
const STORE_NAME = 'travel_history_v2';
const LOCAL_STORAGE_KEY = 'navisync_travel_history_v2';

class TravelHistoryService {
  private dbPromise: Promise<IDBDatabase | null> | null = null;

  constructor() {
    this.initDB();
  }

  private initDB(): Promise<IDBDatabase | null> {
    if (this.dbPromise) return this.dbPromise;

    if (typeof window === 'undefined' || !window.indexedDB) {
      this.dbPromise = Promise.resolve(null);
      return this.dbPromise;
    }

    this.dbPromise = new Promise((resolve) => {
      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
            store.createIndex('startTime', 'startTime', { unique: false });
          }
        };

        request.onsuccess = () => {
          resolve(request.result);
        };

        request.onerror = () => {
          console.warn('IndexedDB unavailable, using localStorage fallback');
          resolve(null);
        };
      } catch (err) {
        console.warn('Error opening IndexedDB:', err);
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  private getLocalStorageTrips(): TravelHistoryRecord[] {
    try {
      const data = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch {
      // ignore
    }
    return this.getDefaultTrips();
  }

  private saveLocalStorageTrips(trips: TravelHistoryRecord[]): void {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(trips));
    } catch {
      // ignore
    }
  }

  private getDefaultTrips(): TravelHistoryRecord[] {
    const now = Date.now();
    return [
      {
        id: 'trip-history-1',
        startTime: now - 3600000 * 3,
        endTime: now - 3600000 * 3 + 1860000,
        dateFormatted: new Date(now - 3600000 * 3).toLocaleString([], {
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        startLocation: 'Mindspace Junction, HITEC City',
        endLocation: 'Inorbit Mall Cyberabad',
        startCoordinate: { lat: 17.4435, lng: 78.3772 },
        endCoordinate: { lat: 17.4344, lng: 78.3866 },
        distanceKm: 3.2,
        durationMinutes: 9,
        stoppedDurationSeconds: 70,
        averageSpeedKmh: 24.5,
        maxSpeedKmh: 48.0,
        navigationMode: 'driving',
        routeCoordinates: [
          [17.4435, 78.3772],
          [17.4421, 78.3789],
          [17.4402, 78.3805],
          [17.4385, 78.3822],
          [17.4367, 78.3838],
          [17.4355, 78.3852],
          [17.4344, 78.3866]
        ],
        gnssOutageDurationSeconds: 42,
        gnssOutageSegments: [
          {
            startTime: now - 3600000 * 3 + 300000,
            endTime: now - 3600000 * 3 + 342000,
            durationSeconds: 42,
            startCoordinate: [17.4402, 78.3805],
            endCoordinate: [17.4385, 78.3822],
            maxDriftMeters: 2.1,
            recoveredConfidence: 0.94,
            cause: 'TUNNEL'
          }
        ],
        gnssAvailabilityPercentage: 92,
        drPercentage: 8,
        estimatedDriftMeters: 2.1,
        overallConfidence: 0.94,
        routeName: 'Cyber Towers via Durgam Cheruvu Link',
        completedNaturally: true
      },
      {
        id: 'trip-history-2',
        startTime: now - 3600000 * 28,
        endTime: now - 3600000 * 28 + 1440000,
        dateFormatted: new Date(now - 3600000 * 28).toLocaleString([], {
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        startLocation: 'Jubilee Hills Check Post',
        endLocation: 'KBR National Park Gate',
        startCoordinate: { lat: 17.4298, lng: 78.4095 },
        endCoordinate: { lat: 17.4215, lng: 78.4182 },
        distanceKm: 2.4,
        durationMinutes: 7,
        stoppedDurationSeconds: 45,
        averageSpeedKmh: 21.0,
        maxSpeedKmh: 42.5,
        navigationMode: 'two_wheeler',
        routeCoordinates: [
          [17.4298, 78.4095],
          [17.4277, 78.4118],
          [17.4255, 78.4140],
          [17.4235, 78.4161],
          [17.4215, 78.4182]
        ],
        gnssOutageDurationSeconds: 0,
        gnssOutageSegments: [],
        gnssAvailabilityPercentage: 100,
        drPercentage: 0,
        estimatedDriftMeters: 0.0,
        overallConfidence: 0.98,
        routeName: 'Road No. 36 Direct',
        completedNaturally: true
      }
    ];
  }

  public async getTrips(): Promise<TravelHistoryRecord[]> {
    const db = await this.initDB();
    if (!db) {
      return this.getLocalStorageTrips();
    }

    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const request = store.getAll();

        request.onsuccess = () => {
          let results: TravelHistoryRecord[] = request.result || [];
          if (results.length === 0) {
            const defaults = this.getDefaultTrips();
            defaults.forEach((t) => this.saveTrip(t));
            resolve(defaults);
          } else {
            results.sort((a, b) => b.startTime - a.startTime);
            resolve(results);
          }
        };

        request.onerror = () => {
          resolve(this.getLocalStorageTrips());
        };
      } catch (e) {
        resolve(this.getLocalStorageTrips());
      }
    });
  }

  public async saveTrip(
    entry: Omit<TravelHistoryRecord, 'id' | 'dateFormatted'> & { id?: string }
  ): Promise<TravelHistoryRecord> {
    const fullRecord: TravelHistoryRecord = {
      ...entry,
      id: entry.id || `trip-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      dateFormatted: new Date(entry.startTime).toLocaleString([], {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    };

    const db = await this.initDB();
    if (!db) {
      const trips = this.getLocalStorageTrips();
      trips.unshift(fullRecord);
      this.saveLocalStorageTrips(trips);
      return fullRecord;
    }

    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const request = store.put(fullRecord);

        request.onsuccess = () => {
          const trips = this.getLocalStorageTrips().filter((t) => t.id !== fullRecord.id);
          trips.unshift(fullRecord);
          this.saveLocalStorageTrips(trips);
          resolve(fullRecord);
        };

        request.onerror = () => {
          const trips = this.getLocalStorageTrips().filter((t) => t.id !== fullRecord.id);
          trips.unshift(fullRecord);
          this.saveLocalStorageTrips(trips);
          resolve(fullRecord);
        };
      } catch {
        const trips = this.getLocalStorageTrips().filter((t) => t.id !== fullRecord.id);
        trips.unshift(fullRecord);
        this.saveLocalStorageTrips(trips);
        resolve(fullRecord);
      }
    });
  }

  public async deleteTrip(id: string): Promise<void> {
    const db = await this.initDB();
    if (!db) {
      const trips = this.getLocalStorageTrips().filter((t) => t.id !== id);
      this.saveLocalStorageTrips(trips);
      return;
    }

    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const request = store.delete(id);

        request.onsuccess = () => {
          const trips = this.getLocalStorageTrips().filter((t) => t.id !== id);
          this.saveLocalStorageTrips(trips);
          resolve();
        };

        request.onerror = () => {
          const trips = this.getLocalStorageTrips().filter((t) => t.id !== id);
          this.saveLocalStorageTrips(trips);
          resolve();
        };
      } catch {
        const trips = this.getLocalStorageTrips().filter((t) => t.id !== id);
        this.saveLocalStorageTrips(trips);
        resolve();
      }
    });
  }

  public async clearAll(): Promise<void> {
    const db = await this.initDB();
    if (!db) {
      this.saveLocalStorageTrips([]);
      return;
    }

    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const request = store.clear();

        request.onsuccess = () => {
          this.saveLocalStorageTrips([]);
          resolve();
        };

        request.onerror = () => {
          this.saveLocalStorageTrips([]);
          resolve();
        };
      } catch {
        this.saveLocalStorageTrips([]);
        resolve();
      }
    });
  }

  public async exportHistoryJSON(): Promise<string> {
    const trips = await this.getTrips();
    return JSON.stringify({
      exportedAt: new Date().toISOString(),
      system: 'NaviSync Intelligent GNSS-Denied Navigation',
      totalTrips: trips.length,
      trips
    }, null, 2);
  }

  // --- RAG Tools for Navi AI (Requirement 26) ---

  public async getTravelHistory(): Promise<TravelHistoryRecord[]> {
    return this.getTrips();
  }

  public async getTripDetails(tripId: string): Promise<TravelHistoryRecord | null> {
    const trips = await this.getTrips();
    return trips.find((t) => t.id === tripId) || null;
  }

  public async getTravelStatistics(): Promise<{
    totalTrips: number;
    totalDistanceKm: number;
    totalDurationMinutes: number;
    averageSpeedKmh: number;
    longestTripKm: number;
    totalGnssOutageSeconds: number;
    overallGnssAvailabilityPct: number;
  }> {
    const trips = await this.getTrips();
    if (trips.length === 0) {
      return {
        totalTrips: 0,
        totalDistanceKm: 0,
        totalDurationMinutes: 0,
        averageSpeedKmh: 0,
        longestTripKm: 0,
        totalGnssOutageSeconds: 0,
        overallGnssAvailabilityPct: 100
      };
    }

    let totalDist = 0;
    let totalDur = 0;
    let maxDist = 0;
    let totalOutage = 0;
    let speedSum = 0;

    for (const t of trips) {
      totalDist += t.distanceKm;
      totalDur += t.durationMinutes;
      if (t.distanceKm > maxDist) maxDist = t.distanceKm;
      totalOutage += t.gnssOutageDurationSeconds || 0;
      speedSum += t.averageSpeedKmh || 0;
    }

    const totalSeconds = totalDur * 60;
    const gnssAvailabilityPct = totalSeconds > 0
      ? Math.round(((totalSeconds - totalOutage) / totalSeconds) * 100)
      : 100;

    return {
      totalTrips: trips.length,
      totalDistanceKm: Math.round(totalDist * 10) / 10,
      totalDurationMinutes: Math.round(totalDur),
      averageSpeedKmh: Math.round((speedSum / trips.length) * 10) / 10,
      longestTripKm: Math.round(maxDist * 10) / 10,
      totalGnssOutageSeconds: totalOutage,
      overallGnssAvailabilityPct: Math.max(0, Math.min(100, gnssAvailabilityPct))
    };
  }

  public async getRecentTrips(limit = 5): Promise<TravelHistoryRecord[]> {
    const trips = await this.getTrips();
    return trips.slice(0, limit);
  }

  public async getFrequentRoutes(): Promise<{ route: string; count: number }[]> {
    const trips = await this.getTrips();
    const map = new Map<string, number>();

    for (const t of trips) {
      const key = `${t.startLocation} → ${t.endLocation}`;
      map.set(key, (map.get(key) || 0) + 1);
    }

    return Array.from(map.entries())
      .map(([route, count]) => ({ route, count }))
      .sort((a, b) => b.count - a.count);
  }
}

export const globalTravelHistoryService = new TravelHistoryService();
