import React, { useState, useEffect, useRef, useCallback } from 'react';
import { LeafletMap } from './components/Map/LeafletMap';
import { NavigationCockpit } from './components/Navigation/NavigationCockpit';
import { SearchBar } from './components/Search/SearchBar';
import { CategoryChips } from './components/Search/CategoryChips';
import { PlaceDetailSheet } from './components/Search/PlaceDetailSheet';
import { PlacesCarousel } from './components/Search/PlacesCarousel';
import { RoutePlanner } from './components/Routes/RoutePlanner';
import { NaviCopilot } from './components/Assistant/NaviCopilot';
import { IntelligenceDashboard } from './components/TechnicalDashboard/IntelligenceDashboard';
import { NaviSyncStatusPanel } from './components/TechnicalDashboard/NaviSyncStatusPanel';
import { EvaluatorControls } from './components/TechnicalDashboard/EvaluatorControls';
import { IOVNBDModal } from './components/TechnicalDashboard/IOVNBDModal';
import { OfflineManagerModal } from './components/Offline/OfflineManagerModal';
import { TravelHistoryModal } from './components/Navigation/TravelHistoryModal';
import { globalTravelHistoryService, TravelHistoryEntry } from './services/TravelHistoryService';
import { AppHeader } from './components/Header/AppHeader';
import { SIHDemoPage } from './components/SIHDemo/SIHDemoPage';
import { X } from 'lucide-react';

function calculateBearing(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const toDeg = (rad: number) => (rad * 180) / Math.PI;
  const phi1 = toRad(lat1);
  const phi2 = toRad(lat2);
  const deltaLambda = toRad(lon2 - lon1);
  const y = Math.sin(deltaLambda) * Math.cos(phi2);
  const x = Math.cos(phi1) * Math.sin(phi2) - Math.sin(phi1) * Math.cos(deltaLambda);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

function calculateDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3;
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

import {
  GeoCoordinate,
  RouteOption,
  PlaceItem,
  FusionState,
  GNSSState,
  NavigationMode,
  IMURawData,
  IMUFilteredData,
  GNSSReading,
  NaviSyncNavigationState
} from './types/navigation';
import { NavigationContextPayload } from './types/rag';
import { SupportedLanguage, TRANSLATIONS } from './i18n/translations';

import { GNSSLossDetector } from './engines/GNSSLossDetector';
import { AIMotionFilter } from './engines/AIMotionFilter';
import { SensorFusionEngine } from './engines/SensorFusionEngine';
import { RoutingProvider } from './providers/RoutingProvider';
import { PlacesProvider } from './providers/PlacesProvider';
import { GeocodingResult } from './providers/GeocodingProvider';
import { globalVoiceService } from './services/VoiceService';
import { globalSensorService } from './services/SensorService';
import { globalOfflineService } from './services/OfflineService';
import { globalTripRecorder } from './services/TripRecorder';

export default function App() {
  // 1. Core State
  const [currentPosition, setCurrentPosition] = useState<GeoCoordinate>({
    lat: 17.4504,
    lng: 78.3808
  });

  const [language, setLanguage] = useState<SupportedLanguage>('en');
  const [gnssState, setGnssState] = useState<GNSSState>('GNSS_AVAILABLE');
  const [activeRoute, setActiveRoute] = useState<RouteOption | null>(null);
  const [candidateRoutes, setCandidateRoutes] = useState<RouteOption[]>([]);
  const [selectedRouteId, setSelectedRouteId] = useState<string>('');
  const [destinationName, setDestinationName] = useState<string>('');
  const [destinationCoordinate, setDestinationCoordinate] = useState<GeoCoordinate | null>(null);
  const [nearbyPlaces, setNearbyPlaces] = useState<PlaceItem[]>([]);
  const [isStatusPanelOpen, setIsStatusPanelOpen] = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  const [selectedPlace, setSelectedPlace] = useState<PlaceItem | null>(null);
  const [activeCategory, setActiveCategory] = useState<PlaceItem['category'] | null>(null);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [showTraditionalComparison, setShowTraditionalComparison] = useState(false);
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  const [transportMode, setTransportMode] = useState<NavigationMode>('driving');
  const [gnssHeading, setGnssHeading] = useState<number | null>(null);
  const [compassHeading, setCompassHeading] = useState<number | null>(null);
  const [recenterTrigger, setRecenterTrigger] = useState(0);

  // Modals & Panels
  const [isIntelligenceOpen, setIsIntelligenceOpen] = useState(false);
  const [isEvaluatorOpen, setIsEvaluatorOpen] = useState(false);
  const [isIOVNBDOldOpen, setIsIOVNBDOldOpen] = useState(false);
  const [isOfflineModalOpen, setIsOfflineModalOpen] = useState(false);
  const [isTravelHistoryOpen, setIsTravelHistoryOpen] = useState(false);
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [isRoutePlannerOpen, setIsRoutePlannerOpen] = useState(false);

  // Persona & View Switching (SIH Demo is strictly Admin Persona only)
  const [currentPersona, setCurrentPersona] = useState<'admin' | 'user'>(() => {
    try {
      const saved = localStorage.getItem('navisync_persona');
      return saved === 'user' ? 'user' : 'admin';
    } catch {
      return 'admin';
    }
  });
  const [activeView, setActiveView] = useState<'navigation' | 'sih_demo'>('navigation');

  const handleTogglePersona = () => {
    setCurrentPersona((prev) => {
      const next = prev === 'admin' ? 'user' : 'admin';
      try {
        localStorage.setItem('navisync_persona', next);
      } catch {}
      if (next === 'user' && activeView === 'sih_demo') {
        setActiveView('navigation');
      }
      return next;
    });
  };

  // Genuine Real-time Speed & Trip Metadata
  const [deviceGnssSpeedMps, setDeviceGnssSpeedMps] = useState<number | null>(null);
  const lastPositionRef = useRef<{ lat: number; lng: number; time: number } | null>(null);
  const initialPositionFixedRef = useRef<boolean>(false);
  const tripMetadataRef = useRef<{
    startTime: number;
    startPos: GeoCoordinate;
    destinationName: string;
    destinationCoord: GeoCoordinate;
    mode: NavigationMode;
    routeCoords: [number, number][];
    distanceKm: number;
    estimatedDuration: number;
  } | null>(null);

  // 2. Engines & Providers
  const gnssDetectorRef = useRef(new GNSSLossDetector());
  const aiMotionFilterRef = useRef(new AIMotionFilter());
  const fusionEngineRef = useRef(new SensorFusionEngine(17.4504, 78.3808, 45));
  const routingProviderRef = useRef(new RoutingProvider());
  const placesProviderRef = useRef(new PlacesProvider());

  // 3. Sensor & Telemetry State
  const [rawIMU, setRawIMU] = useState<IMURawData>({
    ax: 0.4,
    ay: 0.05,
    az: 9.81,
    gx: 0,
    gy: 0,
    gz: 0,
    timestamp: Date.now(),
    isSimulated: true
  });

  const [filteredIMU, setFilteredIMU] = useState<IMUFilteredData>({
    axFiltered: 0.4,
    ayFiltered: 0.05,
    azFiltered: 9.81,
    pitch: 0,
    roll: 0,
    yaw: 0,
    forwardAccel: 0.4,
    lateralAccel: 0,
    noiseLevel: 0.05,
    vibrationAnomaly: false,
    filterType: 'AI_TCN_PROTOTYPE'
  });

  const [fusionState, setFusionState] = useState<FusionState>({
    lat: 17.4504,
    lng: 78.3808,
    speedKmh: 0,
    headingDeg: 45,
    confidence: 0.98,
    driftMeters: 0,
    gnssOutageDurationSec: 0,
    isZuptActive: false,
    isMapMatched: true,
    activeEngine: 'GNSS',
    rawDriftMetersWithoutNaviSync: 0,
    gnssWeight: 0.85,
    imuWeight: 0.15
  });

  const [navState, setNavState] = useState<NaviSyncNavigationState>(() =>
    fusionEngineRef.current.getNavigationState()
  );

  const [travelStats, setTravelStats] = useState({
    totalTrips: 0,
    totalDistanceKm: 0,
    avgSpeedKmh: 0,
    longestTripKm: 0,
    recentSummary: ''
  });

  const t = TRANSLATIONS[language];

  // Initialize Geolocation & Voice
  useEffect(() => {
    globalVoiceService.setLanguage(language);
    globalVoiceService.setEnabled(voiceEnabled);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setCurrentPosition({ lat, lng });
          fusionEngineRef.current.setPosition(lat, lng);
          initialPositionFixedRef.current = true;

          const genuineInitialSpeedKmh =
            pos.coords.speed !== null && !isNaN(pos.coords.speed) && pos.coords.speed >= 0
              ? pos.coords.speed * 3.6
              : 0;

          setFusionState((prev) => ({
            ...prev,
            lat,
            lng,
            speedKmh: genuineInitialSpeedKmh
          }));

          setRecenterTrigger((prev) => prev + 1);
        },
        (err) => {
          console.warn('Browser geolocation notice:', err.message);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    }
  }, []);

  // Sync Voice Language
  useEffect(() => {
    globalVoiceService.setLanguage(language);
  }, [language]);

  // Load Travel Statistics for RAG Assistant
  useEffect(() => {
    const fetchStats = async () => {
      try {
        const stats = await globalTravelHistoryService.getTravelStatistics();
        const recent = await globalTravelHistoryService.getRecentTrips(3);
        const summaryStr = recent
          .map((r) => `${r.startLocation} to ${r.endLocation} (${r.distanceKm} km)`)
          .join('; ');
        setTravelStats({
          totalTrips: stats.totalTrips,
          totalDistanceKm: stats.totalDistanceKm,
          avgSpeedKmh: stats.averageSpeedKmh,
          longestTripKm: stats.longestTripKm,
          recentSummary: summaryStr
        });
      } catch (err) {
        console.warn('Could not load travel stats for RAG:', err);
      }
    };
    fetchStats();
  }, [isTravelHistoryOpen, isNavigating]);

  // Listen for Device GNSS Speed, GNSS Heading, and Compass Orientation
  useEffect(() => {
    let watchId: number | null = null;
    if (navigator.geolocation) {
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setCurrentPosition({ lat, lng });

          if (!initialPositionFixedRef.current) {
            initialPositionFixedRef.current = true;
            fusionEngineRef.current.setPosition(lat, lng);
            setFusionState((prev) => ({ ...prev, lat, lng }));
          }

          // Priority 1: GNSS Heading from coords
          if (pos.coords.heading !== null && !isNaN(pos.coords.heading) && pos.coords.heading >= 0) {
            setGnssHeading(pos.coords.heading);
          }

          // Priority 1: GNSS Speed from coords
          if (pos.coords.speed !== null && !isNaN(pos.coords.speed) && pos.coords.speed >= 0) {
            setDeviceGnssSpeedMps(pos.coords.speed);
          } else if (lastPositionRef.current) {
            // Calculate speed from coordinate delta if coords.speed is null
            const dtSec = (Date.now() - lastPositionRef.current.time) / 1000;
            if (dtSec > 0.8 && dtSec < 15) {
              const distM = calculateDistanceMeters(
                lastPositionRef.current.lat,
                lastPositionRef.current.lng,
                lat,
                lng
              );
              const computedMps = distM / dtSec;
              if (computedMps >= 0 && computedMps < 55) {
                setDeviceGnssSpeedMps(computedMps);
              }
            }
          }
          lastPositionRef.current = { lat, lng, time: Date.now() };
        },
        (err) => console.warn('Geolocation heading/position notice:', err.message),
        { enableHighAccuracy: true, maximumAge: 1000 }
      );
    }

    // Priority 2: Compass from DeviceOrientationEvent (mobile compass fallback)
    const handleOrientation = (e: DeviceOrientationEvent) => {
      if ((e as any).webkitCompassHeading !== undefined && (e as any).webkitCompassHeading !== null) {
        setCompassHeading((e as any).webkitCompassHeading);
      } else if (e.alpha !== null && !isNaN(e.alpha)) {
        const heading = (360 - e.alpha) % 360;
        setCompassHeading(heading);
      }
    };

    window.addEventListener('deviceorientation', handleOrientation, true);
    window.addEventListener('deviceorientationabsolute' as any, handleOrientation, true);

    return () => {
      if (watchId !== null) navigator.geolocation.clearWatch(watchId);
      window.removeEventListener('deviceorientation', handleOrientation, true);
      window.removeEventListener('deviceorientationabsolute' as any, handleOrientation, true);
    };
  }, []);

  // Subscribe to 10Hz Sensor Telemetry
  useEffect(() => {
    const unsubscribe = globalSensorService.subscribe((raw) => {
      setRawIMU(raw);

      // 1. Run AI Motion Filter
      const filtered = aiMotionFilterRef.current.filter(raw);
      setFilteredIMU(filtered);

      // 2. GNSS Reading (if available)
      const currentGnssState = gnssDetectorRef.current.getState();
      setGnssState(currentGnssState);

      // Speed calculation:
      // Primary: GNSS speed (from device coords.speed or distance delta)
      // If navigating: mode-specific realistic dynamic speed with turn variations
      // If GPS denied/lost: null (forces SensorFusionEngine to use IMUSpeedEstimator)
      let liveSpeedMps: number | null = null;
      if (currentGnssState === 'GNSS_AVAILABLE') {
        if (isNavigating) {
          const baseSpeedMps =
            transportMode === 'walking'
              ? 1.25 + (Math.sin(Date.now() / 2000) * 0.15) // ~4.5 km/h
              : transportMode === 'cycling'
              ? 4.8 + (Math.sin(Date.now() / 2500) * 0.4) // ~17.5 km/h
              : transportMode === 'two_wheeler'
              ? 9.5 + (Math.sin(Date.now() / 3000) * 0.8) // ~34 km/h
              : 12.5 + (Math.sin(Date.now() / 3500) * 1.2); // ~45 km/h
          liveSpeedMps = deviceGnssSpeedMps !== null && deviceGnssSpeedMps > 0.5 ? deviceGnssSpeedMps : baseSpeedMps;
        } else if (deviceGnssSpeedMps !== null && deviceGnssSpeedMps >= 0) {
          liveSpeedMps = deviceGnssSpeedMps;
        } else {
          liveSpeedMps = 0;
        }
      } else {
        // In GPS lost / denied / tunnel: pass null so IMUSpeedEstimator integrates IMU forward acceleration!
        liveSpeedMps = null;
      }

      const fakeReading: GNSSReading | null =
        currentGnssState === 'GNSS_AVAILABLE'
          ? {
              latitude: currentPosition.lat,
              longitude: currentPosition.lng,
              altitude: 540,
              accuracy: 4.5,
              speed: liveSpeedMps !== null ? liveSpeedMps : 0,
              heading: fusionState.headingDeg,
              timestamp: Date.now()
            }
          : null;

      // 3. Sensor Fusion Step
      const updatedFusion = fusionEngineRef.current.update(
        fakeReading,
        currentGnssState,
        filtered,
        raw.gz,
        activeRoute?.coordinates || [],
        compassHeading
      );

      const authoritativeNavState = fusionEngineRef.current.getNavigationState();
      setFusionState(updatedFusion);
      setNavState(authoritativeNavState);

      // 4. Update Trip Recorder with Authoritative Navigation State
      globalTripRecorder.update(
        authoritativeNavState,
        isNavigating,
        activeRoute?.summary || destinationName || 'Navigation Trip'
      );
    });

    return () => unsubscribe();
  }, [currentPosition, activeRoute, isNavigating, transportMode, deviceGnssSpeedMps, fusionState.headingDeg, compassHeading, destinationName]);

  // Turn-by-Turn Navigation Progress Simulation
  useEffect(() => {
    if (!isNavigating || !activeRoute || activeRoute.coordinates.length < 2) return;

    let waypointIdx = 0;
    const interval = setInterval(() => {
      waypointIdx += 1;

      if (waypointIdx >= activeRoute.coordinates.length) {
        // Arrived at destination
        globalVoiceService.speak('You have arrived at your destination.', true);
        globalTripRecorder.endTrip(true);
        saveTripToHistory(true);
        setIsNavigating(false);
        clearInterval(interval);
        return;
      }

      const targetCoord = activeRoute.coordinates[waypointIdx];
      const prevCoord = activeRoute.coordinates[Math.max(0, waypointIdx - 1)];
      let bearing = fusionState.headingDeg;
      if (prevCoord && targetCoord && (prevCoord[0] !== targetCoord[0] || prevCoord[1] !== targetCoord[1])) {
        bearing = calculateBearing(prevCoord[0], prevCoord[1], targetCoord[0], targetCoord[1]);
      }
      fusionEngineRef.current.setPosition(targetCoord[0], targetCoord[1], bearing);

      // Calculate step index along route
      const stepIdx = Math.min(
        activeRoute.steps.length - 1,
        Math.floor((waypointIdx / activeRoute.coordinates.length) * activeRoute.steps.length)
      );

      if (stepIdx !== currentStepIndex) {
        setCurrentStepIndex(stepIdx);
        const step = activeRoute.steps[stepIdx];
        if (step) {
          globalVoiceService.speak(step.instruction);
        }
      }

      // Check for Tunnel entry in route
      if (activeRoute.tunnelSegments && activeRoute.tunnelSegments.length > 0) {
        const tunnel = activeRoute.tunnelSegments[0];
        if (waypointIdx === tunnel.startIdx) {
          // Entering Tunnel -> GNSS Blackout
          gnssDetectorRef.current.forceState('GNSS_LOST');
          setGnssState('GNSS_LOST');
          globalVoiceService.speak(t.signalLostInertialEngaged, true);
        } else if (waypointIdx === tunnel.endIdx) {
          // Exiting Tunnel -> GNSS Restored
          gnssDetectorRef.current.forceState('GNSS_RESTORING');
          setGnssState('GNSS_RESTORING');
          setTimeout(() => {
            gnssDetectorRef.current.forceState('GNSS_AVAILABLE');
            setGnssState('GNSS_AVAILABLE');
            globalVoiceService.speak(t.signalRestoredSynced, true);
          }, 2000);
        }
      }
    }, 1200);

    return () => clearInterval(interval);
  }, [isNavigating, activeRoute, currentStepIndex, t]);

  // Route Planning Handlers
  const handleClearDestination = () => {
    setActiveRoute(null);
    setCandidateRoutes([]);
    setSelectedRouteId('');
    setDestinationCoordinate(null);
    setDestinationName('');
    setIsRoutePlannerOpen(false);
    setSelectedPlace(null);
    setActiveCategory(null);
    setIsNavigating(false);
    setCurrentStepIndex(0);
    setRecenterTrigger((prev) => prev + 1);
  };

  const handleSelectLocation = async (result: GeocodingResult) => {
    // 1. Instantly clear old route line and destination pin first to prevent visual stacking
    setActiveRoute(null);
    setCandidateRoutes([]);
    setSelectedRouteId('');
    setDestinationCoordinate(null);

    // 2. Set new destination info
    setDestinationName(result.name);
    setDestinationCoordinate({ lat: result.lat, lng: result.lng });
    setSelectedPlace(null);

    // 3. Query routes
    const routes = await routingProviderRef.current.getRoutes(
      currentPosition.lat,
      currentPosition.lng,
      result.lat,
      result.lng,
      transportMode
    );

    setCandidateRoutes(routes);
    if (routes.length > 0) {
      setSelectedRouteId(routes[0].id);
      setActiveRoute(routes[0]);
    }
    setIsRoutePlannerOpen(true);
  };

  const handleMapClick = (lat: number, lng: number) => {
    if (isNavigating) return;
    handleSelectLocation({
      name: `Dropped Pin`,
      displayName: `${lat.toFixed(5)}, ${lng.toFixed(5)}`,
      lat,
      lng,
      type: 'poi'
    });
  };

  const handleSelectCategory = async (cat: PlaceItem['category']) => {
    setActiveCategory(cat);
    const places = await placesProviderRef.current.getNearbyPlaces(
      currentPosition.lat,
      currentPosition.lng,
      cat,
      5.0
    );
    setNearbyPlaces(places);
    if (places.length > 0) {
      setSelectedPlace(places[0]);
    }
  };

  const handleTriggerEmergency = async () => {
    const hospitals = await placesProviderRef.current.getNearbyPlaces(
      currentPosition.lat,
      currentPosition.lng,
      'hospital',
      5.0
    );
    setNearbyPlaces(hospitals);
    if (hospitals.length > 0) {
      handleSelectLocation({
        name: hospitals[0].name,
        displayName: hospitals[0].address,
        lat: hospitals[0].lat,
        lng: hospitals[0].lng,
        type: 'hospital'
      });
      globalVoiceService.speak('Emergency SOS activated. Locating nearest trauma center.', true);
    }
  };

  const saveTripToHistory = async (completedNaturally: boolean) => {
    if (!tripMetadataRef.current) return;
    const meta = tripMetadataRef.current;
    const elapsedMinutes = Math.max(1, Math.round((Date.now() - meta.startTime) / 60000));
    const avgSpeed = elapsedMinutes > 0 ? (meta.distanceKm / (elapsedMinutes / 60)) : 0;

    try {
      await globalTravelHistoryService.saveTrip({
        startTime: meta.startTime,
        endTime: Date.now(),
        timestamp: meta.startTime,
        startLocation: 'Current Location',
        endLocation: meta.destinationName,
        destinationName: meta.destinationName,
        startCoordinate: meta.startPos,
        endCoordinate: meta.destinationCoord,
        destinationCoord: meta.destinationCoord,
        distanceKm: meta.distanceKm,
        durationMinutes: elapsedMinutes,
        stoppedDurationSeconds: 0,
        navigationMode: meta.mode,
        mode: meta.mode,
        routeCoordinates: meta.routeCoords,
        completedNaturally,
        averageSpeedKmh: Math.min(120, Math.max(2, Math.round(avgSpeed))),
        maxSpeedKmh: Math.min(130, Math.max(5, Math.round(avgSpeed * 1.3))),
        gnssOutageDurationSeconds: 0,
        gnssOutageSegments: [],
        gnssAvailabilityPercentage: 100,
        drPercentage: 0,
        estimatedDriftMeters: 0,
        overallConfidence: 0.98
      });
    } catch (err) {
      console.warn('Could not save trip to travel history:', err);
    }
    tripMetadataRef.current = null;
  };

  const handleStartNavigation = () => {
    if (!activeRoute) return;
    tripMetadataRef.current = {
      startTime: Date.now(),
      startPos: { ...currentPosition },
      destinationName: destinationName || 'Destination',
      destinationCoord: destinationCoordinate || { lat: currentPosition.lat, lng: currentPosition.lng },
      mode: transportMode,
      routeCoords: activeRoute.coordinates,
      distanceKm: activeRoute.distanceKm,
      estimatedDuration: activeRoute.durationMinutes
    };
    globalTripRecorder.startTrip(destinationName || activeRoute.summary || 'Navigation Journey', transportMode);
    setIsRoutePlannerOpen(false);
    setIsNavigating(true);
    setCurrentStepIndex(0);
    globalVoiceService.speak(activeRoute.steps[0]?.instruction || 'Starting navigation.', true);
  };

  const handleStopNavigation = async () => {
    await globalTripRecorder.endTrip(false);
    saveTripToHistory(false);
    handleClearDestination();
    globalVoiceService.speak('Navigation stopped.', true);
  };

  const handleReopenTripRoute = (entry: TravelHistoryEntry) => {
    // 1. Clear previous navigation and routes first
    setActiveRoute(null);
    setCandidateRoutes([]);
    setSelectedRouteId('');
    setDestinationCoordinate(null);

    const destName = entry.endLocation || entry.destinationName || 'Destination';
    const destCoord = entry.endCoordinate || entry.destinationCoord || (entry.routeCoordinates.length > 0 ? { lat: entry.routeCoordinates[entry.routeCoordinates.length - 1][0], lng: entry.routeCoordinates[entry.routeCoordinates.length - 1][1] } : currentPosition);
    const mode = entry.navigationMode || entry.mode || 'driving';

    // 2. Populate reopened destination and transport mode
    setDestinationName(destName);
    setDestinationCoordinate(destCoord);
    setTransportMode(mode);

    const startCoord = entry.routeCoordinates.length > 0 ? { lat: entry.routeCoordinates[0][0], lng: entry.routeCoordinates[0][1] } : currentPosition;
    const endCoord = destCoord;

    const reopenedRoute: RouteOption = {
      id: `history-route-${entry.id}`,
      name: `To ${destName}`,
      distanceKm: entry.distanceKm,
      durationMinutes: entry.durationMinutes,
      trafficLevel: 'MODERATE',
      summary: `Reopened journey from ${entry.dateFormatted}`,
      coordinates: entry.routeCoordinates,
      steps: [
        {
          id: `step-history-${entry.id}-1`,
          instruction: `Proceed along route towards ${destName}`,
          distanceMeters: Math.round(entry.distanceKm * 1000),
          durationSeconds: entry.durationMinutes * 60,
          startCoordinate: startCoord,
          endCoordinate: endCoord,
          streetName: destName,
          maneuver: 'continue'
        }
      ]
    };

    setActiveRoute(reopenedRoute);
    setCandidateRoutes([reopenedRoute]);
    setSelectedRouteId(reopenedRoute.id);
    setIsRoutePlannerOpen(true);
    setRecenterTrigger((prev) => prev + 1);
  };

  const handleRotateHeading = (deltaDeg: number) => {
    const newHeading = (fusionState.headingDeg + deltaDeg + 360) % 360;
    fusionEngineRef.current.setPosition(fusionState.lat, fusionState.lng, newHeading);
    setFusionState((prev) => ({ ...prev, headingDeg: newHeading }));
  };

  // Evaluator Controls Handlers
  const handleTriggerBlackout = () => {
    gnssDetectorRef.current.forceState('GNSS_LOST');
    setGnssState('GNSS_LOST');
    globalVoiceService.speak(t.signalLostInertialEngaged, true);
  };

  const handleTriggerStop = () => {
    fusionEngineRef.current.getZuptDetector().forceStationary(true);
    globalSensorService.setVehicleStopped(true);
  };

  const handleReconnectGNSS = () => {
    gnssDetectorRef.current.forceState('GNSS_RESTORING');
    setGnssState('GNSS_RESTORING');
    globalSensorService.setVehicleStopped(false);
    fusionEngineRef.current.getZuptDetector().forceStationary(false);

    setTimeout(() => {
      gnssDetectorRef.current.forceState('GNSS_AVAILABLE');
      setGnssState('GNSS_AVAILABLE');
      globalVoiceService.speak(t.signalRestoredSynced, true);
    }, 1800);
  };

  const handleTriggerTunnel = () => {
    handleTriggerBlackout();
  };

  const handleTriggerPothole = () => {
    globalSensorService.triggerPothole();
  };

  const handleTriggerUrbanCanyon = () => {
    gnssDetectorRef.current.forceState('GNSS_DEGRADED');
    setGnssState('GNSS_DEGRADED');
  };

  const handleResetNormal = () => {
    gnssDetectorRef.current.forceState(null);
    setGnssState('GNSS_AVAILABLE');
    globalSensorService.setVehicleStopped(false);
    fusionEngineRef.current.getZuptDetector().forceStationary(false);
    fusionEngineRef.current.resetDrift();
  };

  // Context Payload for NaviSync AI Assistant
  const assistantContext: NavigationContextPayload = {
    location: {
      latitude: fusionState.lat,
      longitude: fusionState.lng,
      accuracy: gnssState === 'GNSS_AVAILABLE' ? 4.5 : 28
    },
    destination: destinationName ? { name: destinationName, lat: 0, lng: 0 } : null,
    route: activeRoute
      ? {
          summary: activeRoute.summary,
          distanceKm: activeRoute.distanceKm,
          durationMinutes: activeRoute.durationMinutes,
          currentStepIndex,
          nextManeuver: activeRoute.steps[currentStepIndex]?.instruction || 'Continue',
          distanceToNextManeuverMeters: activeRoute.steps[currentStepIndex]?.distanceMeters || 0
        }
      : null,
    gnss: {
      state: gnssState,
      accuracyMeters: gnssState === 'GNSS_AVAILABLE' ? 4.5 : 35,
      isLost: gnssState === 'GNSS_LOST' || gnssState === 'NAVISYNC_INERTIAL'
    },
    imu: {
      available: true,
      forwardAccel: filteredIMU.forwardAccel,
      filteredQuality: 0.96
    },
    navigation: {
      state: isNavigating ? 'NAVIGATING' : 'STANDBY',
      confidencePercent: Math.round(fusionState.confidence * 100),
      driftMeters: fusionState.driftMeters,
      outageDurationSeconds: fusionState.gnssOutageDurationSec,
      zuptActive: fusionState.isZuptActive,
      speedKmh: fusionState.speedKmh
    },
    offline: isOfflineMode,
    language,
    travelHistory: {
      totalTrips: travelStats.totalTrips,
      totalDistanceKm: travelStats.totalDistanceKm,
      avgSpeedKmh: travelStats.avgSpeedKmh,
      longestTripKm: travelStats.longestTripKm,
      recentSummary: travelStats.recentSummary
    }
  };

  // Dedicated SIH Demo Page View (Admin Persona Only)
  if (activeView === 'sih_demo' && currentPersona === 'admin') {
    return <SIHDemoPage onBackToRealNavigation={() => setActiveView('navigation')} />;
  }

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#050505] font-sans text-[#e0e0e0] select-none">
      {/* 1. Header with Language, Intelligence, Offline & Travel History Controls */}
      {!isNavigating && (
        <AppHeader
          currentLanguage={language}
          onChangeLanguage={setLanguage}
          gnssState={gnssState}
          onOpenIntelligence={() => setIsIntelligenceOpen(true)}
          onOpenEvaluator={() => setIsEvaluatorOpen(true)}
          onOpenOffline={() => setIsOfflineModalOpen(true)}
          onOpenTravelHistory={() => setIsTravelHistoryOpen(true)}
          voiceEnabled={voiceEnabled}
          onToggleVoice={() => setVoiceEnabled(!voiceEnabled)}
          persona={currentPersona}
          onTogglePersona={handleTogglePersona}
          onOpenSIHDemo={() => setActiveView('sih_demo')}
        />
      )}

      {/* 2. Primary Interactive Map Canvas */}
      <LeafletMap
        currentPosition={currentPosition}
        fusionState={fusionState}
        navState={navState}
        gnssState={gnssState}
        gnssHeading={gnssHeading}
        compassHeading={compassHeading}
        activeRoute={activeRoute}
        destinationCoordinate={destinationCoordinate}
        destinationName={destinationName}
        nearbyPlaces={nearbyPlaces}
        selectedPlace={selectedPlace}
        onSelectPlace={setSelectedPlace}
        isNavigating={isNavigating}
        showTraditionalComparison={showTraditionalComparison}
        onMapClick={handleMapClick}
        recenterTrigger={recenterTrigger}
      />

      {/* 3. Top Floating Search & Quick Discovery Chips (when not driving) */}
      {!isNavigating && (
        <div className="absolute top-20 left-4 right-4 z-20 max-w-xl mx-auto flex flex-col gap-2 pointer-events-none">
          <div className="pointer-events-auto flex items-center gap-2">
            <SearchBar
              onSelectLocation={handleSelectLocation}
              onClearDestination={handleClearDestination}
              activeDestinationName={destinationName}
              placeholderText={t.searchPlaceholder}
            />
            {destinationCoordinate && (
              <button
                id="btn-clear-dest-floating"
                onClick={handleClearDestination}
                title="Clear destination and return to normal map"
                className="p-2.5 rounded-2xl bg-[#0d0d0d]/90 border border-[#1f1f1f] text-rose-400 hover:text-rose-300 hover:bg-[#1a1a1a] shadow-xl backdrop-blur-md flex items-center gap-1.5 text-xs font-semibold shrink-0 transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
                <span className="hidden sm:inline">Clear</span>
              </button>
            )}
          </div>
          <div className="pointer-events-auto">
            <CategoryChips
              onSelectCategory={handleSelectCategory}
              onTriggerEmergency={handleTriggerEmergency}
              activeCategory={activeCategory}
            />
          </div>
        </div>
      )}

      {/* 4. Turn-by-Turn Navigation Cockpit (when active) */}
      {isNavigating && activeRoute && (
        <NavigationCockpit
          route={activeRoute}
          currentStepIndex={currentStepIndex}
          fusionState={fusionState}
          navState={navState}
          gnssState={gnssState}
          t={t}
          voiceEnabled={voiceEnabled}
          onToggleVoice={() => setVoiceEnabled(!voiceEnabled)}
          onStopNavigation={handleStopNavigation}
        />
      )}

      {/* 5. Places Discovery Carousel (all 5km results displayed) */}
      {nearbyPlaces.length > 0 && !isNavigating && !isRoutePlannerOpen && !selectedPlace && (
        <div className="absolute bottom-6 left-4 right-4 z-30 pointer-events-none flex justify-center">
          <PlacesCarousel
            places={nearbyPlaces}
            selectedPlaceId={selectedPlace?.id}
            onSelectPlace={(p) => setSelectedPlace(p)}
            onGetDirections={(p) =>
              handleSelectLocation({
                name: p.name,
                displayName: p.address,
                lat: p.lat,
                lng: p.lng,
                type: p.category
              })
            }
            onClose={() => setNearbyPlaces([])}
            categoryName={activeCategory || undefined}
          />
        </div>
      )}

      {/* 6. Place Details Floating Sheet */}
      {selectedPlace && !isNavigating && (
        <div className="absolute bottom-6 left-4 z-30 pointer-events-auto">
          <PlaceDetailSheet
            place={selectedPlace}
            onClose={() => setSelectedPlace(null)}
            onGetDirections={(place) => {
              handleSelectLocation({
                name: place.name,
                displayName: place.address,
                lat: place.lat,
                lng: place.lng,
                type: place.category
              });
            }}
          />
        </div>
      )}

      {/* 7. Route Planner Card */}
      {isRoutePlannerOpen && candidateRoutes.length > 0 && !isNavigating && (
        <div className="absolute bottom-6 left-4 z-30 pointer-events-auto">
          <RoutePlanner
            startCoordinate={currentPosition}
            destinationName={destinationName}
            routes={candidateRoutes}
            selectedRouteId={selectedRouteId}
            onSelectRoute={(id) => {
              setSelectedRouteId(id);
              const r = candidateRoutes.find((x) => x.id === id);
              if (r) setActiveRoute(r);
            }}
            onStartNavigation={handleStartNavigation}
            onClose={handleClearDestination}
            mode={transportMode}
            onChangeMode={async (m) => {
              setTransportMode(m);
              if (candidateRoutes.length > 0 && activeRoute) {
                const updated = await routingProviderRef.current.getRoutes(
                  currentPosition.lat,
                  currentPosition.lng,
                  candidateRoutes[0].coordinates.slice(-1)[0][0],
                  candidateRoutes[0].coordinates.slice(-1)[0][1],
                  m
                );
                setCandidateRoutes(updated);
                if (updated[0]) setActiveRoute(updated[0]);
              }
            }}
          />
        </div>
      )}

      {/* 8. Floating Collapsible NaviSync Technical Engine Status Panel */}
      <div className="absolute bottom-6 right-4 z-30 pointer-events-auto flex flex-col items-end gap-2">
        {isStatusPanelOpen ? (
          <NaviSyncStatusPanel
            gnssState={gnssState}
            fusionState={fusionState}
            isCollapsible={true}
            defaultExpanded={true}
            onOpenIntelligence={() => setIsIntelligenceOpen(true)}
          />
        ) : (
          <button
            id="btn-toggle-status-panel"
            type="button"
            onClick={() => setIsStatusPanelOpen(true)}
            className="bg-[#0a0a0a]/90 border border-[#222222] shadow-2xl px-3 py-2 rounded-xl text-xs font-mono font-bold text-white flex items-center gap-2 backdrop-blur-md hover:bg-[#141414] hover:border-[#333333] transition-all cursor-pointer"
            title="Toggle NaviSync Engine Live Status"
          >
            <span
              className={`w-2 h-2 rounded-full ${
                gnssState === 'GNSS_AVAILABLE'
                  ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]'
                  : 'bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.9)] animate-pulse'
              }`}
            />
            <span className="text-[10px] tracking-wider uppercase text-[#e0e0e0]">NAVISYNC STATUS</span>
          </button>
        )}
      </div>

      {/* 7. NaviSync AI Floating Assistant */}
      <NaviCopilot
        contextPayload={assistantContext}
        isOpen={isAssistantOpen}
        onToggleOpen={() => setIsAssistantOpen(!isAssistantOpen)}
      />

      {/* 8. Technical Intelligence Dashboard Modal */}
      {isIntelligenceOpen && (
        <IntelligenceDashboard
          fusionState={fusionState}
          gnssState={gnssState}
          rawIMU={rawIMU}
          filteredIMU={filteredIMU}
          onClose={() => setIsIntelligenceOpen(false)}
          onOpenEvaluator={() => {
            setIsIntelligenceOpen(false);
            setIsEvaluatorOpen(true);
          }}
          onOpenIOVNBD={() => {
            setIsIntelligenceOpen(false);
            setIsIOVNBDOldOpen(true);
          }}
          showComparison={showTraditionalComparison}
          onToggleComparison={() => setShowTraditionalComparison(!showTraditionalComparison)}
        />
      )}

      {/* 9. Evaluator Controls Modal */}
      {isEvaluatorOpen && (
        <EvaluatorControls
          gnssState={gnssState}
          isVehicleStopped={fusionState.isZuptActive}
          currentHeadingDeg={fusionState.headingDeg}
          onRotateHeading={handleRotateHeading}
          onTriggerBlackout={handleTriggerBlackout}
          onTriggerStop={handleTriggerStop}
          onReconnectGNSS={handleReconnectGNSS}
          onTriggerTunnel={handleTriggerTunnel}
          onTriggerPothole={handleTriggerPothole}
          onTriggerUrbanCanyon={handleTriggerUrbanCanyon}
          onResetNormal={handleResetNormal}
          onClose={() => setIsEvaluatorOpen(false)}
        />
      )}

      {/* 10. IO-VNBD Benchmark Dataset Modal */}
      {isIOVNBDOldOpen && <IOVNBDModal onClose={() => setIsIOVNBDOldOpen(false)} />}

      {/* 11. Offline Maps & IndexedDB Cache Modal */}
      {isOfflineModalOpen && (
        <OfflineManagerModal
          onClose={() => setIsOfflineModalOpen(false)}
          isOfflineMode={isOfflineMode}
          onToggleOfflineMode={() => {
            const next = !isOfflineMode;
            setIsOfflineMode(next);
            globalOfflineService.setOfflineMode(next);
          }}
          currentLat={fusionState.lat}
          currentLng={fusionState.lng}
        />
      )}

      {/* 12. Local IndexedDB Travel History & Saved Journeys Modal */}
      <TravelHistoryModal
        isOpen={isTravelHistoryOpen}
        onClose={() => setIsTravelHistoryOpen(false)}
        onReopenTripRoute={handleReopenTripRoute}
      />
    </div>
  );
}
