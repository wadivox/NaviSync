import { RAGDocument } from '../types/rag';

export const KNOWLEDGE_BASE_DOCS: RAGDocument[] = [
  {
    id: 'navisync-architecture',
    title: 'NaviSync 4-System Architectural Separation',
    category: 'architecture',
    version: '1.2',
    author: 'NaviSync Engineering Team',
    updatedAt: '2026-03-01',
    keywords: ['architecture', 'layers', 'separation', 'positioning', 'llm', 'assistant', 'fusion'],
    content: `NaviSync strictly isolates 4 distinct subsystems:
1. User System: Interactive Map, Search, Places, Turn-by-Turn Navigation UI, Offline Caching.
2. Navigation Positioning Layer: Deterministic mathematical engine fusing GNSS + IMU accelerometer/gyroscope, Dead Reckoning (DR), Non-Holonomic Constraints (NHC), Map Matching, and Zero Velocity Updates (ZUPT).
3. NaviSync AI Assistant: Natural language reasoning layer built on OpenAI GPT-4o-mini and RAG vector store. The LLM NEVER computes coordinates or integrates acceleration equations.
4. RAG Knowledge & Tools Layer: Grounded documentation and strict typed function calling interfaces (searchPlaces, getGNSSStatus, getDriftEstimate, calculateRoute, etc.).
Crucial invariant: Navigation continues uninterrupted even if OpenAI or internet connectivity is completely offline.`
  },
  {
    id: 'gnss-denied-resilience',
    title: 'GNSS Signal Loss Detection, Degradation & Recovery',
    category: 'navigation',
    version: '1.1',
    author: 'NaviSync Research Group',
    updatedAt: '2026-02-28',
    keywords: ['gnss', 'gps', 'outage', 'tunnel', 'urban canyon', 'degradation', 'multipath', 'loss'],
    content: `GNSS loss detection in NaviSync is based on multi-criteria Bayesian filtering rather than a single missed GPS packet:
- Horizontal Dilution of Precision (HDOP) and reported accuracy variance (> 25m threshold).
- Update frequency gap exceeding 2.2 seconds.
- Speed consistency checks between Doppler velocity and step-integrated vehicle motion.
- Position jump anomalies exceeding maximum physical kinematic acceleration.
When a signal outage begins (e.g. entering the 2.4 km Patalganga Mountain Tunnel or subterranean parking):
- State transitions: GNSS_AVAILABLE -> GNSS_DEGRADED -> GNSS_LOST -> NAVISYNC_INERTIAL.
- When signal returns, GNSS_RESTORING initiates an innovation-bounded Kalman correction to smoothly pull the trajectory without sudden teleportation.`
  },
  {
    id: 'dead-reckoning-imu',
    title: 'Inertial Dead Reckoning & Device Alignment',
    category: 'algorithms',
    version: '1.4',
    author: 'NaviSync Sensors Team',
    updatedAt: '2026-02-15',
    keywords: ['dead reckoning', 'imu', 'accelerometer', 'gyroscope', 'alignment', 'euler', 'quaternion'],
    content: `Dead Reckoning (DR) calculates progressive vehicle displacement by integrating body-frame accelerations and angular velocities over discrete time step dt (typical 10-50 Hz):
1. Calibration & Alignment: Gravity vector (9.81 m/s^2) is isolated during stationary periods to establish pitch and roll attitude angles.
2. Coordinate Transformation: Tri-axial sensor readings [ax, ay, az] are rotated into the navigation reference frame (East-North-Up) using the estimated attitude quaternion/DCM.
3. Forward Acceleration Isolation: Forward linear acceleration is separated from gravitational components and centripetal acceleration (ay = v * omega_z).
4. Dual Integration: Velocity is integrated: v(t) = v(t-1) + a_forward * dt. Position displacement: d = v(t) * dt. Heading is integrated from yaw gyro: theta(t) = theta(t-1) + omega_yaw * dt.`
  },
  {
    id: 'ai-motion-filter',
    title: 'AI Motion Filter & Noise Suppression',
    category: 'algorithms',
    version: '1.0',
    author: 'NaviSync AI Lab',
    updatedAt: '2026-01-20',
    keywords: ['ai motion filter', 'noise', 'vibration', 'pothole', 'tcn', 'lstm', 'engine vibration'],
    content: `Raw consumer phone IMUs suffer severe high-frequency noise from vehicle engine harmonics (20-120 Hz), road asphalt roughness, potholes, and passenger hand tremors.
NaviSync utilizes an AI Motion Filtering pipeline (Temporal Convolutional Network / 1D CNN baseline with high-order exponential bandpass filter):
- Rejects vibrational oscillations while preserving genuine longitudinal vehicle acceleration and braking transients.
- Detects sudden impulse shocks (e.g. potholes or speed breakers) and suppresses them from leaking into forward velocity integration.
- Automatically flags 'AI Motion Filter: Prototype Simulation' when using our deterministic DSP benchmark pipeline.`
  },
  {
    id: 'zupt-zero-velocity',
    title: 'Zero Velocity Update (ZUPT) Engine',
    category: 'algorithms',
    version: '1.3',
    author: 'NaviSync Inertial Lab',
    updatedAt: '2026-02-10',
    keywords: ['zupt', 'zero velocity', 'drift', 'stop', 'red light', 'traffic', 'standstill'],
    content: `The primary cause of catastrophic drift in classical inertial dead reckoning is integration error during standstill: if a 0.05 m/s^2 bias is integrated for 60 seconds at a red light inside a tunnel, the vehicle marker will falsely drift over 90 meters away!
Zero Velocity Update (ZUPT) solves this:
- Detects vehicle standstill when tri-axial accelerometer variance is < 0.015 (m/s^2)^2 and gyroscope angular rate variance is < 0.02 rad/s over a sliding 400ms window.
- When ZUPT engages: forward velocity is forcefully clamped to 0.0 m/s; accelerometer and gyroscope bias estimates are updated in the Kalman filter; position drift accumulation is paused.
- As soon as forward throttle exceeds the motion threshold, ZUPT releases immediately.`
  },
  {
    id: 'map-matching-nhc',
    title: 'Map Matching & Non-Holonomic Constraints (NHC)',
    category: 'algorithms',
    version: '1.2',
    author: 'NaviSync Geodesy Lab',
    updatedAt: '2026-02-18',
    keywords: ['map matching', 'nhc', 'non-holonomic', 'road network', 'heading constraint'],
    content: `Ground vehicles operate under strict physical kinematics known as Non-Holonomic Constraints (NHC):
1. Zero Lateral Slip: Assuming normal traction, vehicle velocity orthogonal to the driving axle is approximately zero (v_lateral ~ 0).
2. Zero Vertical Flight: A road vehicle does not fly or sink into subterranean strata (v_vertical ~ 0).
3. Topological Map Matching: The estimated vehicle trajectory is projected onto candidate polyline links of the road network using Hidden Markov Model (HMM) geometric distance and bearing alignment.
By enforcing NHC and road topology, accumulated lateral drift is eliminated, reducing position error by over 85% compared to open-loop IMU integration.`
  },
  {
    id: 'drift-and-confidence',
    title: 'Drift Estimator & Dynamic Confidence Scoring',
    category: 'algorithms',
    version: '1.1',
    author: 'NaviSync Analytics',
    updatedAt: '2026-02-22',
    keywords: ['drift', 'confidence', 'error bounds', 'outage duration', 'covariance'],
    content: `NaviSync calculates real-time positioning confidence dynamically based on:
- GNSS state: 98% during open-sky high-accuracy GNSS fix.
- Outage duration: Degrades logarithmically rather than instantaneously. At 30s outage with ZUPT + NHC + Map Matching, confidence remains ~82-88% with ~4-8m error.
- At 120s extended outage without corrections, confidence scales down to ~55-65% with estimated drift bounds visually displayed.
Traditional unconstrained double-integration drift (proportional to time squared: 1/2 * a_bias * t^2) would accumulate 150m+ in 60 seconds, whereas NaviSync's constrained fusion restricts drift to a fraction of that.`
  },
  {
    id: 'iovnbd-dataset-benchmarking',
    title: 'IO-VNBD Dataset & SIH26168 Benchmarking Methodology',
    category: 'dataset',
    version: '1.0',
    author: 'NaviSync SIH26168 Taskforce',
    updatedAt: '2026-02-25',
    keywords: ['io-vnbd', 'sih26168', 'dataset', 'benchmark', 'ground truth', 'evaluation'],
    content: `Problem Statement SIH26168 focuses on reliable navigation in GPS-denied environments using consumer mobile devices.
The IO-VNBD (Inertial Odometry - Vehicle Navigation Benchmark Dataset) training methodology:
- Ground-truth trajectory is recorded with dual-frequency RTK-GNSS alongside synchronized smartphone IMU sensors (100 Hz).
- Blackout Segments: We systematically mask GNSS data for intervals of 30s, 60s, and 120s to evaluate dead reckoning resilience.
- Model Training Target: The machine learning model is trained to predict delta-velocity (forward speed) and delta-yaw (heading rate) rather than latitude/longitude coordinates directly.
- Benchmark Metrics: Absolute Trajectory Error (ATE), Relative Pose Error (RPE), and Drift Percentage over Distance Travelled (typically < 1.8% in NaviSync vs 14.5% in raw IMU).`
  },
  {
    id: 'offline-and-emergency',
    title: 'Offline Maps Architecture & Emergency SOS Locating',
    category: 'emergency',
    version: '1.1',
    author: 'NaviSync Resilience Ops',
    updatedAt: '2026-02-27',
    keywords: ['offline', 'indexeddb', 'emergency', 'sos', 'hospital', 'police', 'ambulance', 'cache'],
    content: `NaviSync distinguishes two independent axes:
- Internet Connectivity: Online vs Offline (stored in client IndexedDB & Service Worker caches).
- Positioning Signal: GNSS Available vs GNSS Lost (handled by NaviSync Inertial Engine).
Emergency Mode allows instant 1-tap discovery of nearest trauma centers, hospitals, fire stations, and police stations using cached POI networks, and generates high-precision coordinates with confidence metrics for first-responder dispatch.`
  }
];

export function searchLocalKnowledge(query: string, limit = 3) {
  const qTokens = query.toLowerCase().split(/\s+/).filter(t => t.length > 2);
  if (qTokens.length === 0) return [];

  const scored = KNOWLEDGE_BASE_DOCS.map(doc => {
    let score = 0;
    const fullText = (doc.title + ' ' + doc.content + ' ' + doc.keywords.join(' ')).toLowerCase();
    for (const token of qTokens) {
      if (doc.title.toLowerCase().includes(token)) score += 5;
      if (doc.keywords.some(k => k.includes(token))) score += 4;
      const count = (fullText.match(new RegExp(token, 'g')) || []).length;
      score += Math.min(count, 5);
    }
    return { doc, score };
  });

  return scored
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(item => ({
      documentId: item.doc.id,
      title: item.doc.title,
      category: item.doc.category,
      snippet: item.doc.content.slice(0, 320) + '...',
      score: item.score
    }));
}
