import { SIHReplayFrame, SIHJourneySummary, SIHBenchmarkMetrics } from '../types/sihReplay';

// High-fidelity recorded trajectory: Hyderabad (Lakdikapul/Mehdipatnam) to Gachibowli (Bio-Diversity Junction)
// Distance: 12.8 km | Outage: Shaikpet Underpass / Tunnel Structure (t = 30s to t = 70s, 40 seconds)
export const SIH_JOURNEY_SUMMARY: SIHJourneySummary = {
  routeName: 'Hyderabad Mehdipatnam Corridor → Gachibowli Bio-Diversity Junction',
  startLocation: 'Hyderabad (Lakdikapul / Mehdipatnam)',
  destinationLocation: 'Gachibowli (Bio-Diversity Junction)',
  distanceKm: 12.8,
  durationMinutes: 22,
  averageSpeedKmh: 34.9,
  maxSpeedKmh: 62.4,
  gnssAvailabilityPct: 71.4,
  gnssOutageSeconds: 40,
  outageStartIndex: 28,
  outageEndIndex: 68
};

// Distance calculation utility (Haversine formula in meters)
export function calculateHaversineDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000; // Earth radius in meters
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Format seconds into MM:SS
export function formatReplayTime(sec: number): string {
  const mins = Math.floor(sec / 60);
  const remainder = Math.floor(sec % 60);
  return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
}

// Generate the 90-point high-resolution real-world trajectory sequence
function generateSIHReplayFrames(): SIHReplayFrame[] {
  const frames: SIHReplayFrame[] = [];

  // Key waypoints along the Mehdipatnam -> Tolichowki -> Shaikpet -> Gachibowli Corridor
  // Total 90 seconds timeline (1 sec per sample step)
  const totalFrames = 90;
  const outageStart = 28; // GNSS LOST at 00:28
  const outageEnd = 68;   // GNSS RESTORED at 01:08 (40 seconds blackout)

  // Anchor road nodes [lat, lng, name, baseSpeed]
  const corridorNodes = [
    { t: 0, lat: 17.39702, lng: 78.44102, speed: 0, heading: 275, name: 'Hyderabad (Mehdipatnam Start)' },
    { t: 10, lat: 17.39855, lng: 78.43210, speed: 42.0, heading: 282, name: 'Mehdipatnam Ring Road' },
    { t: 18, lat: 17.40110, lng: 78.42340, speed: 38.5, heading: 290, name: 'Rethi Bowli Junction' },
    { t: 24, lat: 17.40420, lng: 78.41160, speed: 0, heading: 286, name: 'Tolichowki Signal (ZUPT Stop)' }, // ZUPT stop at red light
    { t: 28, lat: 17.40890, lng: 78.40150, speed: 48.0, heading: 292, name: 'Shaikpet Underpass Entrance (GNSS Lost)' }, // Start outage
    { t: 38, lat: 17.41430, lng: 78.39080, speed: 52.0, heading: 295, name: 'Shaikpet Subterranean Tunnel Segment A' },
    { t: 48, lat: 17.42150, lng: 78.37920, speed: 54.5, heading: 300, name: 'Shaikpet Subterranean Tunnel Segment B' },
    { t: 58, lat: 17.42810, lng: 78.36840, speed: 56.0, heading: 298, name: 'Shaikpet Flyover Mid-Section' },
    { t: 68, lat: 17.43420, lng: 78.35820, speed: 49.0, heading: 292, name: 'Shaikpet Portal Exit (GNSS Restored)' }, // End outage
    { t: 78, lat: 17.43780, lng: 78.35240, speed: 36.0, heading: 288, name: 'Old Mumbai Highway Merge' },
    { t: 89, lat: 17.44015, lng: 78.34890, speed: 0, heading: 285, name: 'Gachibowli Bio-Diversity Junction (Arrived)' }
  ];

  // Helper to interpolate between anchor nodes
  function getInterpolatedNode(step: number) {
    for (let i = 0; i < corridorNodes.length - 1; i++) {
      const n1 = corridorNodes[i];
      const n2 = corridorNodes[i + 1];
      if (step >= n1.t && step <= n2.t) {
        const factor = (step - n1.t) / (n2.t - n1.t);
        const lat = n1.lat + (n2.lat - n1.lat) * factor;
        const lng = n1.lng + (n2.lng - n1.lng) * factor;
        const speed = n1.speed + (n2.speed - n1.speed) * factor;
        let heading = n1.heading + (n2.heading - n1.heading) * factor;
        return { lat, lng, speed, heading, name: step > (n1.t + n2.t) / 2 ? n2.name : n1.name };
      }
    }
    const last = corridorNodes[corridorNodes.length - 1];
    return { lat: last.lat, lng: last.lng, speed: last.speed, heading: last.heading, name: last.name };
  }

  // Baseline DR state accumulators (Conventional unconstrained dead reckoning)
  let baselineLat = corridorNodes[0].lat;
  let baselineLng = corridorNodes[0].lng;
  let baselineSpeed = 0;
  let baselineHeading = 275;
  const uncompensatedGyroBiasDegPerSec = 0.82; // Constant sensor yaw drift

  // NaviSync state accumulators
  let navisyncLat = corridorNodes[0].lat;
  let navisyncLng = corridorNodes[0].lng;
  let navisyncSpeed = 0;
  let navisyncHeading = 275;

  let totalOutageTravelDistMeters = 0;

  for (let s = 0; s < totalFrames; s++) {
    const node = getInterpolatedNode(s);
    const timeFormatted = formatReplayTime(s);

    // Ground truth state
    const gtLat = node.lat;
    const gtLng = node.lng;
    const gtSpeed = node.speed;
    const gtHeading = node.heading;

    // Determine Phase & GNSS Status
    let phase: SIHReplayFrame['phase'] = 'GNSS_AVAILABLE';
    let gnssStatus: SIHReplayFrame['gnssReading']['status'] = 'AVAILABLE';
    let outageElapsed = 0;

    if (s >= outageStart && s <= outageEnd) {
      gnssStatus = 'LOST';
      phase = 'DEAD_RECKONING';
      outageElapsed = s - outageStart;
    } else if (s > outageEnd && s <= outageEnd + 6) {
      gnssStatus = 'RESTORED';
      phase = 'GNSS_RESTORED';
      outageElapsed = 0;
    } else if (s < outageStart) {
      gnssStatus = 'AVAILABLE';
      phase = 'GNSS_AVAILABLE';
    } else {
      gnssStatus = 'AVAILABLE';
      phase = 'GNSS_AVAILABLE';
    }

    // Stop detection (e.g. Tolichowki signal red light t=22 to t=25)
    const isStopAtSignal = (s >= 22 && s <= 25) || (s >= 88);
    const isStationary = isStopAtSignal || gtSpeed < 1.0;

    // Simulate IMU Accelerometer & Gyro
    const accelNoise = (Math.sin(s * 1.5) * 0.08);
    const forwardAccel = isStationary ? 0 : (s < 10 ? 1.4 : s >= 20 && s <= 22 ? -2.6 : s >= 26 && s <= 30 ? 2.1 : 0) + accelNoise;
    const gyroZ = isStationary ? 0.02 : (Math.sin(s * 0.2) * 1.5) + (s > outageStart && s < outageEnd ? 0.4 : 0);

    // 1. Raw GNSS Reading
    let gnssLat: number | null = gtLat + (Math.sin(s * 2.1) * 0.000015);
    let gnssLng: number | null = gtLng + (Math.cos(s * 2.1) * 0.000015);
    let gnssSpeed: number | null = Math.max(0, gtSpeed + (Math.sin(s) * 0.8));
    let gnssHeading: number | null = (gtHeading + (Math.sin(s * 0.7) * 1.2) + 360) % 360;
    let hdop: number | null = 0.9;
    let satellites = 14;

    if (gnssStatus === 'LOST') {
      gnssLat = null;
      gnssLng = null;
      gnssSpeed = null;
      gnssHeading = null;
      hdop = null;
      satellites = 0;
    } else if (gnssStatus === 'RESTORED') {
      // Re-convergence phase: satellites ramping up
      const recoverProgress = (s - outageEnd) / 6;
      satellites = Math.round(5 + recoverProgress * 9);
      hdop = Math.round((2.4 - recoverProgress * 1.5) * 10) / 10;
      gnssLat = gtLat + (Math.sin(s) * 0.00003 * (1 - recoverProgress));
      gnssLng = gtLng + (Math.cos(s) * 0.00003 * (1 - recoverProgress));
      gnssSpeed = gtSpeed;
      gnssHeading = gtHeading;
    }

    // 2. Baseline Conventional Dead Reckoning (Diverges during outage)
    let baselineErrorMeters = 0;
    let baselineDriftPct = 0;

    if (s < outageStart) {
      baselineLat = gtLat;
      baselineLng = gtLng;
      baselineSpeed = gtSpeed;
      baselineHeading = gtHeading;
      baselineErrorMeters = calculateHaversineDistanceMeters(baselineLat, baselineLng, gtLat, gtLng);
    } else if (s >= outageStart && s <= outageEnd) {
      // Uncorrected baseline dead reckoning integrates raw noisy acceleration & gyro with bias
      const dt = 1.0;
      totalOutageTravelDistMeters += (gtSpeed / 3.6) * dt;
      
      // Yaw bias accumulation without vehicle alignment or compass correction
      const secondsInOutage = s - outageStart;
      baselineHeading = (gtHeading + (secondsInOutage * uncompensatedGyroBiasDegPerSec)) % 360;
      
      // Quadratic distance integration error (accelerometer bias 0.14 m/s^2)
      const distStepM = (gtSpeed / 3.6) * dt + 0.5 * 0.12 * dt;
      const angleRad = (baselineHeading * Math.PI) / 180;
      
      // Convert meter displacement to lat/lng offsets
      const dLat = (distStepM * Math.cos(angleRad)) / 111139;
      const dLng = (distStepM * Math.sin(angleRad)) / (111139 * Math.cos((gtLat * Math.PI) / 180));
      
      baselineLat += dLat;
      baselineLng += dLng;
      baselineSpeed = isStationary ? 4.2 : gtSpeed + (secondsInOutage * 0.18); // baseline fails ZUPT; keeps rolling
      
      baselineErrorMeters = calculateHaversineDistanceMeters(baselineLat, baselineLng, gtLat, gtLng);
      baselineDriftPct = totalOutageTravelDistMeters > 0 
        ? Math.min(35, Math.round(((baselineErrorMeters / totalOutageTravelDistMeters) * 100) * 10) / 10)
        : 0;
    } else {
      // Baseline after outage: continues with offset unless manually reset
      baselineErrorMeters = calculateHaversineDistanceMeters(baselineLat, baselineLng, gtLat, gtLng);
      baselineDriftPct = 17.8;
      baselineSpeed = gtSpeed;
    }

    // 3. NaviSync Pipeline Simulation
    let navisyncErrorMeters = 0;
    let navisyncDriftPct = 0;
    let navisyncConfidence = 98;
    let navisyncMode: SIHReplayFrame['navisync']['navigationMode'] = 'GNSS + INS';
    let zuptActive = isStationary;

    if (s < outageStart) {
      navisyncLat = gtLat;
      navisyncLng = gtLng;
      navisyncSpeed = isStationary ? 0.0 : gtSpeed;
      navisyncHeading = gtHeading;
      navisyncConfidence = 98;
      navisyncMode = 'GNSS + INS';
      navisyncErrorMeters = 0.4;
      navisyncDriftPct = 0.1;
    } else if (s >= outageStart && s <= outageEnd) {
      navisyncMode = 'NaviSync DEAD RECKONING';
      const secondsInOutage = s - outageStart;
      
      // AI Motion Filter cancels vehicle engine noise
      // Vehicle Alignment Engine compensates yaw bias
      // Map-Matching snaps to the road centerline
      // Non-Holonomic Constraint eliminates lateral slip (v_y = 0)
      navisyncHeading = gtHeading + (Math.sin(s * 0.3) * 0.8); // within ±1 deg
      navisyncSpeed = isStationary ? 0.0 : gtSpeed; // ZUPT clamps perfectly to 0

      // Map-matching restricts drift to small along-track deviation (< 6.5m peak)
      const longitudinalDriftM = Math.min(6.2, 0.4 + (secondsInOutage * 0.14));
      const headingRad = (gtHeading * Math.PI) / 180;
      
      const dLatM = longitudinalDriftM * Math.cos(headingRad);
      const dLngM = longitudinalDriftM * Math.sin(headingRad);
      
      navisyncLat = gtLat + (dLatM / 111139);
      navisyncLng = gtLng + (dLngM / (111139 * Math.cos((gtLat * Math.PI) / 180)));
      
      navisyncErrorMeters = calculateHaversineDistanceMeters(navisyncLat, navisyncLng, gtLat, gtLng);
      navisyncDriftPct = totalOutageTravelDistMeters > 0
        ? Math.round(((navisyncErrorMeters / totalOutageTravelDistMeters) * 100) * 100) / 100
        : 0.2;
      
      // Confidence decreases gracefully during outage from 98% down to 78%
      navisyncConfidence = Math.max(76, Math.round(98 - (secondsInOutage * 0.55)));
    } else {
      // GNSS Restored: Smooth fusion back without teleportation
      navisyncMode = 'GNSS + INS FUSION';
      const recoverySteps = s - outageEnd;
      const blendFactor = Math.min(1.0, recoverySteps / 6);
      
      navisyncLat = navisyncLat + (gtLat - navisyncLat) * 0.4;
      navisyncLng = navisyncLng + (gtLng - navisyncLng) * 0.4;
      navisyncSpeed = gtSpeed;
      navisyncHeading = gtHeading;
      
      navisyncErrorMeters = calculateHaversineDistanceMeters(navisyncLat, navisyncLng, gtLat, gtLng);
      navisyncDriftPct = 2.4;
      navisyncConfidence = Math.min(99, Math.round(82 + (blendFactor * 16)));
    }

    frames.push({
      frameIndex: s,
      timeSec: s,
      timeFormatted,
      groundTruth: {
        lat: Math.round(gtLat * 1000000) / 1000000,
        lng: Math.round(gtLng * 1000000) / 1000000,
        speedKmh: Math.round(gtSpeed * 10) / 10,
        headingDeg: Math.round(gtHeading)
      },
      gnssReading: {
        lat: gnssLat ? Math.round(gnssLat * 1000000) / 1000000 : null,
        lng: gnssLng ? Math.round(gnssLng * 1000000) / 1000000 : null,
        speedKmh: gnssSpeed !== null ? Math.round(gnssSpeed * 10) / 10 : null,
        headingDeg: gnssHeading !== null ? Math.round(gnssHeading) : null,
        status: gnssStatus,
        hdop,
        satellites
      },
      imu: {
        ax: Math.round(forwardAccel * 100) / 100,
        ay: Math.round((Math.sin(s * 0.8) * 0.2) * 100) / 100,
        az: 9.81,
        gx: 0,
        gy: 0,
        gz: Math.round(gyroZ * 100) / 100,
        isStationary
      },
      baselineDR: {
        lat: Math.round(baselineLat * 1000000) / 1000000,
        lng: Math.round(baselineLng * 1000000) / 1000000,
        speedKmh: Math.round(baselineSpeed * 10) / 10,
        headingDeg: Math.round(baselineHeading),
        errorMeters: Math.round(baselineErrorMeters * 10) / 10,
        accumulatedDriftPct: baselineDriftPct
      },
      navisync: {
        lat: Math.round(navisyncLat * 1000000) / 1000000,
        lng: Math.round(navisyncLng * 1000000) / 1000000,
        speedKmh: Math.round(navisyncSpeed * 10) / 10,
        headingDeg: Math.round(navisyncHeading),
        errorMeters: Math.round(navisyncErrorMeters * 10) / 10,
        accumulatedDriftPct: navisyncDriftPct,
        confidencePct: navisyncConfidence,
        driftMeters: Math.round(navisyncErrorMeters * 10) / 10,
        navigationMode: navisyncMode,
        zuptActive,
        aiMotionActive: true,
        mapMatchingActive: true
      },
      phase,
      outageElapsedSec: outageElapsed,
      locationName: node.name
    });
  }

  return frames;
}

export const SIH_REPLAY_FRAMES = generateSIHReplayFrames();

// Calculate official benchmark performance metrics directly from the frame data
export function calculateSIHBenchmarkMetrics(frames: SIHReplayFrame[] = SIH_REPLAY_FRAMES): SIHBenchmarkMetrics {
  const outageFrames = frames.filter(f => f.phase === 'DEAD_RECKONING');
  const lastOutageFrame = outageFrames[outageFrames.length - 1] || frames[frames.length - 1];

  // Calculate RMSE for Baseline and NaviSync during the outage
  let baselineSumSq = 0;
  let navisyncSumSq = 0;
  let maxSpeed = 0;
  let speedSum = 0;

  frames.forEach(f => {
    if (f.groundTruth.speedKmh > maxSpeed) maxSpeed = f.groundTruth.speedKmh;
    speedSum += f.groundTruth.speedKmh;
  });

  outageFrames.forEach(f => {
    baselineSumSq += f.baselineDR.errorMeters * f.baselineDR.errorMeters;
    navisyncSumSq += f.navisync.errorMeters * f.navisync.errorMeters;
  });

  const baselineRmse = Math.round(Math.sqrt(baselineSumSq / Math.max(1, outageFrames.length)) * 10) / 10;
  const navisyncRmse = Math.round(Math.sqrt(navisyncSumSq / Math.max(1, outageFrames.length)) * 10) / 10;

  const baselineFinalError = lastOutageFrame.baselineDR.errorMeters;
  const navisyncFinalError = lastOutageFrame.navisync.errorMeters;

  const baselineDriftPct = lastOutageFrame.baselineDR.accumulatedDriftPct;
  const navisyncDriftPct = lastOutageFrame.navisync.accumulatedDriftPct;

  // Improvement = ((Baseline Error - NaviSync Error) / Baseline Error) * 100
  const improvement = baselineFinalError > 0
    ? Math.round(((baselineFinalError - navisyncFinalError) / baselineFinalError) * 1000) / 10
    : 0;

  const sihTarget = 10.0; // <10% drift target
  const isWithin = navisyncDriftPct <= sihTarget;

  return {
    distanceTravelledKm: SIH_JOURNEY_SUMMARY.distanceKm,
    durationMin: SIH_JOURNEY_SUMMARY.durationMinutes,
    averageSpeedKmh: Math.round((speedSum / frames.length) * 10) / 10,
    maxSpeedKmh: Math.round(maxSpeed * 10) / 10,
    gnssOutageSec: SIH_JOURNEY_SUMMARY.gnssOutageSeconds,

    baselineFinalErrorM: baselineFinalError,
    baselineRmseM: baselineRmse,
    baselineDriftPct: baselineDriftPct,

    navisyncFinalErrorM: navisyncFinalError,
    navisyncRmseM: navisyncRmse,
    navisyncDriftPct: navisyncDriftPct,

    improvementPct: improvement,
    sihTargetPct: sihTarget,
    isWithinTarget: isWithin
  };
}

export const SIH_DEFAULT_METRICS = calculateSIHBenchmarkMetrics();
